﻿Imports MySql.Data.MySqlClient
Module user
    Public con As MySqlConnection = mysqldb()
    Public USERID As Integer = 0
    Public Sub login(ByVal USERNAME As Object, ByVal PASSWORD As Object)
        Try

            con.Open()
            reloadtxt("SELECT * FROM tbluser WHERE USERNAME= '" & USERNAME & "' and PASSWORD = sha1('" & PASSWORD & "')")


            If dt.Rows.Count > 0 Then
                USERID = dt.Rows(0).Item("USER_ID")
                If dt.Rows(0).Item("TYPE") = "Administrator" Then
                    MsgBox("Welcome " & dt.Rows(0).Item("TYPE"))
                    With FormMenu
                        .Show()
                        'MsgBox("Today's user : " & dt.Rows(0).Item("NAME") & "/" & dt.Rows(0).Item("TYPE"))
                    End With
                    LoginForm1.Hide()

                ElseIf dt.Rows(0).Item("TYPE") = "HR Personnel" Then
                    MsgBox("Welcome " & dt.Rows(0).Item("TYPE"))
                    With FormMenu
                        .Show()
                        .btnSettings.Enabled = False
                        .btnManageUser.Enabled = False
                    End With
                    LoginForm1.Hide()
                End If

            Else
                MsgBox("Acount doest not exits!", MsgBoxStyle.Information)
            End If
        Catch ex As Exception
            MsgBox("error:" + ex.Message)
        End Try
        con.Close()
        da.Dispose()
    End Sub
    Public Sub append(ByVal sql As String, ByVal field As String, ByVal txt As Object)
        reloadtxt(sql)
        Try
            Dim r As DataRow
            txt.AutoCompleteCustomSource.Clear()
            For Each r In dt.Rows
                txt.AutoCompleteCustomSource.Add(r.Item(field).ToString)
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
       

    End Sub
End Module

