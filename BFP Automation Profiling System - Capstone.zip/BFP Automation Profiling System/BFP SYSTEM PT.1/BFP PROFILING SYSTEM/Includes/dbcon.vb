﻿Imports MySql.Data.MySqlClient
Module dbcon
    Public Function mysqldb() As MySqlConnection

        Return New MySqlConnection("server=localhost;user id=root;password=rooting;database=db_bfparpis;sslMode=none ")

    End Function

    Public con As MySqlConnection = mysqldb()

End Module
