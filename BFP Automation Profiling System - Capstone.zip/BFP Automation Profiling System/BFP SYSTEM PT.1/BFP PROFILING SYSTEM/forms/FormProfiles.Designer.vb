﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormProfiles
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormProfiles))
        Me.txtcode = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtbplace = New System.Windows.Forms.RichTextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.dtpdbirth = New System.Windows.Forms.DateTimePicker()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtlname = New System.Windows.Forms.TextBox()
        Me.txtcontact = New System.Windows.Forms.TextBox()
        Me.txtfname = New System.Windows.Forms.TextBox()
        Me.txtmname = New System.Windows.Forms.TextBox()
        Me.rdofemale = New System.Windows.Forms.RadioButton()
        Me.txtemerg = New System.Windows.Forms.TextBox()
        Me.txtrank = New System.Windows.Forms.ComboBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.cbounitassign = New System.Windows.Forms.ComboBox()
        Me.txtremarks = New System.Windows.Forms.TextBox()
        Me.txtlngpaynum = New System.Windows.Forms.TextBox()
        Me.txtlndbnknum = New System.Windows.Forms.TextBox()
        Me.txtbadgenum = New System.Windows.Forms.TextBox()
        Me.txtphlthnum = New System.Windows.Forms.TextBox()
        Me.txtgsisnum = New System.Windows.Forms.TextBox()
        Me.txtpibgnum = New System.Windows.Forms.TextBox()
        Me.txttinnum = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.dteffectivecon = New System.Windows.Forms.DateTimePicker()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.txtauthcondesig = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.txtcondesig = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.txtdateretire = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.dtdolp = New System.Windows.Forms.DateTimePicker()
        Me.dtdao = New System.Windows.Forms.DateTimePicker()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.txtyrsfiresvc = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.dtendfs = New System.Windows.Forms.DateTimePicker()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.dtdefs = New System.Windows.Forms.DateTimePicker()
        Me.dtdegs = New System.Windows.Forms.DateTimePicker()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.txtyrspridesig = New System.Windows.Forms.TextBox()
        Me.dteop = New System.Windows.Forms.DateTimePicker()
        Me.dtseop = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.txtadmin = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.txtapd = New System.Windows.Forms.TextBox()
        Me.txtpridesig = New System.Windows.Forms.TextBox()
        Me.txtitemnum = New System.Windows.Forms.TextBox()
        Me.txtunitcode = New System.Windows.Forms.TextBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtaccnum = New System.Windows.Forms.TextBox()
        Me.cbosoa = New System.Windows.Forms.ComboBox()
        Me.rdomale = New System.Windows.Forms.RadioButton()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtstatus = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.txtaddress = New System.Windows.Forms.RichTextBox()
        Me.cbomunicipality = New System.Windows.Forms.ComboBox()
        Me.txtzipcode = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtprovince = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtreligion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtsfxname = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtage = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.LblDtNow = New System.Windows.Forms.Label()
        Me.emptitle = New System.Windows.Forms.Label()
        Me.btnSave = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btnNew = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.txtPhoto = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtcrs = New System.Windows.Forms.TextBox()
        Me.cbohigheli = New System.Windows.Forms.ComboBox()
        Me.txtothereli = New System.Windows.Forms.TextBox()
        Me.txtdspecialtrain = New System.Windows.Forms.TextBox()
        Me.txtspecialtrain = New System.Windows.Forms.TextBox()
        Me.txtdmantrain = New System.Windows.Forms.TextBox()
        Me.txtdoccrs = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cbolvleli = New System.Windows.Forms.ComboBox()
        Me.txtmascrs = New System.Windows.Forms.TextBox()
        Me.txtmaslvl = New System.Windows.Forms.TextBox()
        Me.txtdoclvl = New System.Windows.Forms.TextBox()
        Me.cbohighmantrain = New System.Windows.Forms.ComboBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtcode
        '
        Me.txtcode.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtcode.Enabled = False
        Me.txtcode.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcode.Location = New System.Drawing.Point(19, 39)
        Me.txtcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtcode.Multiline = True
        Me.txtcode.Name = "txtcode"
        Me.txtcode.Size = New System.Drawing.Size(71, 24)
        Me.txtcode.TabIndex = 18
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(15, 23)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(62, 16)
        Me.Label20.TabIndex = 19
        Me.Label20.Text = "EMP ID :"
        '
        'txtbplace
        '
        Me.txtbplace.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtbplace.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbplace.Location = New System.Drawing.Point(20, 85)
        Me.txtbplace.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtbplace.Name = "txtbplace"
        Me.txtbplace.Size = New System.Drawing.Size(274, 35)
        Me.txtbplace.TabIndex = 17
        Me.txtbplace.Text = ""
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(16, 68)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(97, 16)
        Me.Label21.TabIndex = 14
        Me.Label21.Text = "Place of Birth :"
        '
        'dtpdbirth
        '
        Me.dtpdbirth.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.dtpdbirth.CustomFormat = "yyyy-MM-dd"
        Me.dtpdbirth.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpdbirth.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpdbirth.Location = New System.Drawing.Point(303, 91)
        Me.dtpdbirth.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtpdbirth.Name = "dtpdbirth"
        Me.dtpdbirth.Size = New System.Drawing.Size(115, 22)
        Me.dtpdbirth.TabIndex = 12
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(300, 72)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(86, 16)
        Me.Label22.TabIndex = 11
        Me.Label22.Text = "Date of Birth"
        '
        'txtlname
        '
        Me.txtlname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtlname.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.txtlname.Location = New System.Drawing.Point(304, 40)
        Me.txtlname.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtlname.Multiline = True
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(235, 23)
        Me.txtlname.TabIndex = 0
        '
        'txtcontact
        '
        Me.txtcontact.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtcontact.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcontact.Location = New System.Drawing.Point(594, 90)
        Me.txtcontact.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtcontact.MaxLength = 11
        Me.txtcontact.Multiline = True
        Me.txtcontact.Name = "txtcontact"
        Me.txtcontact.Size = New System.Drawing.Size(140, 23)
        Me.txtcontact.TabIndex = 0
        '
        'txtfname
        '
        Me.txtfname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtfname.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfname.Location = New System.Drawing.Point(96, 40)
        Me.txtfname.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtfname.Multiline = True
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(203, 23)
        Me.txtfname.TabIndex = 0
        '
        'txtmname
        '
        Me.txtmname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtmname.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmname.Location = New System.Drawing.Point(544, 40)
        Me.txtmname.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtmname.Multiline = True
        Me.txtmname.Name = "txtmname"
        Me.txtmname.Size = New System.Drawing.Size(234, 23)
        Me.txtmname.TabIndex = 0
        '
        'rdofemale
        '
        Me.rdofemale.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.rdofemale.AutoSize = True
        Me.rdofemale.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdofemale.Location = New System.Drawing.Point(32, 56)
        Me.rdofemale.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdofemale.Name = "rdofemale"
        Me.rdofemale.Size = New System.Drawing.Size(75, 22)
        Me.rdofemale.TabIndex = 6
        Me.rdofemale.TabStop = True
        Me.rdofemale.Text = "Female"
        Me.rdofemale.UseVisualStyleBackColor = True
        '
        'txtemerg
        '
        Me.txtemerg.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtemerg.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtemerg.Location = New System.Drawing.Point(740, 90)
        Me.txtemerg.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtemerg.MaxLength = 11
        Me.txtemerg.Multiline = True
        Me.txtemerg.Name = "txtemerg"
        Me.txtemerg.Size = New System.Drawing.Size(229, 23)
        Me.txtemerg.TabIndex = 0
        '
        'txtrank
        '
        Me.txtrank.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtrank.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrank.FormattingEnabled = True
        Me.txtrank.Location = New System.Drawing.Point(460, 46)
        Me.txtrank.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtrank.Name = "txtrank"
        Me.txtrank.Size = New System.Drawing.Size(103, 26)
        Me.txtrank.TabIndex = 2
        '
        'GroupBox10
        '
        Me.GroupBox10.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox10.Controls.Add(Me.cbounitassign)
        Me.GroupBox10.Controls.Add(Me.txtremarks)
        Me.GroupBox10.Controls.Add(Me.txtlngpaynum)
        Me.GroupBox10.Controls.Add(Me.txtlndbnknum)
        Me.GroupBox10.Controls.Add(Me.txtbadgenum)
        Me.GroupBox10.Controls.Add(Me.txtphlthnum)
        Me.GroupBox10.Controls.Add(Me.txtgsisnum)
        Me.GroupBox10.Controls.Add(Me.txtpibgnum)
        Me.GroupBox10.Controls.Add(Me.txttinnum)
        Me.GroupBox10.Controls.Add(Me.Label53)
        Me.GroupBox10.Controls.Add(Me.Label54)
        Me.GroupBox10.Controls.Add(Me.Label55)
        Me.GroupBox10.Controls.Add(Me.Label56)
        Me.GroupBox10.Controls.Add(Me.Label57)
        Me.GroupBox10.Controls.Add(Me.Label58)
        Me.GroupBox10.Controls.Add(Me.Label59)
        Me.GroupBox10.Controls.Add(Me.Label60)
        Me.GroupBox10.Controls.Add(Me.dteffectivecon)
        Me.GroupBox10.Controls.Add(Me.Label51)
        Me.GroupBox10.Controls.Add(Me.txtauthcondesig)
        Me.GroupBox10.Controls.Add(Me.Label50)
        Me.GroupBox10.Controls.Add(Me.txtcondesig)
        Me.GroupBox10.Controls.Add(Me.Label49)
        Me.GroupBox10.Controls.Add(Me.txtdateretire)
        Me.GroupBox10.Controls.Add(Me.Label3)
        Me.GroupBox10.Controls.Add(Me.Label48)
        Me.GroupBox10.Controls.Add(Me.dtdolp)
        Me.GroupBox10.Controls.Add(Me.dtdao)
        Me.GroupBox10.Controls.Add(Me.Label45)
        Me.GroupBox10.Controls.Add(Me.Label47)
        Me.GroupBox10.Controls.Add(Me.txtyrsfiresvc)
        Me.GroupBox10.Controls.Add(Me.Label44)
        Me.GroupBox10.Controls.Add(Me.dtendfs)
        Me.GroupBox10.Controls.Add(Me.Label43)
        Me.GroupBox10.Controls.Add(Me.dtdefs)
        Me.GroupBox10.Controls.Add(Me.dtdegs)
        Me.GroupBox10.Controls.Add(Me.Label41)
        Me.GroupBox10.Controls.Add(Me.Label42)
        Me.GroupBox10.Controls.Add(Me.txtyrspridesig)
        Me.GroupBox10.Controls.Add(Me.dteop)
        Me.GroupBox10.Controls.Add(Me.dtseop)
        Me.GroupBox10.Controls.Add(Me.Label1)
        Me.GroupBox10.Controls.Add(Me.Label36)
        Me.GroupBox10.Controls.Add(Me.Label46)
        Me.GroupBox10.Controls.Add(Me.txtadmin)
        Me.GroupBox10.Controls.Add(Me.Label40)
        Me.GroupBox10.Controls.Add(Me.txtapd)
        Me.GroupBox10.Controls.Add(Me.txtpridesig)
        Me.GroupBox10.Controls.Add(Me.txtitemnum)
        Me.GroupBox10.Controls.Add(Me.txtunitcode)
        Me.GroupBox10.Controls.Add(Me.Label52)
        Me.GroupBox10.Controls.Add(Me.Label19)
        Me.GroupBox10.Controls.Add(Me.Label18)
        Me.GroupBox10.Controls.Add(Me.Label23)
        Me.GroupBox10.Controls.Add(Me.Label37)
        Me.GroupBox10.Controls.Add(Me.Label38)
        Me.GroupBox10.Controls.Add(Me.Label39)
        Me.GroupBox10.Controls.Add(Me.txtaccnum)
        Me.GroupBox10.Controls.Add(Me.cbosoa)
        Me.GroupBox10.Controls.Add(Me.txtrank)
        Me.GroupBox10.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox10.Location = New System.Drawing.Point(148, 383)
        Me.GroupBox10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox10.Size = New System.Drawing.Size(976, 222)
        Me.GroupBox10.TabIndex = 39
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "WORK INFORMATION"
        '
        'cbounitassign
        '
        Me.cbounitassign.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cbounitassign.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbounitassign.FormattingEnabled = True
        Me.cbounitassign.Location = New System.Drawing.Point(252, 47)
        Me.cbounitassign.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cbounitassign.Name = "cbounitassign"
        Me.cbounitassign.Size = New System.Drawing.Size(92, 26)
        Me.cbounitassign.TabIndex = 176
        '
        'txtremarks
        '
        Me.txtremarks.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtremarks.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtremarks.Location = New System.Drawing.Point(863, 188)
        Me.txtremarks.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtremarks.Multiline = True
        Me.txtremarks.Name = "txtremarks"
        Me.txtremarks.Size = New System.Drawing.Size(106, 23)
        Me.txtremarks.TabIndex = 175
        '
        'txtlngpaynum
        '
        Me.txtlngpaynum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtlngpaynum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlngpaynum.Location = New System.Drawing.Point(742, 189)
        Me.txtlngpaynum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtlngpaynum.Multiline = True
        Me.txtlngpaynum.Name = "txtlngpaynum"
        Me.txtlngpaynum.Size = New System.Drawing.Size(115, 23)
        Me.txtlngpaynum.TabIndex = 174
        '
        'txtlndbnknum
        '
        Me.txtlndbnknum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtlndbnknum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlndbnknum.Location = New System.Drawing.Point(575, 189)
        Me.txtlndbnknum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtlndbnknum.Multiline = True
        Me.txtlndbnknum.Name = "txtlndbnknum"
        Me.txtlndbnknum.Size = New System.Drawing.Size(158, 23)
        Me.txtlndbnknum.TabIndex = 173
        '
        'txtbadgenum
        '
        Me.txtbadgenum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtbadgenum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbadgenum.Location = New System.Drawing.Point(467, 189)
        Me.txtbadgenum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtbadgenum.Multiline = True
        Me.txtbadgenum.Name = "txtbadgenum"
        Me.txtbadgenum.Size = New System.Drawing.Size(104, 23)
        Me.txtbadgenum.TabIndex = 172
        '
        'txtphlthnum
        '
        Me.txtphlthnum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtphlthnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtphlthnum.Location = New System.Drawing.Point(346, 189)
        Me.txtphlthnum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtphlthnum.Multiline = True
        Me.txtphlthnum.Name = "txtphlthnum"
        Me.txtphlthnum.Size = New System.Drawing.Size(115, 23)
        Me.txtphlthnum.TabIndex = 171
        '
        'txtgsisnum
        '
        Me.txtgsisnum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtgsisnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgsisnum.Location = New System.Drawing.Point(238, 189)
        Me.txtgsisnum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtgsisnum.Multiline = True
        Me.txtgsisnum.Name = "txtgsisnum"
        Me.txtgsisnum.Size = New System.Drawing.Size(104, 23)
        Me.txtgsisnum.TabIndex = 170
        '
        'txtpibgnum
        '
        Me.txtpibgnum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtpibgnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpibgnum.Location = New System.Drawing.Point(130, 189)
        Me.txtpibgnum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtpibgnum.Multiline = True
        Me.txtpibgnum.Name = "txtpibgnum"
        Me.txtpibgnum.Size = New System.Drawing.Size(104, 23)
        Me.txtpibgnum.TabIndex = 169
        '
        'txttinnum
        '
        Me.txttinnum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txttinnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttinnum.Location = New System.Drawing.Point(22, 188)
        Me.txttinnum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txttinnum.Multiline = True
        Me.txttinnum.Name = "txttinnum"
        Me.txttinnum.Size = New System.Drawing.Size(104, 23)
        Me.txttinnum.TabIndex = 168
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Black
        Me.Label53.Location = New System.Drawing.Point(862, 172)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(78, 16)
        Me.Label53.TabIndex = 167
        Me.Label53.Text = "REMARKS :"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.Black
        Me.Label54.Location = New System.Drawing.Point(739, 173)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(69, 16)
        Me.Label54.TabIndex = 166
        Me.Label54.Text = "LONGPAY"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.Black
        Me.Label55.Location = New System.Drawing.Point(573, 173)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(117, 16)
        Me.Label55.TabIndex = 165
        Me.Label55.Text = "LANDBANK ATM#"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.Black
        Me.Label56.Location = New System.Drawing.Point(464, 172)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(65, 16)
        Me.Label56.TabIndex = 163
        Me.Label56.Text = "BADGE #"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.Black
        Me.Label57.Location = New System.Drawing.Point(345, 171)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(101, 16)
        Me.Label57.TabIndex = 164
        Me.Label57.Text = "PHILHEALTH #"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.Black
        Me.Label58.Location = New System.Drawing.Point(241, 171)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(52, 16)
        Me.Label58.TabIndex = 162
        Me.Label58.Text = "GSIS #"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.Black
        Me.Label59.Location = New System.Drawing.Point(125, 172)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(75, 16)
        Me.Label59.TabIndex = 161
        Me.Label59.Text = "PAGIBIG #"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.Black
        Me.Label60.Location = New System.Drawing.Point(21, 171)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(43, 16)
        Me.Label60.TabIndex = 160
        Me.Label60.Text = "TIN #"
        '
        'dteffectivecon
        '
        Me.dteffectivecon.CustomFormat = "yyyy-MM-dd"
        Me.dteffectivecon.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dteffectivecon.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dteffectivecon.Location = New System.Drawing.Point(827, 142)
        Me.dteffectivecon.Name = "dteffectivecon"
        Me.dteffectivecon.Size = New System.Drawing.Size(142, 22)
        Me.dteffectivecon.TabIndex = 159
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Black
        Me.Label51.Location = New System.Drawing.Point(824, 123)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(154, 16)
        Me.Label51.TabIndex = 158
        Me.Label51.Text = "Effective of Concurrent :"
        '
        'txtauthcondesig
        '
        Me.txtauthcondesig.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtauthcondesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtauthcondesig.Location = New System.Drawing.Point(658, 142)
        Me.txtauthcondesig.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtauthcondesig.Multiline = True
        Me.txtauthcondesig.Name = "txtauthcondesig"
        Me.txtauthcondesig.Size = New System.Drawing.Size(159, 23)
        Me.txtauthcondesig.TabIndex = 157
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Black
        Me.Label50.Location = New System.Drawing.Point(651, 124)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(170, 16)
        Me.Label50.TabIndex = 156
        Me.Label50.Text = "Auth of Concurrent Desig :"
        '
        'txtcondesig
        '
        Me.txtcondesig.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtcondesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcondesig.Location = New System.Drawing.Point(493, 142)
        Me.txtcondesig.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtcondesig.Multiline = True
        Me.txtcondesig.Name = "txtcondesig"
        Me.txtcondesig.Size = New System.Drawing.Size(159, 23)
        Me.txtcondesig.TabIndex = 155
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Black
        Me.Label49.Location = New System.Drawing.Point(491, 124)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(161, 16)
        Me.Label49.TabIndex = 154
        Me.Label49.Text = "Concurrent Designation :"
        '
        'txtdateretire
        '
        Me.txtdateretire.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtdateretire.Enabled = False
        Me.txtdateretire.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdateretire.Location = New System.Drawing.Point(346, 142)
        Me.txtdateretire.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtdateretire.Multiline = True
        Me.txtdateretire.Name = "txtdateretire"
        Me.txtdateretire.Size = New System.Drawing.Size(144, 23)
        Me.txtdateretire.TabIndex = 153
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(344, 124)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 16)
        Me.Label3.TabIndex = 152
        Me.Label3.Text = "Date of Retirement :"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.Black
        Me.Label48.Location = New System.Drawing.Point(243, 126)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(91, 16)
        Me.Label48.TabIndex = 151
        Me.Label48.Text = "Work Status :"
        '
        'dtdolp
        '
        Me.dtdolp.CustomFormat = "yyyy-MM-dd"
        Me.dtdolp.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdolp.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdolp.Location = New System.Drawing.Point(132, 143)
        Me.dtdolp.Name = "dtdolp"
        Me.dtdolp.Size = New System.Drawing.Size(107, 22)
        Me.dtdolp.TabIndex = 150
        '
        'dtdao
        '
        Me.dtdao.CustomFormat = "yyyy-MM-dd"
        Me.dtdao.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdao.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdao.Location = New System.Drawing.Point(19, 143)
        Me.dtdao.Name = "dtdao"
        Me.dtdao.Size = New System.Drawing.Size(112, 22)
        Me.dtdao.TabIndex = 149
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Black
        Me.Label45.Location = New System.Drawing.Point(134, 124)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(51, 16)
        Me.Label45.TabIndex = 148
        Me.Label45.Text = "DOLP :"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Black
        Me.Label47.Location = New System.Drawing.Point(21, 125)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(44, 16)
        Me.Label47.TabIndex = 147
        Me.Label47.Text = "DAO :"
        '
        'txtyrsfiresvc
        '
        Me.txtyrsfiresvc.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtyrsfiresvc.Enabled = False
        Me.txtyrsfiresvc.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyrsfiresvc.Location = New System.Drawing.Point(840, 93)
        Me.txtyrsfiresvc.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtyrsfiresvc.Multiline = True
        Me.txtyrsfiresvc.Name = "txtyrsfiresvc"
        Me.txtyrsfiresvc.Size = New System.Drawing.Size(130, 23)
        Me.txtyrsfiresvc.TabIndex = 146
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Black
        Me.Label44.Location = New System.Drawing.Point(839, 76)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(130, 16)
        Me.Label44.TabIndex = 145
        Me.Label44.Text = "Yrs in Fire Service  :"
        '
        'dtendfs
        '
        Me.dtendfs.CustomFormat = "yyyy-MM-dd"
        Me.dtendfs.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtendfs.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtendfs.Location = New System.Drawing.Point(675, 94)
        Me.dtendfs.Name = "dtendfs"
        Me.dtendfs.Size = New System.Drawing.Size(160, 22)
        Me.dtendfs.TabIndex = 144
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Black
        Me.Label43.Location = New System.Drawing.Point(674, 76)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(161, 16)
        Me.Label43.TabIndex = 143
        Me.Label43.Text = "Date End of Fire Service :"
        '
        'dtdefs
        '
        Me.dtdefs.CustomFormat = "yyyy-MM-dd"
        Me.dtdefs.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdefs.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdefs.Location = New System.Drawing.Point(493, 95)
        Me.dtdefs.Name = "dtdefs"
        Me.dtdefs.Size = New System.Drawing.Size(179, 22)
        Me.dtdefs.TabIndex = 142
        '
        'dtdegs
        '
        Me.dtdegs.CustomFormat = "yyyy-MM-dd"
        Me.dtdegs.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdegs.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtdegs.Location = New System.Drawing.Point(383, 96)
        Me.dtdegs.Name = "dtdegs"
        Me.dtdegs.Size = New System.Drawing.Size(107, 22)
        Me.dtdegs.TabIndex = 141
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Black
        Me.Label41.Location = New System.Drawing.Point(490, 77)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(185, 16)
        Me.Label41.TabIndex = 140
        Me.Label41.Text = "Date Entered of Fire Service :"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(380, 77)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(52, 16)
        Me.Label42.TabIndex = 139
        Me.Label42.Text = "DEGS :"
        '
        'txtyrspridesig
        '
        Me.txtyrspridesig.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtyrspridesig.Enabled = False
        Me.txtyrspridesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyrspridesig.Location = New System.Drawing.Point(242, 96)
        Me.txtyrspridesig.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtyrspridesig.Multiline = True
        Me.txtyrspridesig.Name = "txtyrspridesig"
        Me.txtyrspridesig.Size = New System.Drawing.Size(138, 23)
        Me.txtyrspridesig.TabIndex = 138
        '
        'dteop
        '
        Me.dteop.CustomFormat = "yyyy-MM-dd"
        Me.dteop.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dteop.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dteop.Location = New System.Drawing.Point(132, 97)
        Me.dteop.Name = "dteop"
        Me.dteop.Size = New System.Drawing.Size(107, 22)
        Me.dteop.TabIndex = 137
        '
        'dtseop
        '
        Me.dtseop.CustomFormat = "yyyy-MM-dd"
        Me.dtseop.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtseop.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtseop.Location = New System.Drawing.Point(20, 98)
        Me.dtseop.Name = "dtseop"
        Me.dtseop.Size = New System.Drawing.Size(109, 22)
        Me.dtseop.TabIndex = 136
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(131, 79)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 16)
        Me.Label1.TabIndex = 135
        Me.Label1.Text = "EOP :"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(241, 79)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(139, 16)
        Me.Label36.TabIndex = 134
        Me.Label36.Text = "Yrs of Primary Desig :"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.Black
        Me.Label46.Location = New System.Drawing.Point(17, 79)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(91, 16)
        Me.Label46.TabIndex = 128
        Me.Label46.Text = "Start of EOP :"
        '
        'txtadmin
        '
        Me.txtadmin.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtadmin.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadmin.Location = New System.Drawing.Point(140, 49)
        Me.txtadmin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtadmin.Multiline = True
        Me.txtadmin.Name = "txtadmin"
        Me.txtadmin.Size = New System.Drawing.Size(108, 23)
        Me.txtadmin.TabIndex = 127
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Black
        Me.Label40.Location = New System.Drawing.Point(138, 31)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(54, 16)
        Me.Label40.TabIndex = 126
        Me.Label40.Text = "Admin :"
        '
        'txtapd
        '
        Me.txtapd.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtapd.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtapd.Location = New System.Drawing.Point(830, 45)
        Me.txtapd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtapd.Multiline = True
        Me.txtapd.Name = "txtapd"
        Me.txtapd.Size = New System.Drawing.Size(140, 23)
        Me.txtapd.TabIndex = 125
        '
        'txtpridesig
        '
        Me.txtpridesig.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtpridesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpridesig.Location = New System.Drawing.Point(686, 46)
        Me.txtpridesig.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtpridesig.Multiline = True
        Me.txtpridesig.Name = "txtpridesig"
        Me.txtpridesig.Size = New System.Drawing.Size(136, 23)
        Me.txtpridesig.TabIndex = 124
        '
        'txtitemnum
        '
        Me.txtitemnum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtitemnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtitemnum.Location = New System.Drawing.Point(569, 48)
        Me.txtitemnum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtitemnum.Multiline = True
        Me.txtitemnum.Name = "txtitemnum"
        Me.txtitemnum.Size = New System.Drawing.Size(112, 23)
        Me.txtitemnum.TabIndex = 123
        '
        'txtunitcode
        '
        Me.txtunitcode.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtunitcode.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtunitcode.Location = New System.Drawing.Point(348, 47)
        Me.txtunitcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtunitcode.Multiline = True
        Me.txtunitcode.Name = "txtunitcode"
        Me.txtunitcode.Size = New System.Drawing.Size(108, 23)
        Me.txtunitcode.TabIndex = 122
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Black
        Me.Label52.Location = New System.Drawing.Point(247, 30)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(86, 16)
        Me.Label52.TabIndex = 121
        Me.Label52.Text = "Unit Assign :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(827, 29)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(148, 16)
        Me.Label19.TabIndex = 120
        Me.Label19.Text = "Auth of Primary Desig :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(683, 30)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(139, 16)
        Me.Label18.TabIndex = 119
        Me.Label18.Text = "Primary Designation :"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(572, 30)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(96, 16)
        Me.Label23.TabIndex = 118
        Me.Label23.Text = "Item Number :"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(457, 30)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(47, 16)
        Me.Label37.TabIndex = 117
        Me.Label37.Text = "Rank :"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Black
        Me.Label38.Location = New System.Drawing.Point(346, 29)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(76, 16)
        Me.Label38.TabIndex = 116
        Me.Label38.Text = "Unit Code :"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Black
        Me.Label39.Location = New System.Drawing.Point(17, 31)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(120, 16)
        Me.Label39.TabIndex = 115
        Me.Label39.Text = "Account Number  :"
        '
        'txtaccnum
        '
        Me.txtaccnum.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtaccnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaccnum.Location = New System.Drawing.Point(20, 49)
        Me.txtaccnum.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtaccnum.Multiline = True
        Me.txtaccnum.Name = "txtaccnum"
        Me.txtaccnum.Size = New System.Drawing.Size(117, 23)
        Me.txtaccnum.TabIndex = 103
        '
        'cbosoa
        '
        Me.cbosoa.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cbosoa.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.cbosoa.FormattingEnabled = True
        Me.cbosoa.Items.AddRange(New Object() {"Regular", "Casual"})
        Me.cbosoa.Location = New System.Drawing.Point(242, 142)
        Me.cbosoa.Name = "cbosoa"
        Me.cbosoa.Size = New System.Drawing.Size(100, 24)
        Me.cbosoa.TabIndex = 12
        '
        'rdomale
        '
        Me.rdomale.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.rdomale.AutoSize = True
        Me.rdomale.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdomale.Location = New System.Drawing.Point(32, 27)
        Me.rdomale.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdomale.Name = "rdomale"
        Me.rdomale.Size = New System.Drawing.Size(58, 22)
        Me.rdomale.TabIndex = 6
        Me.rdomale.TabStop = True
        Me.rdomale.Text = "Male"
        Me.rdomale.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(590, 72)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(115, 16)
        Me.Label25.TabIndex = 1
        Me.Label25.Text = "Contact Number :"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(93, 23)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(83, 16)
        Me.Label26.TabIndex = 1
        Me.Label26.Text = "First Name :"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(872, 23)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(87, 16)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "Civil Status :"
        '
        'txtstatus
        '
        Me.txtstatus.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtstatus.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus.FormattingEnabled = True
        Me.txtstatus.Items.AddRange(New Object() {"Married", "Single", "Widow"})
        Me.txtstatus.Location = New System.Drawing.Point(875, 39)
        Me.txtstatus.Name = "txtstatus"
        Me.txtstatus.Size = New System.Drawing.Size(95, 24)
        Me.txtstatus.TabIndex = 2
        Me.txtstatus.Text = "Single"
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(301, 24)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(81, 16)
        Me.Label28.TabIndex = 1
        Me.Label28.Text = "Last Name :"
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(737, 72)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(132, 16)
        Me.Label30.TabIndex = 1
        Me.Label30.Text = "Emergency Number :"
        '
        'Label31
        '
        Me.Label31.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(541, 23)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(95, 16)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "Middle Name :"
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox9.Controls.Add(Me.txtaddress)
        Me.GroupBox9.Controls.Add(Me.cbomunicipality)
        Me.GroupBox9.Controls.Add(Me.txtzipcode)
        Me.GroupBox9.Controls.Add(Me.Label8)
        Me.GroupBox9.Controls.Add(Me.txtprovince)
        Me.GroupBox9.Controls.Add(Me.Label7)
        Me.GroupBox9.Controls.Add(Me.Label6)
        Me.GroupBox9.Controls.Add(Me.txtreligion)
        Me.GroupBox9.Controls.Add(Me.Label5)
        Me.GroupBox9.Controls.Add(Me.Label4)
        Me.GroupBox9.Controls.Add(Me.txtsfxname)
        Me.GroupBox9.Controls.Add(Me.Label2)
        Me.GroupBox9.Controls.Add(Me.txtage)
        Me.GroupBox9.Controls.Add(Me.txtcode)
        Me.GroupBox9.Controls.Add(Me.Label20)
        Me.GroupBox9.Controls.Add(Me.txtbplace)
        Me.GroupBox9.Controls.Add(Me.Label21)
        Me.GroupBox9.Controls.Add(Me.dtpdbirth)
        Me.GroupBox9.Controls.Add(Me.Label22)
        Me.GroupBox9.Controls.Add(Me.txtlname)
        Me.GroupBox9.Controls.Add(Me.txtcontact)
        Me.GroupBox9.Controls.Add(Me.txtfname)
        Me.GroupBox9.Controls.Add(Me.txtmname)
        Me.GroupBox9.Controls.Add(Me.txtemerg)
        Me.GroupBox9.Controls.Add(Me.Label25)
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.Label27)
        Me.GroupBox9.Controls.Add(Me.txtstatus)
        Me.GroupBox9.Controls.Add(Me.Label28)
        Me.GroupBox9.Controls.Add(Me.Label29)
        Me.GroupBox9.Controls.Add(Me.Label30)
        Me.GroupBox9.Controls.Add(Me.Label31)
        Me.GroupBox9.Controls.Add(Me.LblDtNow)
        Me.GroupBox9.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox9.Location = New System.Drawing.Point(148, 53)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox9.Size = New System.Drawing.Size(976, 192)
        Me.GroupBox9.TabIndex = 38
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "PERSONAL INFORMATION"
        '
        'txtaddress
        '
        Me.txtaddress.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtaddress.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaddress.Location = New System.Drawing.Point(20, 143)
        Me.txtaddress.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtaddress.Name = "txtaddress"
        Me.txtaddress.Size = New System.Drawing.Size(274, 35)
        Me.txtaddress.TabIndex = 64
        Me.txtaddress.Text = ""
        '
        'cbomunicipality
        '
        Me.cbomunicipality.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cbomunicipality.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbomunicipality.FormattingEnabled = True
        Me.cbomunicipality.Location = New System.Drawing.Point(304, 142)
        Me.cbomunicipality.Name = "cbomunicipality"
        Me.cbomunicipality.Size = New System.Drawing.Size(146, 24)
        Me.cbomunicipality.TabIndex = 59
        '
        'txtzipcode
        '
        Me.txtzipcode.Enabled = False
        Me.txtzipcode.Font = New System.Drawing.Font("Bookman Old Style", 9.75!)
        Me.txtzipcode.Location = New System.Drawing.Point(634, 142)
        Me.txtzipcode.Name = "txtzipcode"
        Me.txtzipcode.Size = New System.Drawing.Size(94, 23)
        Me.txtzipcode.TabIndex = 58
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(632, 126)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 16)
        Me.Label8.TabIndex = 57
        Me.Label8.Text = "ZipCode :"
        '
        'txtprovince
        '
        Me.txtprovince.Font = New System.Drawing.Font("Bookman Old Style", 9.75!)
        Me.txtprovince.Location = New System.Drawing.Point(457, 142)
        Me.txtprovince.Name = "txtprovince"
        Me.txtprovince.Size = New System.Drawing.Size(171, 23)
        Me.txtprovince.TabIndex = 56
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(454, 126)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 16)
        Me.Label7.TabIndex = 55
        Me.Label7.Text = "Province :"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(303, 125)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 16)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "Municipality :"
        '
        'txtreligion
        '
        Me.txtreligion.Font = New System.Drawing.Font("Bookman Old Style", 9.75!)
        Me.txtreligion.Location = New System.Drawing.Point(496, 90)
        Me.txtreligion.Name = "txtreligion"
        Me.txtreligion.Size = New System.Drawing.Size(95, 23)
        Me.txtreligion.TabIndex = 52
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(494, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 16)
        Me.Label5.TabIndex = 51
        Me.Label5.Text = "Religion :"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(779, 23)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 16)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = "Suffix Name :"
        '
        'txtsfxname
        '
        Me.txtsfxname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtsfxname.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsfxname.FormattingEnabled = True
        Me.txtsfxname.Items.AddRange(New Object() {"JR.", "SR.", "NONE"})
        Me.txtsfxname.Location = New System.Drawing.Point(782, 39)
        Me.txtsfxname.Name = "txtsfxname"
        Me.txtsfxname.Size = New System.Drawing.Size(87, 24)
        Me.txtsfxname.TabIndex = 48
        Me.txtsfxname.Text = "Select"
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(422, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 16)
        Me.Label2.TabIndex = 47
        Me.Label2.Text = "Age:"
        '
        'txtage
        '
        Me.txtage.Enabled = False
        Me.txtage.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtage.Location = New System.Drawing.Point(423, 90)
        Me.txtage.MaxLength = 2
        Me.txtage.Name = "txtage"
        Me.txtage.Size = New System.Drawing.Size(68, 23)
        Me.txtage.TabIndex = 46
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(19, 125)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(226, 16)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = "Address :  (No.& Street) and Barangay"
        '
        'LblDtNow
        '
        Me.LblDtNow.AutoSize = True
        Me.LblDtNow.Font = New System.Drawing.Font("Bookman Old Style", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblDtNow.Location = New System.Drawing.Point(24, 90)
        Me.LblDtNow.Name = "LblDtNow"
        Me.LblDtNow.Size = New System.Drawing.Size(55, 15)
        Me.LblDtNow.TabIndex = 63
        Me.LblDtNow.Text = "Example"
        '
        'emptitle
        '
        Me.emptitle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.emptitle.AutoSize = True
        Me.emptitle.Font = New System.Drawing.Font("Century", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.emptitle.ForeColor = System.Drawing.Color.DarkRed
        Me.emptitle.Location = New System.Drawing.Point(391, 2)
        Me.emptitle.Name = "emptitle"
        Me.emptitle.Size = New System.Drawing.Size(350, 38)
        Me.emptitle.TabIndex = 37
        Me.emptitle.Text = "ADD NEW PROFILE"
        '
        'btnSave
        '
        Me.btnSave.Activecolor = System.Drawing.Color.DarkRed
        Me.btnSave.BackColor = System.Drawing.Color.Maroon
        Me.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.btnSave.BorderRadius = 0
        Me.btnSave.ButtonText = "SAVE"
        Me.btnSave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSave.DisabledColor = System.Drawing.Color.Gray
        Me.btnSave.Font = New System.Drawing.Font("Bookman Old Style", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Iconcolor = System.Drawing.Color.Transparent
        Me.btnSave.Iconimage = CType(resources.GetObject("btnSave.Iconimage"), System.Drawing.Image)
        Me.btnSave.Iconimage_right = Nothing
        Me.btnSave.Iconimage_right_Selected = Nothing
        Me.btnSave.Iconimage_Selected = Nothing
        Me.btnSave.IconMarginLeft = 0
        Me.btnSave.IconMarginRight = 0
        Me.btnSave.IconRightVisible = True
        Me.btnSave.IconRightZoom = 0R
        Me.btnSave.IconVisible = True
        Me.btnSave.IconZoom = 40.0R
        Me.btnSave.IsTab = False
        Me.btnSave.Location = New System.Drawing.Point(850, 609)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Normalcolor = System.Drawing.Color.Maroon
        Me.btnSave.OnHovercolor = System.Drawing.Color.DarkRed
        Me.btnSave.OnHoverTextColor = System.Drawing.Color.White
        Me.btnSave.selected = False
        Me.btnSave.Size = New System.Drawing.Size(125, 35)
        Me.btnSave.TabIndex = 40
        Me.btnSave.Text = "SAVE"
        Me.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnSave.Textcolor = System.Drawing.Color.White
        Me.btnSave.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btnNew
        '
        Me.btnNew.Activecolor = System.Drawing.Color.OrangeRed
        Me.btnNew.BackColor = System.Drawing.Color.OrangeRed
        Me.btnNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnNew.BorderRadius = 0
        Me.btnNew.ButtonText = "NEW"
        Me.btnNew.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnNew.DisabledColor = System.Drawing.Color.Gray
        Me.btnNew.Iconcolor = System.Drawing.Color.Transparent
        Me.btnNew.Iconimage = CType(resources.GetObject("btnNew.Iconimage"), System.Drawing.Image)
        Me.btnNew.Iconimage_right = Nothing
        Me.btnNew.Iconimage_right_Selected = Nothing
        Me.btnNew.Iconimage_Selected = Nothing
        Me.btnNew.IconMarginLeft = 0
        Me.btnNew.IconMarginRight = 0
        Me.btnNew.IconRightVisible = True
        Me.btnNew.IconRightZoom = 0R
        Me.btnNew.IconVisible = True
        Me.btnNew.IconZoom = 40.0R
        Me.btnNew.IsTab = False
        Me.btnNew.Location = New System.Drawing.Point(1001, 609)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Normalcolor = System.Drawing.Color.OrangeRed
        Me.btnNew.OnHovercolor = System.Drawing.Color.OrangeRed
        Me.btnNew.OnHoverTextColor = System.Drawing.Color.White
        Me.btnNew.selected = False
        Me.btnNew.Size = New System.Drawing.Size(125, 35)
        Me.btnNew.TabIndex = 41
        Me.btnNew.Text = "NEW"
        Me.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btnNew.Textcolor = System.Drawing.Color.White
        Me.btnNew.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'txtPhoto
        '
        Me.txtPhoto.Location = New System.Drawing.Point(13, 140)
        Me.txtPhoto.Name = "txtPhoto"
        Me.txtPhoto.Size = New System.Drawing.Size(100, 20)
        Me.txtPhoto.TabIndex = 60
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Location = New System.Drawing.Point(7, 57)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(135, 135)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 59
        Me.PictureBox1.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.rdomale)
        Me.GroupBox2.Controls.Add(Me.rdofemale)
        Me.GroupBox2.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(7, 198)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(135, 100)
        Me.GroupBox2.TabIndex = 62
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Gender"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.txtcrs)
        Me.GroupBox1.Controls.Add(Me.cbohigheli)
        Me.GroupBox1.Controls.Add(Me.txtothereli)
        Me.GroupBox1.Controls.Add(Me.txtdspecialtrain)
        Me.GroupBox1.Controls.Add(Me.txtspecialtrain)
        Me.GroupBox1.Controls.Add(Me.txtdmantrain)
        Me.GroupBox1.Controls.Add(Me.txtdoccrs)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label35)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label24)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.cbolvleli)
        Me.GroupBox1.Controls.Add(Me.txtmascrs)
        Me.GroupBox1.Controls.Add(Me.txtmaslvl)
        Me.GroupBox1.Controls.Add(Me.txtdoclvl)
        Me.GroupBox1.Controls.Add(Me.cbohighmantrain)
        Me.GroupBox1.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox1.Location = New System.Drawing.Point(148, 249)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(976, 129)
        Me.GroupBox1.TabIndex = 59
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "EDUCATION ATTAINMENT"
        '
        'txtcrs
        '
        Me.txtcrs.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtcrs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcrs.Location = New System.Drawing.Point(19, 45)
        Me.txtcrs.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtcrs.Multiline = True
        Me.txtcrs.Name = "txtcrs"
        Me.txtcrs.Size = New System.Drawing.Size(149, 23)
        Me.txtcrs.TabIndex = 102
        '
        'cbohigheli
        '
        Me.cbohigheli.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cbohigheli.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbohigheli.FormattingEnabled = True
        Me.cbohigheli.Location = New System.Drawing.Point(703, 42)
        Me.cbohigheli.Name = "cbohigheli"
        Me.cbohigheli.Size = New System.Drawing.Size(125, 24)
        Me.cbohigheli.TabIndex = 101
        Me.cbohigheli.Text = "Select"
        '
        'txtothereli
        '
        Me.txtothereli.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtothereli.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtothereli.Location = New System.Drawing.Point(805, 91)
        Me.txtothereli.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtothereli.Multiline = True
        Me.txtothereli.Name = "txtothereli"
        Me.txtothereli.Size = New System.Drawing.Size(164, 23)
        Me.txtothereli.TabIndex = 100
        '
        'txtdspecialtrain
        '
        Me.txtdspecialtrain.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtdspecialtrain.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdspecialtrain.Location = New System.Drawing.Point(593, 91)
        Me.txtdspecialtrain.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtdspecialtrain.Multiline = True
        Me.txtdspecialtrain.Name = "txtdspecialtrain"
        Me.txtdspecialtrain.Size = New System.Drawing.Size(201, 23)
        Me.txtdspecialtrain.TabIndex = 99
        '
        'txtspecialtrain
        '
        Me.txtspecialtrain.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtspecialtrain.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtspecialtrain.Location = New System.Drawing.Point(463, 91)
        Me.txtspecialtrain.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtspecialtrain.Multiline = True
        Me.txtspecialtrain.Name = "txtspecialtrain"
        Me.txtspecialtrain.Size = New System.Drawing.Size(124, 23)
        Me.txtspecialtrain.TabIndex = 98
        '
        'txtdmantrain
        '
        Me.txtdmantrain.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtdmantrain.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdmantrain.Location = New System.Drawing.Point(255, 92)
        Me.txtdmantrain.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtdmantrain.Multiline = True
        Me.txtdmantrain.Name = "txtdmantrain"
        Me.txtdmantrain.Size = New System.Drawing.Size(202, 23)
        Me.txtdmantrain.TabIndex = 97
        '
        'txtdoccrs
        '
        Me.txtdoccrs.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtdoccrs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdoccrs.Location = New System.Drawing.Point(566, 44)
        Me.txtdoccrs.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtdoccrs.Multiline = True
        Me.txtdoccrs.Name = "txtdoccrs"
        Me.txtdoccrs.Size = New System.Drawing.Size(131, 23)
        Me.txtdoccrs.TabIndex = 95
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(801, 74)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(111, 16)
        Me.Label32.TabIndex = 94
        Me.Label32.Text = "Other Eligibility :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(586, 74)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(209, 16)
        Me.Label9.TabIndex = 93
        Me.Label9.Text = "Duration of Specialized Training :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(451, 74)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(129, 16)
        Me.Label10.TabIndex = 92
        Me.Label10.Text = "Specilized Training :"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(235, 72)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(205, 16)
        Me.Label35.TabIndex = 91
        Me.Label35.Text = "Duration of Mandatory Training :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(17, 72)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(183, 16)
        Me.Label11.TabIndex = 90
        Me.Label11.Text = "Highest Mandatory Training :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(804, 25)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(122, 16)
        Me.Label24.TabIndex = 88
        Me.Label24.Text = "Level of Eligibility :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(675, 23)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(123, 16)
        Me.Label12.TabIndex = 89
        Me.Label12.Text = "Highest Eligibility :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(538, 25)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(122, 16)
        Me.Label13.TabIndex = 87
        Me.Label13.Text = "Doctorate Course :"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(425, 25)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(110, 16)
        Me.Label14.TabIndex = 86
        Me.Label14.Text = "Doctorate Level :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(266, 25)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(116, 16)
        Me.Label15.TabIndex = 85
        Me.Label15.Text = "Masteral Course :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(146, 25)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(99, 16)
        Me.Label16.TabIndex = 84
        Me.Label16.Text = "Mastery Level :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(17, 25)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(109, 16)
        Me.Label17.TabIndex = 83
        Me.Label17.Text = "Tertiary Course :"
        '
        'cbolvleli
        '
        Me.cbolvleli.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cbolvleli.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbolvleli.FormattingEnabled = True
        Me.cbolvleli.Location = New System.Drawing.Point(832, 42)
        Me.cbolvleli.Name = "cbolvleli"
        Me.cbolvleli.Size = New System.Drawing.Size(138, 24)
        Me.cbolvleli.TabIndex = 48
        Me.cbolvleli.Text = "Select"
        '
        'txtmascrs
        '
        Me.txtmascrs.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtmascrs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmascrs.Location = New System.Drawing.Point(294, 45)
        Me.txtmascrs.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtmascrs.Multiline = True
        Me.txtmascrs.Name = "txtmascrs"
        Me.txtmascrs.Size = New System.Drawing.Size(149, 23)
        Me.txtmascrs.TabIndex = 0
        '
        'txtmaslvl
        '
        Me.txtmaslvl.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtmaslvl.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmaslvl.Location = New System.Drawing.Point(174, 45)
        Me.txtmaslvl.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtmaslvl.Multiline = True
        Me.txtmaslvl.Name = "txtmaslvl"
        Me.txtmaslvl.Size = New System.Drawing.Size(113, 23)
        Me.txtmaslvl.TabIndex = 0
        '
        'txtdoclvl
        '
        Me.txtdoclvl.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtdoclvl.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdoclvl.Location = New System.Drawing.Point(453, 45)
        Me.txtdoclvl.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtdoclvl.Multiline = True
        Me.txtdoclvl.Name = "txtdoclvl"
        Me.txtdoclvl.Size = New System.Drawing.Size(107, 23)
        Me.txtdoclvl.TabIndex = 0
        '
        'cbohighmantrain
        '
        Me.cbohighmantrain.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cbohighmantrain.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbohighmantrain.FormattingEnabled = True
        Me.cbohighmantrain.Items.AddRange(New Object() {"FBRC", "FAIIC", "FPSC", "JLC", "SLC", "FOCC", "FOBC", "FOAC", "FOSEC"})
        Me.cbohighmantrain.Location = New System.Drawing.Point(19, 91)
        Me.cbohighmantrain.Name = "cbohighmantrain"
        Me.cbohighmantrain.Size = New System.Drawing.Size(230, 24)
        Me.cbohighmantrain.TabIndex = 2
        Me.cbohighmantrain.Text = "Select"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'FormProfiles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtPhoto)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.GroupBox9)
        Me.Controls.Add(Me.emptitle)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Name = "FormProfiles"
        Me.Size = New System.Drawing.Size(1138, 660)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtcode As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtbplace As RichTextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents dtpdbirth As DateTimePicker
    Friend WithEvents Label22 As Label
    Friend WithEvents txtlname As TextBox
    Friend WithEvents txtcontact As TextBox
    Friend WithEvents txtfname As TextBox
    Friend WithEvents txtmname As TextBox
    Friend WithEvents rdofemale As RadioButton
    Friend WithEvents txtemerg As TextBox
    Friend WithEvents txtrank As ComboBox
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents cbosoa As ComboBox
    Friend WithEvents rdomale As RadioButton
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents txtstatus As ComboBox
    Friend WithEvents Label28 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Label29 As Label
    Friend WithEvents emptitle As Label
    Friend WithEvents btnSave As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btnNew As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents txtPhoto As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents Label2 As Label
    Friend WithEvents txtage As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtsfxname As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtreligion As TextBox
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents Label6 As Label
    Friend WithEvents txtzipcode As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtprovince As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents cbohigheli As ComboBox
    Friend WithEvents txtothereli As TextBox
    Friend WithEvents txtdspecialtrain As TextBox
    Friend WithEvents txtspecialtrain As TextBox
    Friend WithEvents txtdmantrain As TextBox
    Friend WithEvents txtdoccrs As TextBox
    Friend WithEvents Label32 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents cbolvleli As ComboBox
    Friend WithEvents txtmascrs As TextBox
    Friend WithEvents txtmaslvl As TextBox
    Friend WithEvents txtdoclvl As TextBox
    Friend WithEvents cbohighmantrain As ComboBox
    Friend WithEvents txtcrs As TextBox
    Friend WithEvents cbomunicipality As ComboBox
    Friend WithEvents txtaccnum As TextBox
    Friend WithEvents txtadmin As TextBox
    Friend WithEvents Label40 As Label
    Friend WithEvents txtapd As TextBox
    Friend WithEvents txtpridesig As TextBox
    Friend WithEvents txtitemnum As TextBox
    Friend WithEvents txtunitcode As TextBox
    Friend WithEvents Label52 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents txtyrsfiresvc As TextBox
    Friend WithEvents Label44 As Label
    Friend WithEvents dtendfs As DateTimePicker
    Friend WithEvents Label43 As Label
    Friend WithEvents dtdefs As DateTimePicker
    Friend WithEvents dtdegs As DateTimePicker
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents txtyrspridesig As TextBox
    Friend WithEvents dteop As DateTimePicker
    Friend WithEvents dtseop As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents dteffectivecon As DateTimePicker
    Friend WithEvents Label51 As Label
    Friend WithEvents txtauthcondesig As TextBox
    Friend WithEvents Label50 As Label
    Friend WithEvents txtcondesig As TextBox
    Friend WithEvents Label49 As Label
    Friend WithEvents txtdateretire As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents dtdolp As DateTimePicker
    Friend WithEvents dtdao As DateTimePicker
    Friend WithEvents Label45 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents txtremarks As TextBox
    Friend WithEvents txtlngpaynum As TextBox
    Friend WithEvents txtlndbnknum As TextBox
    Friend WithEvents txtbadgenum As TextBox
    Friend WithEvents txtphlthnum As TextBox
    Friend WithEvents txtgsisnum As TextBox
    Friend WithEvents txtpibgnum As TextBox
    Friend WithEvents txttinnum As TextBox
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents LblDtNow As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents cbounitassign As ComboBox
    Friend WithEvents txtaddress As RichTextBox
End Class
