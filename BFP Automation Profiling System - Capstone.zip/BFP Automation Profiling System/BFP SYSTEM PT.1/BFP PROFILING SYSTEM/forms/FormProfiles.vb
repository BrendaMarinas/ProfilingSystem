﻿Imports System.IO
Public Class FormProfiles

    Public empid As String = ""
    Private Sub frmEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        fillcbo("SELECT * FROM `tblsettings` WHERE  `FORTHE`='RANK'", txtrank)

        fillcbo("SELECT `UNIT_ASSIGN` FROM `tblunitassign`", cbounitassign)

        cleartext(GroupBox9)
        cleartext(GroupBox10)
        cleartext(GroupBox2)
        cleartext(GroupBox1)

        With cbohigheli
            .Items.Add("RA 1080")
            .Items.Add("CS Professional")
            .Items.Add("CS FOE")
        End With

        With cbomunicipality
            .Items.Add("Agno")
            .Items.Add("Aguilar")
            .Items.Add("Bugallon")
            .Items.Add("Binmaley")
            .Items.Add("Calasiao")
            .Items.Add("Dagupan")
            .Items.Add("Lingayen")
            .Items.Add("Manaoag")
            .Items.Add("San Carlos")
            .Items.Add("Urdaneta")
        End With

        PictureBox1.ImageLocation = Application.StartupPath & "\Photo\no_image.png"


        Try

            sql = "SELECT * FROM `employee` e, `employee_workinfo` ew " _
                 & " WHERE e.`EMPID`=ew.`EMPID` AND e.EMPID ='" & txtcode.Text & "'"
            reloadtxt(sql)

            If dt.Rows.Count > 0 Then

                txtaccnum.Text = dt.Rows(0).Item("ACCOUNT_NUM")
                txtrank.Text = dt.Rows(0).Item("RANK")
                txtfname.Text = dt.Rows(0).Item("EMP_FNAME")
                txtlname.Text = dt.Rows(0).Item("EMP_LNAME")
                txtmname.Text = dt.Rows(0).Item("EMP_MNAME")
                txtaddress.Text = dt.Rows(0).Item("ADDRESS")
                txtcontact.Text = dt.Rows(0).Item("CONTACT")
                txtstatus.Text = dt.Rows(0).Item("STATUS")
                dtpdbirth.Value = dt.Rows(0).Item("BIRTH_DATE")
                txtbplace.Text = dt.Rows(0).Item("BIRTH_PLACE")
                If dt.Rows(0).Item("EMP_SEX") = "MALE" Then
                    rdomale.Checked = True
                Else
                    rdofemale.Checked = True
                End If
                txtage.Text = dt.Rows(0).Item("EMP_AGE")
                txtemerg.Text = dt.Rows(0).Item("EMERG_CONTACT")
                txtsfxname.Text = dt.Rows(0).Item("EMP_SFXNAME")
                txtreligion.Text = dt.Rows(0).Item("RELIGION")
                cbomunicipality.Text = dt.Rows(0).Item("MUNICIPALITY")
                txtzipcode.Text = dt.Rows(0).Item("ZIPCODE")
                txtprovince.Text = dt.Rows(0).Item("PROVINCE")
                txtcrs.Text = dt.Rows(0).Item("TERTIARY_CRS")
                txtmascrs.Text = dt.Rows(0).Item("MASTERAL_CRS")
                txtmaslvl.Text = dt.Rows(0).Item("MASTERAL_LVL")
                txtdoccrs.Text = dt.Rows(0).Item("DOCTORATE_CRS")
                txtdoclvl.Text = dt.Rows(0).Item("DOCTORATE_LVL")
                cbohigheli.Text = dt.Rows(0).Item("HIGH_ELI")
                cbolvleli.Text = dt.Rows(0).Item("LVL_ELI")
                txtothereli.Text = dt.Rows(0).Item("OTHER_ELI")
                cbohighmantrain.Text = dt.Rows(0).Item("HIGH_MANTRAIN")
                txtdmantrain.Text = dt.Rows(0).Item("DTN_MANTRAIN")
                txtspecialtrain.Text = dt.Rows(0).Item("SPL_TRAIN")
                txtdspecialtrain.Text = dt.Rows(0).Item("DTN_SPLTRAIN")
                cbounitassign.Text = dt.Rows(0).Item("UNIT_ASSIGN")
                cbosoa.Text = dt.Rows(0).Item("STATUS_APPOINTMENT")
                txtadmin.Text = dt.Rows(0).Item("ADMIN")
                txtunitcode.Text = dt.Rows(0).Item("UNITCODE")
                txtitemnum.Text = dt.Rows(0).Item("ITEM_NUMBER")
                txtpridesig.Text = dt.Rows(0).Item("PRIMARY_DESIG")
                txtapd.Text = dt.Rows(0).Item("AUTH_PRIDESIG")
                dteop.Value = dt.Rows(0).Item("EFFECTIVE_PRIMARY")
                txtyrspridesig.Text = dt.Rows(0).Item("YRS_PRIMARY")
                dtdegs.Value = dt.Rows(0).Item("DEGS")
                dtdefs.Value = dt.Rows(0).Item("DEFS")
                txtyrsfiresvc.Text = dt.Rows(0).Item("YRS_FIRESERVICE")
                dtdao.Value = dt.Rows(0).Item("DAO")
                dtdolp.Value = dt.Rows(0).Item("DOLP")
                txtdateretire.Text = dt.Rows(0).Item("DATE_RETIREMENT")
                txtcondesig.Text = dt.Rows(0).Item("CON_DESIG")
                txtauthcondesig.Text = dt.Rows(0).Item("AUTH_CONDESIG")
                dteffectivecon.Value = dt.Rows(0).Item("EFFECTIVE_CON")
                txttinnum.Text = dt.Rows(0).Item("TIN_num")
                txtpibgnum.Text = dt.Rows(0).Item("PAGIBIG_num")
                txtgsisnum.Text = dt.Rows(0).Item("GSIS_num")
                txtphlthnum.Text = dt.Rows(0).Item("PHILHEALTH_num")
                txtbadgenum.Text = dt.Rows(0).Item("BADGE_num")
                txtlndbnknum.Text = dt.Rows(0).Item("LANDBANK_num")
                txtlngpaynum.Text = dt.Rows(0).Item("LONGPAY")
                txtremarks.Text = dt.Rows(0).Item("REMARKS")
                'Else
                '    cleartext(GroupBox10)
                '    cleartext(GroupBox9)
            Else

                loadautonumber("employee", txtcode)
            End If
            'aloadautonumber("employee", txtcode)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        'If empid = "" Then
        '    loadautonumber("employee", txtcode)
        'Else
        '    txtcode.Text = empid
        'End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            'loadautonumber("employee", txtcode)
            For Each ctrl As Control In GroupBox9.Controls
                If ctrl.GetType Is GetType(TextBox) Then
                    If ctrl.Text = "" Then
                        MsgBox("One of the box is empty. It needed to be filled up.", MsgBoxStyle.Exclamation)
                        Return
                    End If
                End If
                If ctrl.GetType Is GetType(ComboBox) Then
                    If ctrl.Text = "----Select-----" Then
                        MsgBox("You have to set the correct information.", MsgBoxStyle.Exclamation)
                        Return
                    End If
                End If
            Next

            For Each ctrl As Control In GroupBox10.Controls
                If ctrl.GetType Is GetType(ComboBox) Then
                    If ctrl.Text = "----Select-----" Then
                        MsgBox("You have to set the correct information.", MsgBoxStyle.Exclamation)
                        Return
                    End If
                End If

                If ctrl.GetType Is GetType(TextBox) Then
                    If ctrl.Text = "" Then
                        MsgBox("One of the box is empty. It needs to be filled up.", MsgBoxStyle.Exclamation)
                        Return
                    End If
                End If
            Next

            Dim bdate As Integer = Math.Round(DateDiff(DateInterval.DayOfYear, dtpdbirth.Value, Now) / 12 / 31)
            If bdate < 18 Then
                MsgBox("Invalid birth of date.", MsgBoxStyle.Exclamation)
                Exit Sub
            End If


            '---------------------------------------------------------
            Dim rdo As String = ""
            sql = "SELECT * FROM `employee` e, `employee_workinfo` ew " _
                & " WHERE e.`EMPID`=ew.`EMPID` AND e.EMPID ='" & txtcode.Text & "'"
            reloadtxt(sql)
            If dt.Rows.Count > 0 Then
                '-------------------update
                If rdomale.Checked = True Then
                    rdo = "Male"
                Else
                    rdo = "Female"
                End If

                sql = "UPDATE `employee_workinfo` SET  `ACCOUNT_NUM`='" & txtaccnum.Text &
                                 "', `RANK`='" & txtrank.Text &
                                 "', `UNIT_ASSIGN`='" & cbounitassign.Text & "', `STATUS_APPOINTMENT`='" & cbosoa.Text &
                                 "', `ADMIN`='" & txtadmin.Text & "', `UNITCODE`='" & txtunitcode.Text &
                                 "', `ITEM_NUMBER`='" & txtitemnum.Text & "', `PRIMARY_DESIG`='" & txtpridesig.Text & "', `AUTH_PRIDESIG`='" & txtapd.Text &
                                 "', `EFFECTIVE_PRIMARY`='" & Format(dteop.Value, "yyyy-MM-dd") & "', `YRS_PRIMARY`='" & txtyrspridesig.Text &
                                 "', `DEGS`='" & Format(dtdegs.Value, "yyyy-MM-dd") & "', `DEFS`='" & Format(dtdefs.Value, "yyyy-MM-dd") &
                                 "',`YRS_FIRESERVICE`='" & txtyrsfiresvc.Text &
                                 "', `DAO`='" & Format(dtdao.Value, "yyyy-MM-dd") & "', `DOLP`='" & Format(dtdolp.Value, "yyyy-MM-dd") &
                                 "',`DATE_RETIREMENT`='" & txtdateretire.Text & "',`CON_DESIG`='" & txtcondesig.Text & "',`AUTH_CONDESIG`='" & txtauthcondesig.Text &
                                 "',`EFFECTIVE_CON`='" & Format(dteffectivecon.Value, "yyyy-MM-dd") &
                                 "', `TIN_num`='" & txttinnum.Text & "', `PAGIBIG_num`='" & txtpibgnum.Text & "', `GSIS_num`='" & txtgsisnum.Text &
                                 "', `PHILHEALTH_num`='" & txtphlthnum.Text & "', `BADGE_num`='" & txtbadgenum.Text & "', `LANDBANK_num`='" & txtlndbnknum.Text &
                                 "', `LONGPAY`='" & txtlngpaynum.Text &
                                 "',`REMARKS`='" & txtremarks.Text & "' WHERE `EMPID`='" & txtcode.Text & "'"
                createNoMsg(sql)

                sql = "UPDATE `employee` SET  `EMP_FNAME`='" & txtfname.Text &
                "', `EMP_LNAME`='" & txtlname.Text & "', `EMP_MNAME`='" & txtmname.Text &
                "', `ADDRESS`='" & txtaddress.Text & "', `CONTACT`='" & txtcontact.Text & "', `STATUS`='" & txtstatus.Text &
                "', `BIRTH_DATE`='" & Format(dtpdbirth.Value, "yyyy-MM-dd") & "', `BIRTH_PLACE`='" & txtbplace.Text & "', `EMP_AGE`='" & txtage.Text & "', `EMP_SEX`='" & rdo &
                "' , `EMERG_CONTACT`='" & txtemerg.Text & "' , `EMP_SFXNAME`='" & txtsfxname.Text & "' ,`RELIGION`='" & txtreligion.Text &
                "' , `MUNICIPALITY`='" & cbomunicipality.Text & "' , `ZIPCODE`='" & txtzipcode.Text & "' , `PROVINCE`='" & txtprovince.Text &
                "' , `TERTIARY_CRS`='" & txtcrs.Text & "' , `MASTERAL_CRS`='" & txtmaslvl.Text & "' , `MASTERAL_LVL`='" & txtmaslvl.Text &
                "' , `DOCTORATE_CRS`='" & txtdoccrs.Text & "' , `DOCTORATE_LVL`='" & txtdoclvl.Text & "' , `HIGH_ELI`='" & cbohigheli.Text & "' , `LVL_ELI`='" & cbolvleli.Text &
                "' , `OTHER_ELI`='" & txtothereli.Text & "' , `HIGH_MANTRAIN`='" & cbohighmantrain.Text & "' , `DTN_MANTRAIN`='" & txtdmantrain.Text &
                "' , `SPL_TRAIN`='" & txtspecialtrain.Text & "' , `DTN_SPLTRAIN`='" & txtdspecialtrain.Text &
                "',BFPEMPIMAGE = '" & Path.GetFileName(PictureBox1.ImageLocation) & "'  WHERE `EMPID`='" & txtcode.Text & "'"

                updates(sql, txtlname.Text)



                '--------------end update
            Else
                '------------------insert
                If rdomale.Checked = True Then
                    rdo = "MALE"
                Else
                    rdo = "FEMALE"
                End If
                sql = "INSERT INTO `employee_workinfo` (`EMPID`, `ACCOUNT_NUM`, `RANK`,UNIT_ASSIGN,STATUS_APPOINTMENT , `ADMIN`, `UNITCODE`" &
                ", `ITEM_NUMBER`, `PRIMARY_DESIG`, `AUTH_PRIDESIG`, `EFFECTIVE_PRIMARY`, `YRS_PRIMARY`, `DEGS`, `DEFS`, `YRS_FIRESERVICE`" &
                ", `DAO`, `DOLP`, `DATE_RETIREMENT`, `CON_DESIG`, `AUTH_CONDESIG`, `EFFECTIVE_CON`" &
                ", `TIN_num`, `PAGIBIG_num`, `GSIS_num`, `PHILHEALTH_num`, `BADGE_num`, `LANDBANK_num`, `LONGPAY`, `REMARKS`)" &
                        " VALUES " &
                "('" & txtcode.Text & "','" & txtaccnum.Text & "','" & txtrank.Text &
                "','" & cbounitassign.Text & "','" & cbosoa.Text &
                "','" & txtadmin.Text & "','" & txtunitcode.Text &
                "','" & txtitemnum.Text & "','" & txtpridesig.Text & "','" & txtapd.Text &
                "','" & Format(dteop.Value, "yyyy-MM-dd") & "','" & txtyrspridesig.Text & "','" & Format(dtdegs.Value, "yyyy-MM-dd") &
                "','" & Format(dtdefs.Value, "yyyy-MM-dd") & "','" & txtyrsfiresvc.Text &
                "','" & Format(dtdao.Value, "yyyy-MM-dd") & "','" & Format(dtdolp.Value, "yyyy-MM-dd") & "','" & txtdateretire.Text & "','" & txtcondesig.Text &
                "','" & txtauthcondesig.Text & "','" & Format(dteffectivecon.Value, "yyyy-MM-dd") &
                "','" & txttinnum.Text & "','" & txtpibgnum.Text & "','" & txtgsisnum.Text & "','" & txtphlthnum.Text &
                "','" & txtbadgenum.Text & "','" & txtlndbnknum.Text &
                "','" & txtlngpaynum.Text & "','" & txtremarks.Text & "')"
                createNoMsg(sql)

                '------------------------------------------------------------------------------
                sql = "INSERT INTO `employee` (`EMPID`, `EMP_FNAME`, `EMP_LNAME`, `EMP_MNAME`" &
                ", `ADDRESS`, `CONTACT`, `STATUS`, `BIRTH_DATE`, `BIRTH_PLACE`, `EMP_SEX`" &
                ", `EMP_AGE`, `EMERG_CONTACT`, `EMP_SFXNAME`, `RELIGION`, `MUNICIPALITY`,`ZIPCODE`, `PROVINCE`" &
                ", `TERTIARY_CRS`, `MASTERAL_CRS`, `MASTERAL_LVL`, `DOCTORATE_CRS`, `DOCTORATE_LVL`, `HIGH_ELI`" &
                ", `LVL_ELI`, `OTHER_ELI`, `HIGH_MANTRAIN`, `DTN_MANTRAIN`, `SPL_TRAIN`, `DTN_SPLTRAIN`" &
                ", `BFPEMPIMAGE`,`RECORDENTRY`)" &
                "VALUES " &
                "('" & txtcode.Text & "','" & txtfname.Text & "','" & txtlname.Text &
                "','" & txtmname.Text & "','" & txtaddress.Text & "','" & txtcontact.Text & "','" & txtstatus.Text &
                "','" & Format(dtpdbirth.Value, "yyyy-MM-dd") & "','" & txtbplace.Text & "','" & rdo & "','" & txtage.Text & "','" & txtemerg.Text &
                "','" & txtsfxname.Text & "','" & txtreligion.Text & "','" & cbomunicipality.Text & "','" & txtzipcode.Text & "','" & txtprovince.Text &
                "','" & txtcrs.Text & "','" & txtmascrs.Text & "','" & txtmaslvl.Text & "','" & txtdoccrs.Text & "','" & txtdoclvl.Text &
                "','" & cbohigheli.Text & "','" & cbolvleli.Text & "','" & txtothereli.Text & "','" & cbohighmantrain.Text & "','" & txtdmantrain.Text &
                "','" & txtspecialtrain.Text & "','" & txtdspecialtrain.Text &
                "','" & Path.GetFileName(PictureBox1.ImageLocation) & "',10)"
                create(sql, txtfname.Text & " " & txtlname.Text)
                ''-----------------------------------------------z
                sql = "INSERT INTO `tbldateentry`  (`EMPID`, `DATE_ENTRY`)" _
                & " VALUES ('" & txtcode.Text & "','" & LblDtNow.Text & "')"
                createNoMsg(sql)
                '--------------------------------------------------
                updateautonumber("employee")

                cleartext(GroupBox9)
                cleartext(GroupBox10)
                cleartext(GroupBox2)
                cleartext(GroupBox1)
                PictureBox1.ImageLocation = Application.StartupPath & "\Photo\no_image.png"
                loadautonumber("employee", txtcode)
                emptitle.Text = "ADD NEW PROFILE"
                '---------------end insert
            End If


        Catch ex As Exception
            MsgBox(ex.Message & " btnempsave_Click", MsgBoxStyle.Exclamation)
        End Try
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        cleartext(GroupBox9)
        cleartext(GroupBox10)
        cleartext(GroupBox2)
        cleartext(GroupBox1)
        PictureBox1.ImageLocation = Application.StartupPath & "\Photo\no_image.png"
        loadautonumber("employee", txtcode)
        emptitle.Text = "ADD NEW PROFILE"
    End Sub

    Private Sub dtseop_ValueChanged(sender As Object, e As EventArgs) Handles dtseop.ValueChanged

        Dim startdate As DateTime = dtseop.Value
        Dim enddate As DateTime = dteop.Value
        Dim years As Int64 = 365
        Dim months As Int64 = 30
        Dim ts As TimeSpan = enddate.Subtract(startdate)
        txtyrspridesig.Text = (Convert.ToInt32(ts.TotalDays) & " Days " & "" & Math.Round(Convert.ToInt32(ts.TotalDays) / years) & " Years " & Math.Round(Convert.ToInt32(ts.TotalDays) / months) & " Months ")

    End Sub

    Private Sub dtdefs_ValueChanged(sender As Object, e As EventArgs) Handles dtdefs.ValueChanged

        Dim startdate As DateTime = dtdefs.Value
        Dim enddate As DateTime = dtendfs.Value
        Dim years As Int64 = 365
        Dim months As Int64 = 30
        Dim ts As TimeSpan = enddate.Subtract(startdate)
        txtyrsfiresvc.Text = (Convert.ToInt32(ts.TotalDays) & " Days " & "" & Math.Round(Convert.ToInt32(ts.TotalDays) / years) & " Years " & Math.Round(Convert.ToInt32(ts.TotalDays) / months) & " Months ")

    End Sub

    Private Sub dtpdbirth_ValueChanged(sender As Object, e As EventArgs) Handles dtpdbirth.ValueChanged
        Dim f_date As Date = dtpdbirth.Value
        Dim MyRetireDay As Date = f_date.AddYears(56)
        Dim strDate As String = MyRetireDay.ToString("MMM/dd/yyyy")
        Dim s_date As Date = Now
        Dim age As Integer

        age = DateDiff(DateInterval.Year, f_date, s_date)

        txtage.Text = age
        txtdateretire.Text = Convert.ToString(MyRetireDay)
    End Sub

    Private Sub cbomunicipality_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbomunicipality.SelectedIndexChanged

        If cbomunicipality.SelectedItem = "Agno" Then

            txtzipcode.Text = "2408"

        ElseIf cbomunicipality.SelectedItem = "Aguilar" Then

            txtzipcode.Text = "2415"

        ElseIf cbomunicipality.SelectedItem = "Bugallon" Then

            txtzipcode.Text = "2416"

        ElseIf cbomunicipality.SelectedItem = "Binmaley" Then

            txtzipcode.Text = "2417"

        ElseIf cbomunicipality.SelectedItem = "Calasiao" Then

            txtzipcode.Text = "2418"

        ElseIf cbomunicipality.SelectedItem = "Dagupan" Then

            txtzipcode.Text = "2400"

        ElseIf cbomunicipality.SelectedItem = "Lingayen" Then

            txtzipcode.Text = "2401"

        ElseIf cbomunicipality.SelectedItem = "Manaog" Then

            txtzipcode.Text = "2430"

        ElseIf cbomunicipality.SelectedItem = "San Carlos" Then

            txtzipcode.Text = "2420"

        ElseIf cbomunicipality.SelectedItem = "Urdaneta" Then

            txtzipcode.Text = "2428"

        End If

    End Sub

    Private Sub cbohigheli_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbohigheli.SelectedIndexChanged

        If cbohigheli.SelectedItem = "RA 1080" Then

            cbolvleli.Text = "1ST"
            cbolvleli.Items.Add("1ST")

        ElseIf cbohigheli.SelectedItem = "CS Professional" Then

            cbolvleli.Text = "2ND"
            cbolvleli.Items.Add("2ND")


        ElseIf cbohigheli.SelectedItem = "CS FOE" Then

            cbolvleli.Text = "3RD"
            cbolvleli.Items.Add("3RD")

        End If

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
        Try
            With OpenFileDialog1

                'CHECK THE SELECTED FILE IF IT EXIST OTHERWISE THE DIALOG BOX WILL DISPLAY A WARNING.
                .CheckFileExists = True


                'CHECK THE SELECTED PATH IF IT EXIST OTHERWISE THE DIALOG BOX WILL DISPLAY A WARNING.
                .CheckPathExists = True


                'GET AND SET THE DEFAULT EXTENSION
                .DefaultExt = "jpg"


                'RETURN THE FILE LINKED TO THE LNK FILE
                .DereferenceLinks = True

                'SET THE FILE NAME TO EMPTY 
                .FileName = ""

                'FILTERING THE FILES
                .Filter = "(*.jpg)|*.jpg|(*.png)|*.png|(*.jpg)|*.jpg|All files|*.*"

                'SET THIS FOR ONE FILE SELECTION ONLY.
                .Multiselect = False



                'SET THIS TO PUT THE CURRENT FOLDER BACK TO WHERE IT HAS STARTED.
                .RestoreDirectory = True

                'SET THE TITLE OF THE DIALOG BOX.
                .Title = "Select a file to open"

                'ACCEPT ONLY THE VALID WIN32 FILE NAMES.
                .ValidateNames = True

                If .ShowDialog = DialogResult.OK Then
                    Try
                        txtPhoto.Text = .FileName
                        'PictureBox1.BackgroundImage = Image.FromFile(OpenFileDialog1.FileName)
                        PictureBox1.ImageLocation = .FileName
                        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
                    Catch fileException As Exception
                        Throw fileException
                    End Try
                End If

            End With
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, Me.Text)
        End Try
    End Sub

    Private Sub txtcode_TextChanged(sender As Object, e As EventArgs) Handles txtcode.TextChanged
        Try

            sql = "SELECT * FROM `employee` e, `employee_workinfo` ew " &
                 " WHERE e.`EMPID`=ew.`EMPID` AND e.EMPID ='" & txtcode.Text & "'"
            reloadtxt(sql)

            If dt.Rows.Count > 0 Then
                txtaccnum.Text = dt.Rows(0).Item("ACCOUNT_NUM")
                txtrank.Text = dt.Rows(0).Item("RANK")
                PictureBox1.ImageLocation = Application.StartupPath & "\Photo\" & dt.Rows(0).Item("BFPEMPIMAGE")
                txtfname.Text = dt.Rows(0).Item("EMP_FNAME")
                txtlname.Text = dt.Rows(0).Item("EMP_LNAME")
                txtmname.Text = dt.Rows(0).Item("EMP_MNAME")
                txtaddress.Text = dt.Rows(0).Item("ADDRESS")
                txtcontact.Text = dt.Rows(0).Item("CONTACT")
                txtstatus.Text = dt.Rows(0).Item("STATUS")
                dtpdbirth.Value = dt.Rows(0).Item("BIRTH_DATE")
                txtbplace.Text = dt.Rows(0).Item("BIRTH_PLACE")
                If dt.Rows(0).Item("EMP_SEX") = "MALE" Then
                    rdomale.Checked = True
                Else
                    rdofemale.Checked = True
                End If
                txtage.Text = dt.Rows(0).Item("EMP_AGE")
                txtemerg.Text = dt.Rows(0).Item("EMERG_CONTACT")
                txtsfxname.Text = dt.Rows(0).Item("EMP_SFXNAME")
                txtreligion.Text = dt.Rows(0).Item("RELIGION")
                cbomunicipality.Text = dt.Rows(0).Item("MUNICIPALITY")
                txtzipcode.Text = dt.Rows(0).Item("ZIPCODE")
                txtprovince.Text = dt.Rows(0).Item("PROVINCE")
                txtcrs.Text = dt.Rows(0).Item("TERTIARY_CRS")
                txtmascrs.Text = dt.Rows(0).Item("MASTERAL_CRS")
                txtmaslvl.Text = dt.Rows(0).Item("MASTERAL_LVL")
                txtdoccrs.Text = dt.Rows(0).Item("DOCTORATE_CRS")
                txtdoclvl.Text = dt.Rows(0).Item("DOCTORATE_LVL")
                cbohigheli.Text = dt.Rows(0).Item("HIGH_ELI")
                cbolvleli.Text = dt.Rows(0).Item("LVL_ELI")
                txtothereli.Text = dt.Rows(0).Item("OTHER_ELI")
                cbohighmantrain.Text = dt.Rows(0).Item("HIGH_MANTRAIN")
                txtdmantrain.Text = dt.Rows(0).Item("DTN_MANTRAIN")
                txtspecialtrain.Text = dt.Rows(0).Item("SPL_TRAIN")
                txtdspecialtrain.Text = dt.Rows(0).Item("DTN_SPLTRAIN")
                cbounitassign.Text = dt.Rows(0).Item("UNIT_ASSIGN")
                cbosoa.Text = dt.Rows(0).Item("STATUS_APPOINTMENT")
                txtadmin.Text = dt.Rows(0).Item("ADMIN")
                txtunitcode.Text = dt.Rows(0).Item("UNITCODE")
                txtitemnum.Text = dt.Rows(0).Item("ITEM_NUMBER")
                txtpridesig.Text = dt.Rows(0).Item("PRIMARY_DESIG")
                txtapd.Text = dt.Rows(0).Item("AUTH_PRIDESIG")
                dteop.Value = dt.Rows(0).Item("EFFECTIVE_PRIMARY")
                txtyrspridesig.Text = dt.Rows(0).Item("YRS_PRIMARY")
                dtdegs.Value = dt.Rows(0).Item("DEGS")
                dtdefs.Value = dt.Rows(0).Item("DEFS")
                txtyrsfiresvc.Text = dt.Rows(0).Item("YRS_FIRESERVICE")
                dtdao.Value = dt.Rows(0).Item("DAO")
                dtdolp.Value = dt.Rows(0).Item("DOLP")
                txtdateretire.Text = dt.Rows(0).Item("DATE_RETIREMENT")
                txtcondesig.Text = dt.Rows(0).Item("CON_DESIG")
                txtauthcondesig.Text = dt.Rows(0).Item("AUTH_CONDESIG")
                dteffectivecon.Value = dt.Rows(0).Item("EFFECTIVE_CON")
                txttinnum.Text = dt.Rows(0).Item("TIN_num")
                txtpibgnum.Text = dt.Rows(0).Item("PAGIBIG_num")
                txtgsisnum.Text = dt.Rows(0).Item("GSIS_num")
                txtphlthnum.Text = dt.Rows(0).Item("PHILHEALTH_num")
                txtbadgenum.Text = dt.Rows(0).Item("BADGE_num")
                txtlndbnknum.Text = dt.Rows(0).Item("LANDBANK_num")
                txtlngpaynum.Text = dt.Rows(0).Item("LONGPAY")
                txtremarks.Text = dt.Rows(0).Item("REMARKS")
                'Else
                '    cleartext(GroupBox10)
                '    cleartext(GroupBox9)

            End If
            'aloadautonumber("employee", txtcode)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        LblDtNow.Text = DateTime.Now.ToString("dddd, MMM dd yyyy hh:mm:ss tt")
    End Sub


End Class
