﻿Public Class FormHistory


    Private Sub BtnFind_Click(sender As Object, e As EventArgs) Handles BtnFind.Click
        With FormViewProfiles
            .ShowDialog()
        End With
    End Sub

    Private Sub txtEmployeeId_TextChanged(sender As Object, e As EventArgs) Handles txtEmployeeId.TextChanged
        Try

            sql = "SELECT `ACCOUNT_NUM`, `RANK`, `UNIT_ASSIGN`, `CON_DESIG` FROM `employee` e ,`employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID` AND e.`EMPID`='" & txtEmployeeId.Text & "'"
            reloadtxt(sql)
            If dt.Rows.Count > 0 Then
                With dt.Rows(0)
                    txtposition.Text = .Item("RANK")
                    txtaccountnum.Text = .Item("ACCOUNT_NUM")
                    txtunitassigned.Text = .Item("UNIT_ASSIGN")
                    txtdesignation.Text = .Item("CON_DESIG")
                End With
                sql = "SELECT * FROM `employee_workinfo` WHERE `EMPID` ='" & txtemid.Text & "'"
                reloadtxt(sql)



            Else
                txtEmployeeId.Clear()
                txtposition.Clear()
                txtunitassigned.Clear()
                txtdesignation.Clear()
            End If

        Catch ex As Exception
            '  MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click

        Try

            'For Each grp As Control In Me.Controls
            '    If TypeOf grp Is GroupBox Then
            '        For Each ctrl As Control In grp.Controls
            '            If TypeOf ctrl Is TextBox Then
            '                If ctrl.Text = "" Then
            '                    MessageBox.Show("Please put information in " & ctrl.Tag, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '                    Exit Sub
            '                End If
            '            End If
            '            If TypeOf ctrl Is RichTextBox Then
            '                If ctrl.Text = "" Then
            '                    MessageBox.Show("Please put information in " & ctrl.Tag, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '                    Exit Sub
            '                End If
            '            End If

            '        Next
            '    End If
            'Next


            ''----------------------------------


            ' --------------------------

            ''----------------------------------------------------
            Dim day As Double
            Dim numdays As Integer
            Dim numtime As Integer
            numtime = DateDiff(DateInterval.Hour, dtpTimeFrom.Value, dtpTimeTo.Value)
            ' MsgBox(numtime)
            numdays = DateDiff(DateInterval.Day, dtpdatestart.Value, dtpenddate.Value)
            'MsgBox(numdays)
            If numdays = 0 Then
                If numtime >= 0 Then
                    day = 0.5
                ElseIf numtime = 12 Then
                    day = 1
                End If


            Else
                day = numdays
            End If

            MsgBox(day)

            ''------------------------------------------/
            sql = "INSERT INTO `history_resignation` (`EMPID`,`ACCOUNT_NUM`,`DATEFROM`,`DATETO`, `NODAYS`, `DESIGNATION`) " _
            & "VALUES ('" & txtEmployeeId.Text & "','" & txtaccountnum.Text &
            "','" & Format(dtpdatestart.Value, "yyyy-MM-dd hh:mm:ss tt") & "','" & Format(dtpenddate.Value, "yyyy-MM-dd hh:mm:ss tt") & "'," & day &
            ",'" & txtdesignation.Text & "')"
            create(sql, "New Resignation")

            '-----------------------------------------
            updateautonumber("applicationcode")
            Call BtnNew_Click(sender, e)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
    Private Sub BtnNew_Click(sender As Object, e As EventArgs) Handles BtnNew.Click
        cleartext(GroupBox1)
        cleartext(GroupBox5)
        cleartext(Me)


        sql = "SELECT  e.`EMPID` as 'Employee Id', concat( `EMP_FNAME`,' ', `EMP_LNAME`) as 'Name',`ACCOUNT_NUM` as 'Account Number', DATE(`DATEFROM`) as 'Date From', DATE(DATETO) as 'Date To',`NODAYS` as 'No. Days', `DESIGNATION` as 'Designation'  FROM `employee` e,`history_resignation` l  WHERE  e.`EMPID`=l.`EMPID`"
        reloadDtg(sql, dtgapprovedlist)
    End Sub





    Private Sub dtpenddate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpenddate.ValueChanged, dtpdatestart.ValueChanged
        Try

            txtnoDays.Text = DateDiff(DateInterval.Day, dtpdatestart.Value, dtpenddate.Value)

            Dim numdays As Integer

            numdays = DateDiff(DateInterval.Day, dtpdatestart.Value, dtpenddate.Value)

            If numdays > 0 Then
                dtpTimeFrom.Enabled = False
                dtpTimeTo.Enabled = False
            Else
                dtpTimeFrom.Enabled = True
                dtpTimeTo.Enabled = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AddLeave(sender As Object, e As EventArgs) Handles MyBase.Load
        Call BtnNew_Click(sender, e)
        Try
            'For Each rdo As Control In GroupBox2.Controls
            '    If TypeOf rdo Is RadioButton Then
            '        rdo.Enabled = False
            '    End If
            'Next
            '---------------------------------------
            dtpTimeFrom.Format = DateTimePickerFormat.Time
            dtpTimeFrom.ShowUpDown = True
            '----------------------------------
            dtpTimeTo.Format = DateTimePickerFormat.Time
            dtpTimeTo.ShowUpDown = True
            '-----------------------------------
            '--------------------------------------------
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub txtemid_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnoDays.KeyPress, txtemid.KeyPress

        '97 - 122 = Ascii codes for simple letters
        '65 - 90  = Ascii codes for capital letters
        '48 - 57  = Ascii codes for numbers

        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If
    End Sub



    Private Sub txtapprovesearch_TextChanged(sender As Object, e As EventArgs) Handles txtapprovesearch.TextChanged
        Try
            '----------------------------------approved list.
            sql = "SELECT  e.`EMPID` as 'Employee Id', concat( `EMP_FNAME`,' ', `EMP_LNAME`) as 'Name',`ACCOUNT_NUM` as 'Account Number', DATE(`DATEFROM`) as 'Date From',`DATETO` as 'Date To', `NODAYS` as 'No. Days', `DESIGNATION` as 'Designation'   FROM `employee` e,`history_resignation` l  WHERE e.`EMPID`=l.`EMPID` " &
        " AND (e.`EMPID` LIKE '%" & txtapprovesearch.Text & "%' OR concat( `EMP_FNAME`,' ', `EMP_LNAME`) LIKE '%" & txtapprovesearch.Text & "%')"
            reloadDtg(sql, dtgapprovedlist)
            'sql = "SELECT LEAVECODE, e.`EMPID` as 'Employee Id', concat( `EMP_FNAME`,' ', `EMP_LNAME`) as 'Name',`ACCOUNT_NUM` as 'STATUS', `LEAVEAPPLIED` as 'Applied history_resignation', TIME(`DATEFROM`) as 'From', TIME(`DATETO`) as 'To' , DATE(`DATEFROM`) as 'Date of history_resignation', `NODAYS` as 'No. Days', `DESIGNATION` as 'Designation', `DAYOFFSCHEDULE` as 'Dayoff Schedule'   FROM `employee` e,`history_resignation` l  WHERE   AND e.`EMPID`=l.`EMPID`" & _
            '" AND (e.`EMPID` LIKE '%" & txtapprovesearch.Text & "%' OR concat( `EMP_FNAME`,' ', `EMP_LNAME`) LIKE '%" & txtapprovesearch.Text & "%')"
            'reloadDtg(sql, dtgapprovedlist)
            'dtgapprovedlist.Columns(0).Visible = False
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        sql = "SELECT  e.`EMPID` as 'Employee Id', concat( `EMP_FNAME`,' ', `EMP_LNAME`) as 'Name',`ACCOUNT_NUM` as 'Account Number', DATE(`DATEFROM`) as 'Date From', DATE(DATETO) as 'Date To',`NODAYS` as 'No. Days', `DESIGNATION` as 'Designation'  FROM `employee` e,`history_resignation` l  WHERE  e.`EMPID`=l.`EMPID`"
        reloadDtg(sql, dtgapprovedlist)

    End Sub


End Class
