﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSettings
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormSettings))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dtgdeptlist = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btn_Delete_Position = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_update_Position = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_save_Position = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtposition = New System.Windows.Forms.TextBox()
        Me.dtglistposition = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btn_delete_dept = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_update_dept = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.btn_save_dept = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.txtdepartment = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.dtgdeptlist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dtglistposition, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dtgdeptlist
        '
        Me.dtgdeptlist.AllowUserToAddRows = False
        Me.dtgdeptlist.AllowUserToDeleteRows = False
        Me.dtgdeptlist.AllowUserToResizeColumns = False
        Me.dtgdeptlist.AllowUserToResizeRows = False
        Me.dtgdeptlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dtgdeptlist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtgdeptlist.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(59, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dtgdeptlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Bookman Old Style", 15.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Red
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dtgdeptlist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dtgdeptlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Bookman Old Style", 15.75!, System.Drawing.FontStyle.Bold)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dtgdeptlist.DefaultCellStyle = DataGridViewCellStyle2
        Me.dtgdeptlist.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgdeptlist.GridColor = System.Drawing.Color.Maroon
        Me.dtgdeptlist.Location = New System.Drawing.Point(6, 61)
        Me.dtgdeptlist.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtgdeptlist.Name = "dtgdeptlist"
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(59, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dtgdeptlist.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.dtgdeptlist.Size = New System.Drawing.Size(494, 405)
        Me.dtgdeptlist.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GroupBox1.BackColor = System.Drawing.Color.DimGray
        Me.GroupBox1.Controls.Add(Me.btn_Delete_Position)
        Me.GroupBox1.Controls.Add(Me.btn_update_Position)
        Me.GroupBox1.Controls.Add(Me.btn_save_Position)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtposition)
        Me.GroupBox1.Controls.Add(Me.dtglistposition)
        Me.GroupBox1.Font = New System.Drawing.Font("Bookman Old Style", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(46, 91)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(506, 533)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "RANK OF BFP EMPLOYEE"
        '
        'btn_Delete_Position
        '
        Me.btn_Delete_Position.Activecolor = System.Drawing.Color.Maroon
        Me.btn_Delete_Position.BackColor = System.Drawing.Color.Maroon
        Me.btn_Delete_Position.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Delete_Position.BorderRadius = 0
        Me.btn_Delete_Position.ButtonText = "Delete"
        Me.btn_Delete_Position.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_Delete_Position.DisabledColor = System.Drawing.Color.Gray
        Me.btn_Delete_Position.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Delete_Position.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_Delete_Position.Iconimage = CType(resources.GetObject("btn_Delete_Position.Iconimage"), System.Drawing.Image)
        Me.btn_Delete_Position.Iconimage_right = Nothing
        Me.btn_Delete_Position.Iconimage_right_Selected = Nothing
        Me.btn_Delete_Position.Iconimage_Selected = Nothing
        Me.btn_Delete_Position.IconMarginLeft = 0
        Me.btn_Delete_Position.IconMarginRight = 0
        Me.btn_Delete_Position.IconRightVisible = True
        Me.btn_Delete_Position.IconRightZoom = 0R
        Me.btn_Delete_Position.IconVisible = True
        Me.btn_Delete_Position.IconZoom = 40.0R
        Me.btn_Delete_Position.IsTab = False
        Me.btn_Delete_Position.Location = New System.Drawing.Point(383, 488)
        Me.btn_Delete_Position.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_Delete_Position.Name = "btn_Delete_Position"
        Me.btn_Delete_Position.Normalcolor = System.Drawing.Color.Maroon
        Me.btn_Delete_Position.OnHovercolor = System.Drawing.Color.Maroon
        Me.btn_Delete_Position.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_Delete_Position.selected = False
        Me.btn_Delete_Position.Size = New System.Drawing.Size(115, 34)
        Me.btn_Delete_Position.TabIndex = 10
        Me.btn_Delete_Position.Text = "Delete"
        Me.btn_Delete_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_Delete_Position.Textcolor = System.Drawing.Color.White
        Me.btn_Delete_Position.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_update_Position
        '
        Me.btn_update_Position.Activecolor = System.Drawing.Color.Maroon
        Me.btn_update_Position.BackColor = System.Drawing.Color.Maroon
        Me.btn_update_Position.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_update_Position.BorderRadius = 0
        Me.btn_update_Position.ButtonText = "Update"
        Me.btn_update_Position.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_update_Position.DisabledColor = System.Drawing.Color.Gray
        Me.btn_update_Position.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update_Position.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_update_Position.Iconimage = CType(resources.GetObject("btn_update_Position.Iconimage"), System.Drawing.Image)
        Me.btn_update_Position.Iconimage_right = Nothing
        Me.btn_update_Position.Iconimage_right_Selected = Nothing
        Me.btn_update_Position.Iconimage_Selected = Nothing
        Me.btn_update_Position.IconMarginLeft = 0
        Me.btn_update_Position.IconMarginRight = 0
        Me.btn_update_Position.IconRightVisible = True
        Me.btn_update_Position.IconRightZoom = 0R
        Me.btn_update_Position.IconVisible = True
        Me.btn_update_Position.IconZoom = 40.0R
        Me.btn_update_Position.IsTab = False
        Me.btn_update_Position.Location = New System.Drawing.Point(192, 488)
        Me.btn_update_Position.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_update_Position.Name = "btn_update_Position"
        Me.btn_update_Position.Normalcolor = System.Drawing.Color.Maroon
        Me.btn_update_Position.OnHovercolor = System.Drawing.Color.Maroon
        Me.btn_update_Position.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_update_Position.selected = False
        Me.btn_update_Position.Size = New System.Drawing.Size(115, 34)
        Me.btn_update_Position.TabIndex = 9
        Me.btn_update_Position.Text = "Update"
        Me.btn_update_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_update_Position.Textcolor = System.Drawing.Color.White
        Me.btn_update_Position.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_save_Position
        '
        Me.btn_save_Position.Activecolor = System.Drawing.Color.Maroon
        Me.btn_save_Position.BackColor = System.Drawing.Color.Maroon
        Me.btn_save_Position.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_save_Position.BorderRadius = 0
        Me.btn_save_Position.ButtonText = "Save"
        Me.btn_save_Position.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_save_Position.DisabledColor = System.Drawing.Color.Gray
        Me.btn_save_Position.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save_Position.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_save_Position.Iconimage = CType(resources.GetObject("btn_save_Position.Iconimage"), System.Drawing.Image)
        Me.btn_save_Position.Iconimage_right = Nothing
        Me.btn_save_Position.Iconimage_right_Selected = Nothing
        Me.btn_save_Position.Iconimage_Selected = Nothing
        Me.btn_save_Position.IconMarginLeft = 10
        Me.btn_save_Position.IconMarginRight = 0
        Me.btn_save_Position.IconRightVisible = True
        Me.btn_save_Position.IconRightZoom = 0R
        Me.btn_save_Position.IconVisible = True
        Me.btn_save_Position.IconZoom = 40.0R
        Me.btn_save_Position.IsTab = False
        Me.btn_save_Position.Location = New System.Drawing.Point(8, 488)
        Me.btn_save_Position.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_save_Position.Name = "btn_save_Position"
        Me.btn_save_Position.Normalcolor = System.Drawing.Color.Maroon
        Me.btn_save_Position.OnHovercolor = System.Drawing.Color.Maroon
        Me.btn_save_Position.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_save_Position.selected = False
        Me.btn_save_Position.Size = New System.Drawing.Size(115, 34)
        Me.btn_save_Position.TabIndex = 7
        Me.btn_save_Position.Text = "Save"
        Me.btn_save_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_save_Position.Textcolor = System.Drawing.Color.White
        Me.btn_save_Position.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 11.25!)
        Me.Label1.Location = New System.Drawing.Point(6, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 19)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Rank :"
        '
        'txtposition
        '
        Me.txtposition.Font = New System.Drawing.Font("Bookman Old Style", 11.25!)
        Me.txtposition.Location = New System.Drawing.Point(70, 27)
        Me.txtposition.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtposition.Multiline = True
        Me.txtposition.Name = "txtposition"
        Me.txtposition.Size = New System.Drawing.Size(430, 26)
        Me.txtposition.TabIndex = 2
        '
        'dtglistposition
        '
        Me.dtglistposition.AllowUserToAddRows = False
        Me.dtglistposition.AllowUserToDeleteRows = False
        Me.dtglistposition.AllowUserToResizeColumns = False
        Me.dtglistposition.AllowUserToResizeRows = False
        Me.dtglistposition.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dtglistposition.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dtglistposition.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(59, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dtglistposition.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Bookman Old Style", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Red
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dtglistposition.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dtglistposition.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Bookman Old Style", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dtglistposition.DefaultCellStyle = DataGridViewCellStyle5
        Me.dtglistposition.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtglistposition.GridColor = System.Drawing.Color.Maroon
        Me.dtglistposition.Location = New System.Drawing.Point(6, 61)
        Me.dtglistposition.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtglistposition.Name = "dtglistposition"
        Me.dtglistposition.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(59, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.dtglistposition.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.dtglistposition.Size = New System.Drawing.Size(494, 405)
        Me.dtglistposition.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.GroupBox2.BackColor = System.Drawing.Color.DimGray
        Me.GroupBox2.Controls.Add(Me.btn_delete_dept)
        Me.GroupBox2.Controls.Add(Me.btn_update_dept)
        Me.GroupBox2.Controls.Add(Me.btn_save_dept)
        Me.GroupBox2.Controls.Add(Me.txtdepartment)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.dtgdeptlist)
        Me.GroupBox2.Font = New System.Drawing.Font("Bookman Old Style", 15.75!, System.Drawing.FontStyle.Bold)
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(583, 91)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(506, 533)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "UNIT ASSIGNMENT"
        '
        'btn_delete_dept
        '
        Me.btn_delete_dept.Activecolor = System.Drawing.Color.Maroon
        Me.btn_delete_dept.BackColor = System.Drawing.Color.Maroon
        Me.btn_delete_dept.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_delete_dept.BorderRadius = 0
        Me.btn_delete_dept.ButtonText = "Delete"
        Me.btn_delete_dept.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_delete_dept.DisabledColor = System.Drawing.Color.Gray
        Me.btn_delete_dept.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_delete_dept.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_delete_dept.Iconimage = CType(resources.GetObject("btn_delete_dept.Iconimage"), System.Drawing.Image)
        Me.btn_delete_dept.Iconimage_right = Nothing
        Me.btn_delete_dept.Iconimage_right_Selected = Nothing
        Me.btn_delete_dept.Iconimage_Selected = Nothing
        Me.btn_delete_dept.IconMarginLeft = 0
        Me.btn_delete_dept.IconMarginRight = 0
        Me.btn_delete_dept.IconRightVisible = True
        Me.btn_delete_dept.IconRightZoom = 0R
        Me.btn_delete_dept.IconVisible = True
        Me.btn_delete_dept.IconZoom = 40.0R
        Me.btn_delete_dept.IsTab = False
        Me.btn_delete_dept.Location = New System.Drawing.Point(385, 488)
        Me.btn_delete_dept.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_delete_dept.Name = "btn_delete_dept"
        Me.btn_delete_dept.Normalcolor = System.Drawing.Color.Maroon
        Me.btn_delete_dept.OnHovercolor = System.Drawing.Color.Maroon
        Me.btn_delete_dept.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_delete_dept.selected = False
        Me.btn_delete_dept.Size = New System.Drawing.Size(115, 34)
        Me.btn_delete_dept.TabIndex = 13
        Me.btn_delete_dept.Text = "Delete"
        Me.btn_delete_dept.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_delete_dept.Textcolor = System.Drawing.Color.White
        Me.btn_delete_dept.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_update_dept
        '
        Me.btn_update_dept.Activecolor = System.Drawing.Color.Maroon
        Me.btn_update_dept.BackColor = System.Drawing.Color.Maroon
        Me.btn_update_dept.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_update_dept.BorderRadius = 0
        Me.btn_update_dept.ButtonText = "Update"
        Me.btn_update_dept.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_update_dept.DisabledColor = System.Drawing.Color.Gray
        Me.btn_update_dept.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_update_dept.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_update_dept.Iconimage = CType(resources.GetObject("btn_update_dept.Iconimage"), System.Drawing.Image)
        Me.btn_update_dept.Iconimage_right = Nothing
        Me.btn_update_dept.Iconimage_right_Selected = Nothing
        Me.btn_update_dept.Iconimage_Selected = Nothing
        Me.btn_update_dept.IconMarginLeft = 0
        Me.btn_update_dept.IconMarginRight = 0
        Me.btn_update_dept.IconRightVisible = True
        Me.btn_update_dept.IconRightZoom = 0R
        Me.btn_update_dept.IconVisible = True
        Me.btn_update_dept.IconZoom = 40.0R
        Me.btn_update_dept.IsTab = False
        Me.btn_update_dept.Location = New System.Drawing.Point(201, 488)
        Me.btn_update_dept.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_update_dept.Name = "btn_update_dept"
        Me.btn_update_dept.Normalcolor = System.Drawing.Color.Maroon
        Me.btn_update_dept.OnHovercolor = System.Drawing.Color.Maroon
        Me.btn_update_dept.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_update_dept.selected = False
        Me.btn_update_dept.Size = New System.Drawing.Size(115, 34)
        Me.btn_update_dept.TabIndex = 12
        Me.btn_update_dept.Text = "Update"
        Me.btn_update_dept.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_update_dept.Textcolor = System.Drawing.Color.White
        Me.btn_update_dept.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'btn_save_dept
        '
        Me.btn_save_dept.Activecolor = System.Drawing.Color.Maroon
        Me.btn_save_dept.BackColor = System.Drawing.Color.Maroon
        Me.btn_save_dept.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_save_dept.BorderRadius = 0
        Me.btn_save_dept.ButtonText = "Save"
        Me.btn_save_dept.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_save_dept.DisabledColor = System.Drawing.Color.Gray
        Me.btn_save_dept.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_save_dept.Iconcolor = System.Drawing.Color.Transparent
        Me.btn_save_dept.Iconimage = CType(resources.GetObject("btn_save_dept.Iconimage"), System.Drawing.Image)
        Me.btn_save_dept.Iconimage_right = Nothing
        Me.btn_save_dept.Iconimage_right_Selected = Nothing
        Me.btn_save_dept.Iconimage_Selected = Nothing
        Me.btn_save_dept.IconMarginLeft = 0
        Me.btn_save_dept.IconMarginRight = 0
        Me.btn_save_dept.IconRightVisible = True
        Me.btn_save_dept.IconRightZoom = 0R
        Me.btn_save_dept.IconVisible = True
        Me.btn_save_dept.IconZoom = 40.0R
        Me.btn_save_dept.IsTab = False
        Me.btn_save_dept.Location = New System.Drawing.Point(8, 488)
        Me.btn_save_dept.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.btn_save_dept.Name = "btn_save_dept"
        Me.btn_save_dept.Normalcolor = System.Drawing.Color.Maroon
        Me.btn_save_dept.OnHovercolor = System.Drawing.Color.Maroon
        Me.btn_save_dept.OnHoverTextColor = System.Drawing.Color.White
        Me.btn_save_dept.selected = False
        Me.btn_save_dept.Size = New System.Drawing.Size(115, 34)
        Me.btn_save_dept.TabIndex = 11
        Me.btn_save_dept.Text = "Save"
        Me.btn_save_dept.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.btn_save_dept.Textcolor = System.Drawing.Color.White
        Me.btn_save_dept.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'txtdepartment
        '
        Me.txtdepartment.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdepartment.Location = New System.Drawing.Point(125, 27)
        Me.txtdepartment.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtdepartment.Multiline = True
        Me.txtdepartment.Name = "txtdepartment"
        Me.txtdepartment.Size = New System.Drawing.Size(375, 26)
        Me.txtdepartment.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(18, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 19)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Unit Assign :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.DimGray
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label8.Location = New System.Drawing.Point(472, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(197, 39)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "SETTINGS"
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1138, 660)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'FormSettings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "FormSettings"
        Me.Size = New System.Drawing.Size(1138, 660)
        CType(Me.dtgdeptlist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dtglistposition, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtgdeptlist As DataGridView
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtposition As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtdepartment As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btn_Delete_Position As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_update_Position As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_save_Position As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_delete_dept As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_update_dept As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents btn_save_dept As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents dtglistposition As DataGridView
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
