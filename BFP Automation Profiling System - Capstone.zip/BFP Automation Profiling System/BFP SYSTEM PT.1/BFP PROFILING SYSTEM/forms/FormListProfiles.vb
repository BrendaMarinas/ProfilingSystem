﻿Public Class FormListProfiles
    Private Sub frmFindEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'ADDING ITEMS IN THE COMBOBOX
        With cboCategory
            .Items.Add("ID")
            .Items.Add("Name")
            .Items.Add("Account Number")
            .Items.Add("Unit Assigned")
            .Items.Add("Gender")

        End With


        sql = "SELECT e.EMPID AS 'Employee Id',concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) as Name " &
        ",  `EMP_AGE` AS 'Age', `BIRTH_DATE` AS 'Birthday', `BIRTH_PLACE` AS 'Birth Place', `STATUS` AS 'Civil Status', `EMP_SEX` AS 'Gender', `STATUS` AS 'Status', `RELIGION` AS 'Religion', `ADDRESS` AS 'ADDRESS'" &
        ", `TERTIARY_CRS` AS 'Tertiary Course', `MASTERAL_CRS` AS 'Masteral Course', `MASTERAL_LVL` AS 'Masteral Level', `DOCTORATE_CRS` AS 'Doctorate Course', `DOCTORATE_LVL` AS 'Doctorate Level', `HIGH_ELI` AS 'Highest Eligibility'" &
        ", `LVL_ELI` AS 'Level of Highest Eligibility', `OTHER_ELI` AS 'Othe Eligibility', `HIGH_MANTRAIN` AS 'Highest Mandatory Training', `DTN_MANTRAIN` AS 'Duration of Mandatory Training', `SPL_TRAIN` AS 'Specialized Training', `DTN_SPLTRAIN` AS 'Duration of Specialized Training'" &
        ", `ACCOUNT_NUM` AS 'Account Number', `RANK` AS 'Rank', `UNIT_ASSIGN` AS 'Unit Assign', `STATUS_APPOINTMENT` AS 'Status of Appointment'" &
        ", `ADMIN` AS 'ADMIN', `UNITCODE` AS 'Unit Code', `ITEM_NUMBER` AS 'Item NUmber', `PRIMARY_DESIG` AS 'Primary Designation'" &
        ",  `AUTH_PRIDESIG` AS 'Authority of Primary Designation', `EFFECTIVE_PRIMARY` AS 'Effective of Primary', `YRS_PRIMARY` AS 'Year in Primary Designation', `DEGS` AS 'Date Entered Government Service'" &
        ", `DEFS` AS 'Date entered of Fire Service', `YRS_FIRESERVICE` AS 'Years of Fire Service', `DAO` AS 'Date Acquired Officership', `DOLP` AS 'Date of Last Promotion'" &
        ", `DATE_RETIREMENT` AS 'Date of Retirement', `CON_DESIG` AS 'Concurrent Designation', `AUTH_CONDESIG` AS 'Authority of Concurrent Designation', `EFFECTIVE_CON` AS 'Effective of Concurrent'" &
        ", `TIN_num` AS 'TIN No.', `PAGIBIG_num` AS 'PAGIBIG No.', `GSIS_num` AS 'GSIS No.', `PHILHEALTH_num` AS 'PHILHEALTH No.'" &
        ", `BADGE_num` AS 'Badge No.', `LANDBANK_num` AS 'LandBank No.', `LONGPAY` AS 'Longpay'" &
        ", `REMARKS` AS 'Remarks' FROM `employee` e, `employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID`"

        mysqlRetrieve(sql, dtgemplist)
        PicBox.ImageLocation = Application.StartupPath & "\Photo\no_image.png"
    End Sub

    Private Sub dtgemplist_Click(sender As Object, e As EventArgs) Handles dtgemplist.Click
        Try
            sql = "SELECT * FROM employee WHERE `EMPID` = '" & dtgemplist.CurrentRow.Cells(0).Value & "'"
            reloadtxt(sql)
            If dt.Rows.Count > 0 Then
                PicBox.ImageLocation = Application.StartupPath & "\Photo\" & dt.Rows(0).Item("BFPEMPIMAGE")
            Else
                PicBox.ImageLocation = Application.StartupPath & "\Photo\no_image.png"
            End If

        Catch ex As Exception

        End Try
    End Sub


    Private Sub txtempsearch_TextChanged(sender As Object, e As EventArgs) Handles txtempsearch.TextChanged


        Try
            'CHECKING IF WHAT CATEGORY THAT YOUR GOING THE SEARCH

            If cboCategory.Text = "ID" Then
                'THIS IS FOR THE ID OF THE EMPLOYEE
                sql = "SELECT e.EMPID AS 'Employee Id',concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) as Name " &
                       ",  `EMP_AGE` AS 'Age', `BIRTH_DATE` AS 'Birthday', `BIRTH_PLACE` AS 'Birth Place', `STATUS` AS 'Civil Status', `EMP_SEX` AS 'Gender', `STATUS` AS 'Status', `RELIGION` AS 'Religion', `ADDRESS` AS 'ADDRESS'" &
                       ", `TERTIARY_CRS` AS 'Tertiary Course', `MASTERAL_CRS` AS 'Masteral Course', `MASTERAL_LVL` AS 'Masteral Level', `DOCTORATE_CRS` AS 'Doctorate Course', `DOCTORATE_LVL` AS 'Doctorate Level', `HIGH_ELI` AS 'Highest Eligibility'" &
                       ", `LVL_ELI` AS 'Level of Highest Eligibility', `OTHER_ELI` AS 'Othe Eligibility', `HIGH_MANTRAIN` AS 'Highest Mandatory Training', `DTN_MANTRAIN` AS 'Duration of Mandatory Training', `SPL_TRAIN` AS 'Specialized Training', `DTN_SPLTRAIN` AS 'Duration of Specialized Training'" &
                       ", `ACCOUNT_NUM` AS 'Account Number', `RANK` AS 'Rank', `UNIT_ASSIGN` AS 'Unit Assign', `STATUS_APPOINTMENT` AS 'Status of Appointment'" &
                       ", `ADMIN` AS 'ADMIN', `UNITCODE` AS 'Unit Code', `ITEM_NUMBER` AS 'Item NUmber', `PRIMARY_DESIG` AS 'Primary Designation'" &
                       ",  `AUTH_PRIDESIG` AS 'Authority of Primary Designation', `EFFECTIVE_PRIMARY` AS 'Effective of Primary', `YRS_PRIMARY` AS 'Year in Primary Designation', `DEGS` AS 'Date Entered Government Service'" &
                       ", `DEFS` AS 'Date entered of Fire Service', `YRS_FIRESERVICE` AS 'Years of Fire Service', `DAO` AS 'Date Acquired Officership', `DOLP` AS 'Date of Last Promotion'" &
                       ", `DATE_RETIREMENT` AS 'Date of Retirement', `CON_DESIG` AS 'Concurrent Designation', `AUTH_CONDESIG` AS 'Authority of Concurrent Designation', `EFFECTIVE_CON` AS 'Effective of Concurrent'" &
                       ", `TIN_num` AS 'TIN No.', `PAGIBIG_num` AS 'PAGIBIG No.', `GSIS_num` AS 'GSIS No.', `PHILHEALTH_num` AS 'PHILHEALTH No.'" &
                       ", `BADGE_num` AS 'Badge No.', `LANDBANK_num` AS 'LandBank No.', `LONGPAY` AS 'Longpay'" &
                       ", `REMARKS` AS 'Remarks' FROM `employee` e, `employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID`" &
                       "AND e.EMPID LIKE '%" & txtempsearch.Text & "%'"
                reloadDtg(sql, dtgemplist)

            ElseIf cboCategory.Text = "Account Number" Then

                sql = "SELECT e.EMPID AS 'Employee Id',concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) as Name " &
                       ", `ACCOUNT_NUM` AS 'Account Number', `RANK` AS 'Rank', `UNIT_ASSIGN` AS 'Unit Assign', `STATUS_APPOINTMENT` AS 'Status of Appointment'" &
                       ",  `EMP_AGE` AS 'Age', `BIRTH_DATE` AS 'Birthday', `BIRTH_PLACE` AS 'Birth Place', `STATUS` AS 'Civil Status', `EMP_SEX` AS 'Gender', `STATUS` AS 'Status', `RELIGION` AS 'Religion', `ADDRESS` AS 'ADDRESS'" &
                       ", `TERTIARY_CRS` AS 'Tertiary Course', `MASTERAL_CRS` AS 'Masteral Course', `MASTERAL_LVL` AS 'Masteral Level', `DOCTORATE_CRS` AS 'Doctorate Course', `DOCTORATE_LVL` AS 'Doctorate Level', `HIGH_ELI` AS 'Highest Eligibility'" &
                       ", `LVL_ELI` AS 'Level of Highest Eligibility', `OTHER_ELI` AS 'Othe Eligibility', `HIGH_MANTRAIN` AS 'Highest Mandatory Training', `DTN_MANTRAIN` AS 'Duration of Mandatory Training', `SPL_TRAIN` AS 'Specialized Training', `DTN_SPLTRAIN` AS 'Duration of Specialized Training'" &
                       ", `ADMIN` AS 'ADMIN', `UNITCODE` AS 'Unit Code', `ITEM_NUMBER` AS 'Item NUmber', `PRIMARY_DESIG` AS 'Primary Designation'" &
                       ",  `AUTH_PRIDESIG` AS 'Authority of Primary Designation', `EFFECTIVE_PRIMARY` AS 'Effective of Primary', `YRS_PRIMARY` AS 'Year in Primary Designation', `DEGS` AS 'Date Entered Government Service'" &
                       ", `DEFS` AS 'Date entered of Fire Service', `YRS_FIRESERVICE` AS 'Years of Fire Service', `DAO` AS 'Date Acquired Officership', `DOLP` AS 'Date of Last Promotion'" &
                       ", `DATE_RETIREMENT` AS 'Date of Retirement', `CON_DESIG` AS 'Concurrent Designation', `AUTH_CONDESIG` AS 'Authority of Concurrent Designation', `EFFECTIVE_CON` AS 'Effective of Concurrent'" &
                       ", `TIN_num` AS 'TIN No.', `PAGIBIG_num` AS 'PAGIBIG No.', `GSIS_num` AS 'GSIS No.', `PHILHEALTH_num` AS 'PHILHEALTH No.'" &
                       ", `BADGE_num` AS 'Badge No.', `LANDBANK_num` AS 'LandBank No.', `LONGPAY` AS 'Longpay'" &
                       ", `REMARKS` AS 'Remarks' FROM `employee` e, `employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID`" &
                       "AND `ACCOUNT_NUM` LIKE '%" & txtempsearch.Text & "%'"
                reloadDtg(sql, dtgemplist)

            ElseIf cboCategory.Text = "Name" Then

                sql = "SELECT e.EMPID AS 'Employee Id',concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) as Name " &
                       ",  `EMP_AGE` AS 'Age', `BIRTH_DATE` AS 'Birthday', `BIRTH_PLACE` AS 'Birth Place', `STATUS` AS 'Civil Status', `EMP_SEX` AS 'Gender', `STATUS` AS 'Status', `RELIGION` AS 'Religion', `ADDRESS` AS 'ADDRESS'" &
                       ", `TERTIARY_CRS` AS 'Tertiary Course', `MASTERAL_CRS` AS 'Masteral Course', `MASTERAL_LVL` AS 'Masteral Level', `DOCTORATE_CRS` AS 'Doctorate Course', `DOCTORATE_LVL` AS 'Doctorate Level', `HIGH_ELI` AS 'Highest Eligibility'" &
                       ", `LVL_ELI` AS 'Level of Highest Eligibility', `OTHER_ELI` AS 'Othe Eligibility', `HIGH_MANTRAIN` AS 'Highest Mandatory Training', `DTN_MANTRAIN` AS 'Duration of Mandatory Training', `SPL_TRAIN` AS 'Specialized Training', `DTN_SPLTRAIN` AS 'Duration of Specialized Training'" &
                       ", `ACCOUNT_NUM` AS 'Account Number', `RANK` AS 'Rank', `UNIT_ASSIGN` AS 'Unit Assign', `STATUS_APPOINTMENT` AS 'Status of Appointment'" &
                       ", `ADMIN` AS 'ADMIN', `UNITCODE` AS 'Unit Code', `ITEM_NUMBER` AS 'Item NUmber', `PRIMARY_DESIG` AS 'Primary Designation'" &
                       ",  `AUTH_PRIDESIG` AS 'Authority of Primary Designation', `EFFECTIVE_PRIMARY` AS 'Effective of Primary', `YRS_PRIMARY` AS 'Year in Primary Designation', `DEGS` AS 'Date Entered Government Service'" &
                       ", `DEFS` AS 'Date entered of Fire Service', `YRS_FIRESERVICE` AS 'Years of Fire Service', `DAO` AS 'Date Acquired Officership', `DOLP` AS 'Date of Last Promotion'" &
                       ", `DATE_RETIREMENT` AS 'Date of Retirement', `CON_DESIG` AS 'Concurrent Designation', `AUTH_CONDESIG` AS 'Authority of Concurrent Designation', `EFFECTIVE_CON` AS 'Effective of Concurrent'" &
                       ", `TIN_num` AS 'TIN No.', `PAGIBIG_num` AS 'PAGIBIG No.', `GSIS_num` AS 'GSIS No.', `PHILHEALTH_num` AS 'PHILHEALTH No.'" &
                       ", `BADGE_num` AS 'Badge No.', `LANDBANK_num` AS 'LandBank No.', `LONGPAY` AS 'Longpay'" &
                       ", `REMARKS` AS 'Remarks' FROM `employee` e, `employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID`" &
                       "AND concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) LIKE '%" & txtempsearch.Text & "%'"
                mysqlRetrieve(sql, dtgemplist)

            ElseIf cboCategory.Text = "Unit Assigned" Then

                sql = "SELECT e.EMPID AS 'Employee Id',concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) as Name " &
                       ",  `EMP_AGE` AS 'Age', `BIRTH_DATE` AS 'Birthday', `BIRTH_PLACE` AS 'Birth Place', `STATUS` AS 'Civil Status', `EMP_SEX` AS 'Gender', `STATUS` AS 'Status', `RELIGION` AS 'Religion', `ADDRESS` AS 'ADDRESS'" &
                       ", `TERTIARY_CRS` AS 'Tertiary Course', `MASTERAL_CRS` AS 'Masteral Course', `MASTERAL_LVL` AS 'Masteral Level', `DOCTORATE_CRS` AS 'Doctorate Course', `DOCTORATE_LVL` AS 'Doctorate Level', `HIGH_ELI` AS 'Highest Eligibility'" &
                       ", `LVL_ELI` AS 'Level of Highest Eligibility', `OTHER_ELI` AS 'Othe Eligibility', `HIGH_MANTRAIN` AS 'Highest Mandatory Training', `DTN_MANTRAIN` AS 'Duration of Mandatory Training', `SPL_TRAIN` AS 'Specialized Training', `DTN_SPLTRAIN` AS 'Duration of Specialized Training'" &
                       ", `ACCOUNT_NUM` AS 'Account Number', `RANK` AS 'Rank', `UNIT_ASSIGN` AS 'Unit Assign', `STATUS_APPOINTMENT` AS 'Status of Appointment'" &
                       ", `ADMIN` AS 'ADMIN', `UNITCODE` AS 'Unit Code', `ITEM_NUMBER` AS 'Item NUmber', `PRIMARY_DESIG` AS 'Primary Designation'" &
                       ",  `AUTH_PRIDESIG` AS 'Authority of Primary Designation', `EFFECTIVE_PRIMARY` AS 'Effective of Primary', `YRS_PRIMARY` AS 'Year in Primary Designation', `DEGS` AS 'Date Entered Government Service'" &
                       ", `DEFS` AS 'Date entered of Fire Service', `YRS_FIRESERVICE` AS 'Years of Fire Service', `DAO` AS 'Date Acquired Officership', `DOLP` AS 'Date of Last Promotion'" &
                       ", `DATE_RETIREMENT` AS 'Date of Retirement', `CON_DESIG` AS 'Concurrent Designation', `AUTH_CONDESIG` AS 'Authority of Concurrent Designation', `EFFECTIVE_CON` AS 'Effective of Concurrent'" &
                       ", `TIN_num` AS 'TIN No.', `PAGIBIG_num` AS 'PAGIBIG No.', `GSIS_num` AS 'GSIS No.', `PHILHEALTH_num` AS 'PHILHEALTH No.'" &
                       ", `BADGE_num` AS 'Badge No.', `LANDBANK_num` AS 'LandBank No.', `LONGPAY` AS 'Longpay'" &
                       ", `REMARKS` AS 'Remarks' FROM `employee` e, `employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID`" &
                       "AND `UNIT_ASSIGN` LIKE '%" & txtempsearch.Text & "%'"
                mysqlRetrieve(sql, dtgemplist)

            ElseIf cboCategory.Text = "Gender" Then

                sql = "SELECT e.EMPID AS 'Employee Id',concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) as Name " &
                       ",  `EMP_AGE` AS 'Age', `BIRTH_DATE` AS 'Birthday', `BIRTH_PLACE` AS 'Birth Place', `STATUS` AS 'Civil Status', `EMP_SEX` AS 'Gender', `STATUS` AS 'Status', `RELIGION` AS 'Religion', `ADDRESS` AS 'ADDRESS'" &
                       ", `TERTIARY_CRS` AS 'Tertiary Course', `MASTERAL_CRS` AS 'Masteral Course', `MASTERAL_LVL` AS 'Masteral Level', `DOCTORATE_CRS` AS 'Doctorate Course', `DOCTORATE_LVL` AS 'Doctorate Level', `HIGH_ELI` AS 'Highest Eligibility'" &
                       ", `LVL_ELI` AS 'Level of Highest Eligibility', `OTHER_ELI` AS 'Othe Eligibility', `HIGH_MANTRAIN` AS 'Highest Mandatory Training', `DTN_MANTRAIN` AS 'Duration of Mandatory Training', `SPL_TRAIN` AS 'Specialized Training', `DTN_SPLTRAIN` AS 'Duration of Specialized Training'" &
                       ", `ACCOUNT_NUM` AS 'Account Number', `RANK` AS 'Rank', `UNIT_ASSIGN` AS 'Unit Assign', `STATUS_APPOINTMENT` AS 'Status of Appointment'" &
                       ", `ADMIN` AS 'ADMIN', `UNITCODE` AS 'Unit Code', `ITEM_NUMBER` AS 'Item NUmber', `PRIMARY_DESIG` AS 'Primary Designation'" &
                       ",  `AUTH_PRIDESIG` AS 'Authority of Primary Designation', `EFFECTIVE_PRIMARY` AS 'Effective of Primary', `YRS_PRIMARY` AS 'Year in Primary Designation', `DEGS` AS 'Date Entered Government Service'" &
                       ", `DEFS` AS 'Date entered of Fire Service', `YRS_FIRESERVICE` AS 'Years of Fire Service', `DAO` AS 'Date Acquired Officership', `DOLP` AS 'Date of Last Promotion'" &
                       ", `DATE_RETIREMENT` AS 'Date of Retirement', `CON_DESIG` AS 'Concurrent Designation', `AUTH_CONDESIG` AS 'Authority of Concurrent Designation', `EFFECTIVE_CON` AS 'Effective of Concurrent'" &
                       ", `TIN_num` AS 'TIN No.', `PAGIBIG_num` AS 'PAGIBIG No.', `GSIS_num` AS 'GSIS No.', `PHILHEALTH_num` AS 'PHILHEALTH No.'" &
                       ", `BADGE_num` AS 'Badge No.', `LANDBANK_num` AS 'LandBank No.', `LONGPAY` AS 'Longpay'" &
                       ", `REMARKS` AS 'Remarks' FROM `employee` e, `employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID`" &
                       "AND `EMP_SEX` LIKE '%" & txtempsearch.Text & "%'"
                mysqlRetrieve(sql, dtgemplist)



            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub




    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Try
            FormMenu.addContent(FormMenu.FrmEmployee1)
            FormMenu.FrmEmployee1.emptitle.Text = "UPDATE PROFILE"
            FormMenu.FrmEmployee1.txtcode.Text = dtgemplist.CurrentRow.Cells(0).Value
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        sql = "DELETE FROM employee WHERE EMPID = '" & dtgemplist.CurrentRow.Cells(0).Value & "'"
        createNoMsg(sql)
        sql = "DELETE FROM employee_workinfo WHERE EMPID = '" & dtgemplist.CurrentRow.Cells(0).Value & "'"
        deletes(sql, dtgemplist.CurrentRow.Cells(1).Value)

        sql = "SELECT `EMPID` AS 'Employee Id',`EMP_FNAME` as 'First Name', `EMP_LNAME` as 'Last Name',`EMP_MNAME` AS 'Middle Name'" _
        & ",round( ((DATEDIFF( NOW( ) ,  `BIRTH_DATE` ) /12) /31))  AS 'Age', `EMP_SEX` AS 'Gender', `STATUS` AS 'STATUS', `ADDRESS` AS 'ADDRESS', `CONTACT` AS 'CONTACT Number'  FROM `employee`"
        reloadDtg(sql, dtgemplist)
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        sql = "SELECT e.EMPID AS 'Employee Id',concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) as Name " &
        ",  `EMP_AGE` AS 'Age', `BIRTH_DATE` AS 'Birthday', `BIRTH_PLACE` AS 'Birth Place', `STATUS` AS 'Civil Status', `EMP_SEX` AS 'Gender', `STATUS` AS 'Status', `RELIGION` AS 'Religion', `ADDRESS` AS 'ADDRESS'" &
        ", `TERTIARY_CRS` AS 'Tertiary Course', `MASTERAL_CRS` AS 'Masteral Course', `MASTERAL_LVL` AS 'Masteral Level', `DOCTORATE_CRS` AS 'Doctorate Course', `DOCTORATE_LVL` AS 'Doctorate Level', `HIGH_ELI` AS 'Highest Eligibility'" &
        ", `LVL_ELI` AS 'Level of Highest Eligibility', `OTHER_ELI` AS 'Othe Eligibility', `HIGH_MANTRAIN` AS 'Highest Mandatory Training', `DTN_MANTRAIN` AS 'Duration of Mandatory Training', `SPL_TRAIN` AS 'Specialized Training', `DTN_SPLTRAIN` AS 'Duration of Specialized Training'" &
        ", `ACCOUNT_NUM` AS 'Account Number', `RANK` AS 'Rank', `UNIT_ASSIGN` AS 'Unit Assign', `STATUS_APPOINTMENT` AS 'Status of Appointment'" &
        ", `ADMIN` AS 'ADMIN', `UNITCODE` AS 'Unit Code', `ITEM_NUMBER` AS 'Item NUmber', `PRIMARY_DESIG` AS 'Primary Designation'" &
        ",  `AUTH_PRIDESIG` AS 'Authority of Primary Designation', `EFFECTIVE_PRIMARY` AS 'Effective of Primary', `YRS_PRIMARY` AS 'Year in Primary Designation', `DEGS` AS 'Date Entered Government Service'" &
        ", `DEFS` AS 'Date entered of Fire Service', `YRS_FIRESERVICE` AS 'Years of Fire Service', `DAO` AS 'Date Acquired Officership', `DOLP` AS 'Date of Last Promotion'" &
        ", `DATE_RETIREMENT` AS 'Date of Retirement', `CON_DESIG` AS 'Concurrent Designation', `AUTH_CONDESIG` AS 'Authority of Concurrent Designation', `EFFECTIVE_CON` AS 'Effective of Concurrent'" &
        ", `TIN_num` AS 'TIN No.', `PAGIBIG_num` AS 'PAGIBIG No.', `GSIS_num` AS 'GSIS No.', `PHILHEALTH_num` AS 'PHILHEALTH No.'" &
        ", `BADGE_num` AS 'Badge No.', `LANDBANK_num` AS 'LandBank No.', `LONGPAY` AS 'Longpay'" &
        ", `REMARKS` AS 'Remarks' FROM `employee` e, `employee_workinfo` ew WHERE e.`EMPID`=ew.`EMPID`"

        mysqlRetrieve(sql, dtgemplist)
    End Sub

    Private Sub cboCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCategory.SelectedIndexChanged
        If cboCategory.Text = "ID" Then
            sql = "SELECT EMPID  FROM `employee`"
            autocompletetxt(sql, txtempsearch)
        ElseIf cboCategory.Text = "Name" Then
            sql = "SELECT concat(`EMP_LNAME`,', ',`EMP_FNAME`,', ',  `EMP_MNAME`) FROM `employee`"
            autocompletetxt(sql, txtempsearch)
        ElseIf cboCategory.Text = "Unit Assigned" Then
            sql = "SELECT UNIT_ASSIGN FROM `employee_workinfo`"
            autocompletetxt(sql, txtempsearch)
        ElseIf cboCategory.Text = "Account Number" Then
            sql = "SELECT `ACCOUNT_NUM` FROM `employee_workinfo`"
            autocompletetxt(sql, txtempsearch)
        ElseIf cboCategory.Text = "Gender" Then
            sql = "SELECT EMP_SEX FROM `employee`"
            autocompletetxt(sql, txtempsearch)
        Else

        End If
    End Sub

    Private Sub dtgemplist_DoubleClick(sender As Object, e As EventArgs) Handles dtgemplist.DoubleClick
        Try
            Dim form As New FromPreviewProfiles
            form.txtcode.Text = dtgemplist.CurrentRow.Cells(0).Value
            form.ShowDialog()
        Catch ex As Exception
            '  MsgBox(ex.Message)
        End Try


    End Sub



End Class
