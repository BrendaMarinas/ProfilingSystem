﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMenu))
        Dim Animation2 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Dim Animation1 As BunifuAnimatorNS.Animation = New BunifuAnimatorNS.Animation()
        Me.pnlSideBar = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.IconPictureBox2 = New FontAwesome.Sharp.IconPictureBox()
        Me.Logout = New FontAwesome.Sharp.IconButton()
        Me.btnManageUser = New FontAwesome.Sharp.IconButton()
        Me.btnSettings = New FontAwesome.Sharp.IconButton()
        Me.btnleave = New FontAwesome.Sharp.IconButton()
        Me.btnList = New FontAwesome.Sharp.IconButton()
        Me.btnProfiles = New FontAwesome.Sharp.IconButton()
        Me.btnHome = New FontAwesome.Sharp.IconButton()
        Me.PanelLogo = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ImgHome = New System.Windows.Forms.PictureBox()
        Me.pnlHeader = New Bunifu.Framework.UI.BunifuGradientPanel()
        Me.MinBtn = New System.Windows.Forms.PictureBox()
        Me.MaxBtn = New System.Windows.Forms.PictureBox()
        Me.CloseBtn = New System.Windows.Forms.PictureBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.BunifuDragControl1 = New Bunifu.Framework.UI.BunifuDragControl(Me.components)
        Me.pnlContainer = New System.Windows.Forms.Panel()
        Me.animate1 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.animate2 = New BunifuAnimatorNS.BunifuTransition(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.FrmUser1 = New BFPPROFILINGSYSTEM.FormUsers()
        Me.FrmSetting1 = New BFPPROFILINGSYSTEM.FormSettings()
        Me.FrmAddLeave1 = New BFPPROFILINGSYSTEM.FormHistory()
        Me.FrmFindEmployee1 = New BFPPROFILINGSYSTEM.FormListProfiles()
        Me.FrmEmployee1 = New BFPPROFILINGSYSTEM.FormProfiles()
        Me.FrmHome1 = New BFPPROFILINGSYSTEM.FormHome()
        Me.pnlSideBar.SuspendLayout()
        CType(Me.IconPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelLogo.SuspendLayout()
        CType(Me.ImgHome, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlHeader.SuspendLayout()
        CType(Me.MinBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MaxBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CloseBtn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlContainer.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnlSideBar
        '
        Me.pnlSideBar.BackgroundImage = CType(resources.GetObject("pnlSideBar.BackgroundImage"), System.Drawing.Image)
        Me.pnlSideBar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlSideBar.Controls.Add(Me.IconPictureBox2)
        Me.pnlSideBar.Controls.Add(Me.Logout)
        Me.pnlSideBar.Controls.Add(Me.btnManageUser)
        Me.pnlSideBar.Controls.Add(Me.btnSettings)
        Me.pnlSideBar.Controls.Add(Me.btnleave)
        Me.pnlSideBar.Controls.Add(Me.btnList)
        Me.pnlSideBar.Controls.Add(Me.btnProfiles)
        Me.pnlSideBar.Controls.Add(Me.btnHome)
        Me.pnlSideBar.Controls.Add(Me.PanelLogo)
        Me.animate2.SetDecoration(Me.pnlSideBar, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.pnlSideBar, BunifuAnimatorNS.DecorationType.None)
        Me.pnlSideBar.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnlSideBar.GradientBottomLeft = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.pnlSideBar.GradientBottomRight = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.pnlSideBar.GradientTopLeft = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.pnlSideBar.GradientTopRight = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.pnlSideBar.Location = New System.Drawing.Point(0, 0)
        Me.pnlSideBar.Name = "pnlSideBar"
        Me.pnlSideBar.Quality = 10
        Me.pnlSideBar.Size = New System.Drawing.Size(200, 735)
        Me.pnlSideBar.TabIndex = 0
        '
        'IconPictureBox2
        '
        Me.IconPictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.IconPictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.animate2.SetDecoration(Me.IconPictureBox2, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.IconPictureBox2, BunifuAnimatorNS.DecorationType.None)
        Me.IconPictureBox2.ForeColor = System.Drawing.Color.BurlyWood
        Me.IconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.InfoCircle
        Me.IconPictureBox2.IconColor = System.Drawing.Color.BurlyWood
        Me.IconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox2.IconSize = 30
        Me.IconPictureBox2.Location = New System.Drawing.Point(0, 707)
        Me.IconPictureBox2.Margin = New System.Windows.Forms.Padding(0)
        Me.IconPictureBox2.Name = "IconPictureBox2"
        Me.IconPictureBox2.Size = New System.Drawing.Size(33, 30)
        Me.IconPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.IconPictureBox2.TabIndex = 21
        Me.IconPictureBox2.TabStop = False
        '
        'Logout
        '
        Me.Logout.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate2.SetDecoration(Me.Logout, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.Logout, BunifuAnimatorNS.DecorationType.None)
        Me.Logout.Dock = System.Windows.Forms.DockStyle.Top
        Me.Logout.FlatAppearance.BorderSize = 0
        Me.Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Logout.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Logout.ForeColor = System.Drawing.Color.Gainsboro
        Me.Logout.IconChar = FontAwesome.Sharp.IconChar.FileAlt
        Me.Logout.IconColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(2, Byte), Integer))
        Me.Logout.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.Logout.IconSize = 35
        Me.Logout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Logout.Location = New System.Drawing.Point(0, 568)
        Me.Logout.Name = "Logout"
        Me.Logout.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.Logout.Size = New System.Drawing.Size(200, 51)
        Me.Logout.TabIndex = 20
        Me.Logout.Text = "LOGOUT"
        Me.Logout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Logout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Logout.UseVisualStyleBackColor = False
        '
        'btnManageUser
        '
        Me.btnManageUser.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate2.SetDecoration(Me.btnManageUser, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.btnManageUser, BunifuAnimatorNS.DecorationType.None)
        Me.btnManageUser.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnManageUser.FlatAppearance.BorderSize = 0
        Me.btnManageUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnManageUser.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnManageUser.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnManageUser.IconChar = FontAwesome.Sharp.IconChar.UsersCog
        Me.btnManageUser.IconColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(2, Byte), Integer))
        Me.btnManageUser.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.btnManageUser.IconSize = 35
        Me.btnManageUser.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnManageUser.Location = New System.Drawing.Point(0, 517)
        Me.btnManageUser.Name = "btnManageUser"
        Me.btnManageUser.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnManageUser.Size = New System.Drawing.Size(200, 51)
        Me.btnManageUser.TabIndex = 19
        Me.btnManageUser.Text = "MANAGE USERS"
        Me.btnManageUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnManageUser.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnManageUser.UseVisualStyleBackColor = False
        '
        'btnSettings
        '
        Me.btnSettings.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate2.SetDecoration(Me.btnSettings, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.btnSettings, BunifuAnimatorNS.DecorationType.None)
        Me.btnSettings.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnSettings.FlatAppearance.BorderSize = 0
        Me.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSettings.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSettings.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnSettings.IconChar = FontAwesome.Sharp.IconChar.Cogs
        Me.btnSettings.IconColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(2, Byte), Integer))
        Me.btnSettings.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.btnSettings.IconSize = 35
        Me.btnSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSettings.Location = New System.Drawing.Point(0, 466)
        Me.btnSettings.Name = "btnSettings"
        Me.btnSettings.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnSettings.Size = New System.Drawing.Size(200, 51)
        Me.btnSettings.TabIndex = 18
        Me.btnSettings.Text = "SETTINGS"
        Me.btnSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnSettings.UseVisualStyleBackColor = False
        '
        'btnleave
        '
        Me.btnleave.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate2.SetDecoration(Me.btnleave, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.btnleave, BunifuAnimatorNS.DecorationType.None)
        Me.btnleave.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnleave.FlatAppearance.BorderSize = 0
        Me.btnleave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnleave.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnleave.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnleave.IconChar = FontAwesome.Sharp.IconChar.Outdent
        Me.btnleave.IconColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(2, Byte), Integer))
        Me.btnleave.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.btnleave.IconSize = 35
        Me.btnleave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnleave.Location = New System.Drawing.Point(0, 415)
        Me.btnleave.Name = "btnleave"
        Me.btnleave.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnleave.Size = New System.Drawing.Size(200, 51)
        Me.btnleave.TabIndex = 17
        Me.btnleave.Text = "HISTORY"
        Me.btnleave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnleave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnleave.UseVisualStyleBackColor = False
        '
        'btnList
        '
        Me.btnList.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate2.SetDecoration(Me.btnList, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.btnList, BunifuAnimatorNS.DecorationType.None)
        Me.btnList.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnList.FlatAppearance.BorderSize = 0
        Me.btnList.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnList.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnList.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnList.IconChar = FontAwesome.Sharp.IconChar.List
        Me.btnList.IconColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(2, Byte), Integer))
        Me.btnList.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.btnList.IconSize = 35
        Me.btnList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnList.Location = New System.Drawing.Point(0, 364)
        Me.btnList.Name = "btnList"
        Me.btnList.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnList.Size = New System.Drawing.Size(200, 51)
        Me.btnList.TabIndex = 16
        Me.btnList.Text = "LIST PROFILES"
        Me.btnList.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnList.UseVisualStyleBackColor = False
        '
        'btnProfiles
        '
        Me.btnProfiles.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate2.SetDecoration(Me.btnProfiles, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.btnProfiles, BunifuAnimatorNS.DecorationType.None)
        Me.btnProfiles.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnProfiles.FlatAppearance.BorderSize = 0
        Me.btnProfiles.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProfiles.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProfiles.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnProfiles.IconChar = FontAwesome.Sharp.IconChar.IdCard
        Me.btnProfiles.IconColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(2, Byte), Integer))
        Me.btnProfiles.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.btnProfiles.IconSize = 35
        Me.btnProfiles.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnProfiles.Location = New System.Drawing.Point(0, 313)
        Me.btnProfiles.Name = "btnProfiles"
        Me.btnProfiles.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnProfiles.Size = New System.Drawing.Size(200, 51)
        Me.btnProfiles.TabIndex = 15
        Me.btnProfiles.Text = "BFP PROFILES"
        Me.btnProfiles.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnProfiles.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnProfiles.UseVisualStyleBackColor = False
        '
        'btnHome
        '
        Me.btnHome.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate2.SetDecoration(Me.btnHome, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.btnHome, BunifuAnimatorNS.DecorationType.None)
        Me.btnHome.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnHome.FlatAppearance.BorderSize = 0
        Me.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHome.Font = New System.Drawing.Font("Book Antiqua", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHome.ForeColor = System.Drawing.Color.Gainsboro
        Me.btnHome.IconChar = FontAwesome.Sharp.IconChar.HouseUser
        Me.btnHome.IconColor = System.Drawing.Color.FromArgb(CType(CType(235, Byte), Integer), CType(CType(209, Byte), Integer), CType(CType(2, Byte), Integer))
        Me.btnHome.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.btnHome.IconSize = 35
        Me.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHome.Location = New System.Drawing.Point(0, 262)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Padding = New System.Windows.Forms.Padding(10, 0, 20, 0)
        Me.btnHome.Size = New System.Drawing.Size(200, 51)
        Me.btnHome.TabIndex = 14
        Me.btnHome.Text = "HOME"
        Me.btnHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnHome.UseVisualStyleBackColor = False
        '
        'PanelLogo
        '
        Me.PanelLogo.BackColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.PanelLogo.Controls.Add(Me.Panel1)
        Me.PanelLogo.Controls.Add(Me.Label1)
        Me.PanelLogo.Controls.Add(Me.ImgHome)
        Me.animate2.SetDecoration(Me.PanelLogo, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.PanelLogo, BunifuAnimatorNS.DecorationType.None)
        Me.PanelLogo.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelLogo.Location = New System.Drawing.Point(0, 0)
        Me.PanelLogo.Name = "PanelLogo"
        Me.PanelLogo.Size = New System.Drawing.Size(200, 262)
        Me.PanelLogo.TabIndex = 13
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.LightSalmon
        Me.animate2.SetDecoration(Me.Panel1, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.Panel1, BunifuAnimatorNS.DecorationType.None)
        Me.Panel1.Location = New System.Drawing.Point(16, 213)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(168, 6)
        Me.Panel1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.animate1.SetDecoration(Me.Label1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.Label1, BunifuAnimatorNS.DecorationType.None)
        Me.Label1.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(12, 167)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 42)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "PANGASINAN" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "PROVINCIAL OFFICE" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ImgHome
        '
        Me.animate1.SetDecoration(Me.ImgHome, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.ImgHome, BunifuAnimatorNS.DecorationType.None)
        Me.ImgHome.Image = CType(resources.GetObject("ImgHome.Image"), System.Drawing.Image)
        Me.ImgHome.Location = New System.Drawing.Point(36, 38)
        Me.ImgHome.Name = "ImgHome"
        Me.ImgHome.Size = New System.Drawing.Size(121, 116)
        Me.ImgHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ImgHome.TabIndex = 0
        Me.ImgHome.TabStop = False
        '
        'pnlHeader
        '
        Me.pnlHeader.BackgroundImage = CType(resources.GetObject("pnlHeader.BackgroundImage"), System.Drawing.Image)
        Me.pnlHeader.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pnlHeader.Controls.Add(Me.MinBtn)
        Me.pnlHeader.Controls.Add(Me.MaxBtn)
        Me.pnlHeader.Controls.Add(Me.CloseBtn)
        Me.pnlHeader.Controls.Add(Me.Panel3)
        Me.pnlHeader.Controls.Add(Me.Panel2)
        Me.pnlHeader.Controls.Add(Me.Label5)
        Me.pnlHeader.Controls.Add(Me.PictureBox1)
        Me.pnlHeader.Controls.Add(Me.Label4)
        Me.pnlHeader.Controls.Add(Me.lblDate)
        Me.pnlHeader.Controls.Add(Me.Panel4)
        Me.pnlHeader.Controls.Add(Me.lblFormTitle)
        Me.animate2.SetDecoration(Me.pnlHeader, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.pnlHeader, BunifuAnimatorNS.DecorationType.None)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.GradientBottomLeft = System.Drawing.Color.Maroon
        Me.pnlHeader.GradientBottomRight = System.Drawing.Color.Maroon
        Me.pnlHeader.GradientTopLeft = System.Drawing.Color.Maroon
        Me.pnlHeader.GradientTopRight = System.Drawing.Color.Maroon
        Me.pnlHeader.Location = New System.Drawing.Point(200, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Quality = 10
        Me.pnlHeader.Size = New System.Drawing.Size(1138, 75)
        Me.pnlHeader.TabIndex = 1
        '
        'MinBtn
        '
        Me.MinBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MinBtn.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.MinBtn, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.MinBtn, BunifuAnimatorNS.DecorationType.None)
        Me.MinBtn.Image = CType(resources.GetObject("MinBtn.Image"), System.Drawing.Image)
        Me.MinBtn.Location = New System.Drawing.Point(1061, 4)
        Me.MinBtn.Name = "MinBtn"
        Me.MinBtn.Size = New System.Drawing.Size(20, 20)
        Me.MinBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MinBtn.TabIndex = 28
        Me.MinBtn.TabStop = False
        '
        'MaxBtn
        '
        Me.MaxBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.MaxBtn.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.MaxBtn, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.MaxBtn, BunifuAnimatorNS.DecorationType.None)
        Me.MaxBtn.Image = CType(resources.GetObject("MaxBtn.Image"), System.Drawing.Image)
        Me.MaxBtn.Location = New System.Drawing.Point(1087, 4)
        Me.MaxBtn.Name = "MaxBtn"
        Me.MaxBtn.Size = New System.Drawing.Size(20, 20)
        Me.MaxBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MaxBtn.TabIndex = 27
        Me.MaxBtn.TabStop = False
        '
        'CloseBtn
        '
        Me.CloseBtn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CloseBtn.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.CloseBtn, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.CloseBtn, BunifuAnimatorNS.DecorationType.None)
        Me.CloseBtn.Image = CType(resources.GetObject("CloseBtn.Image"), System.Drawing.Image)
        Me.CloseBtn.Location = New System.Drawing.Point(1113, 4)
        Me.CloseBtn.Name = "CloseBtn"
        Me.CloseBtn.Size = New System.Drawing.Size(20, 20)
        Me.CloseBtn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.CloseBtn.TabIndex = 26
        Me.CloseBtn.TabStop = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Black
        Me.Panel3.Controls.Add(Me.Label3)
        Me.animate2.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.Panel3, BunifuAnimatorNS.DecorationType.None)
        Me.Panel3.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Panel3.Location = New System.Drawing.Point(83, 59)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(440, 5)
        Me.Panel3.TabIndex = 25
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Black
        Me.animate2.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.Panel2, BunifuAnimatorNS.DecorationType.None)
        Me.Panel2.Location = New System.Drawing.Point(83, 30)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(440, 5)
        Me.Panel2.TabIndex = 24
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.Label5, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.Label5, BunifuAnimatorNS.DecorationType.None)
        Me.Label5.Font = New System.Drawing.Font("Book Antiqua", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Label5.Location = New System.Drawing.Point(81, 9)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(201, 19)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Republic of The Phillipines"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.PictureBox1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.PictureBox1, BunifuAnimatorNS.DecorationType.None)
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(60, 67)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.Label4, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.Label4, BunifuAnimatorNS.DecorationType.None)
        Me.Label4.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(789, 37)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 21)
        Me.Label4.TabIndex = 21
        Me.Label4.Text = "TODAY :"
        '
        'lblDate
        '
        Me.lblDate.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblDate.AutoSize = True
        Me.lblDate.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.lblDate, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.lblDate, BunifuAnimatorNS.DecorationType.None)
        Me.lblDate.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.Color.White
        Me.lblDate.Location = New System.Drawing.Point(867, 37)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(82, 21)
        Me.lblDate.TabIndex = 19
        Me.lblDate.Text = "DateTime"
        '
        'lblFormTitle
        '
        Me.lblFormTitle.AutoSize = True
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.lblFormTitle, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.lblFormTitle, BunifuAnimatorNS.DecorationType.None)
        Me.lblFormTitle.Font = New System.Drawing.Font("Book Antiqua", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Yellow
        Me.lblFormTitle.Location = New System.Drawing.Point(77, 32)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.Size = New System.Drawing.Size(449, 52)
        Me.lblFormTitle.TabIndex = 17
        Me.lblFormTitle.Text = "BUREAU OF FIRE PROTECTION REGION I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'BunifuDragControl1
        '
        Me.BunifuDragControl1.Fixed = True
        Me.BunifuDragControl1.Horizontal = True
        Me.BunifuDragControl1.TargetControl = Me.pnlHeader
        Me.BunifuDragControl1.Vertical = True
        '
        'pnlContainer
        '
        Me.pnlContainer.Controls.Add(Me.FrmUser1)
        Me.pnlContainer.Controls.Add(Me.FrmSetting1)
        Me.pnlContainer.Controls.Add(Me.FrmAddLeave1)
        Me.pnlContainer.Controls.Add(Me.FrmFindEmployee1)
        Me.pnlContainer.Controls.Add(Me.FrmEmployee1)
        Me.pnlContainer.Controls.Add(Me.FrmHome1)
        Me.animate2.SetDecoration(Me.pnlContainer, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.pnlContainer, BunifuAnimatorNS.DecorationType.None)
        Me.pnlContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlContainer.Location = New System.Drawing.Point(200, 75)
        Me.pnlContainer.Name = "pnlContainer"
        Me.pnlContainer.Size = New System.Drawing.Size(1138, 660)
        Me.pnlContainer.TabIndex = 2
        '
        'animate1
        '
        Me.animate1.AnimationType = BunifuAnimatorNS.AnimationType.Particles
        Me.animate1.Cursor = Nothing
        Animation2.AnimateOnlyDifferences = True
        Animation2.BlindCoeff = CType(resources.GetObject("Animation2.BlindCoeff"), System.Drawing.PointF)
        Animation2.LeafCoeff = 0!
        Animation2.MaxTime = 1.0!
        Animation2.MinTime = 0!
        Animation2.MosaicCoeff = CType(resources.GetObject("Animation2.MosaicCoeff"), System.Drawing.PointF)
        Animation2.MosaicShift = CType(resources.GetObject("Animation2.MosaicShift"), System.Drawing.PointF)
        Animation2.MosaicSize = 1
        Animation2.Padding = New System.Windows.Forms.Padding(100, 50, 100, 150)
        Animation2.RotateCoeff = 0!
        Animation2.RotateLimit = 0!
        Animation2.ScaleCoeff = CType(resources.GetObject("Animation2.ScaleCoeff"), System.Drawing.PointF)
        Animation2.SlideCoeff = CType(resources.GetObject("Animation2.SlideCoeff"), System.Drawing.PointF)
        Animation2.TimeCoeff = 2.0!
        Animation2.TransparencyCoeff = 0!
        Me.animate1.DefaultAnimation = Animation2
        '
        'animate2
        '
        Me.animate2.AnimationType = BunifuAnimatorNS.AnimationType.HorizSlide
        Me.animate2.Cursor = Nothing
        Animation1.AnimateOnlyDifferences = True
        Animation1.BlindCoeff = CType(resources.GetObject("Animation1.BlindCoeff"), System.Drawing.PointF)
        Animation1.LeafCoeff = 0!
        Animation1.MaxTime = 1.0!
        Animation1.MinTime = 0!
        Animation1.MosaicCoeff = CType(resources.GetObject("Animation1.MosaicCoeff"), System.Drawing.PointF)
        Animation1.MosaicShift = CType(resources.GetObject("Animation1.MosaicShift"), System.Drawing.PointF)
        Animation1.MosaicSize = 0
        Animation1.Padding = New System.Windows.Forms.Padding(0)
        Animation1.RotateCoeff = 0!
        Animation1.RotateLimit = 0!
        Animation1.ScaleCoeff = CType(resources.GetObject("Animation1.ScaleCoeff"), System.Drawing.PointF)
        Animation1.SlideCoeff = CType(resources.GetObject("Animation1.SlideCoeff"), System.Drawing.PointF)
        Animation1.TimeCoeff = 0!
        Animation1.TransparencyCoeff = 0!
        Me.animate2.DefaultAnimation = Animation1
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.animate1.SetDecoration(Me.Label3, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.Label3, BunifuAnimatorNS.DecorationType.None)
        Me.Label3.Location = New System.Drawing.Point(324, 4)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Label3"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Gray
        Me.animate2.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.animate1.SetDecoration(Me.Panel4, BunifuAnimatorNS.DecorationType.None)
        Me.Panel4.Location = New System.Drawing.Point(783, 32)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(355, 32)
        Me.Panel4.TabIndex = 29
        '
        'FrmUser1
        '
        Me.FrmUser1.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.FrmUser1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.FrmUser1, BunifuAnimatorNS.DecorationType.None)
        Me.FrmUser1.Location = New System.Drawing.Point(12, 304)
        Me.FrmUser1.Name = "FrmUser1"
        Me.FrmUser1.Size = New System.Drawing.Size(58, 61)
        Me.FrmUser1.TabIndex = 5
        '
        'FrmSetting1
        '
        Me.FrmSetting1.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.FrmSetting1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.FrmSetting1, BunifuAnimatorNS.DecorationType.None)
        Me.FrmSetting1.Location = New System.Drawing.Point(12, 253)
        Me.FrmSetting1.Name = "FrmSetting1"
        Me.FrmSetting1.Size = New System.Drawing.Size(10, 32)
        Me.FrmSetting1.TabIndex = 4
        '
        'FrmAddLeave1
        '
        Me.FrmAddLeave1.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.FrmAddLeave1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.FrmAddLeave1, BunifuAnimatorNS.DecorationType.None)
        Me.FrmAddLeave1.Location = New System.Drawing.Point(12, 181)
        Me.FrmAddLeave1.Name = "FrmAddLeave1"
        Me.FrmAddLeave1.Size = New System.Drawing.Size(58, 49)
        Me.FrmAddLeave1.TabIndex = 3
        '
        'FrmFindEmployee1
        '
        Me.FrmFindEmployee1.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.FrmFindEmployee1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.FrmFindEmployee1, BunifuAnimatorNS.DecorationType.None)
        Me.FrmFindEmployee1.Location = New System.Drawing.Point(6, 117)
        Me.FrmFindEmployee1.Name = "FrmFindEmployee1"
        Me.FrmFindEmployee1.Size = New System.Drawing.Size(50, 58)
        Me.FrmFindEmployee1.TabIndex = 2
        '
        'FrmEmployee1
        '
        Me.FrmEmployee1.BackColor = System.Drawing.Color.Transparent
        Me.animate1.SetDecoration(Me.FrmEmployee1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.FrmEmployee1, BunifuAnimatorNS.DecorationType.None)
        Me.FrmEmployee1.ForeColor = System.Drawing.Color.Black
        Me.FrmEmployee1.Location = New System.Drawing.Point(6, 46)
        Me.FrmEmployee1.Name = "FrmEmployee1"
        Me.FrmEmployee1.Size = New System.Drawing.Size(46, 21)
        Me.FrmEmployee1.TabIndex = 1
        Me.FrmEmployee1.Visible = False
        '
        'FrmHome1
        '
        Me.FrmHome1.BackColor = System.Drawing.Color.FromArgb(CType(CType(66, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.animate1.SetDecoration(Me.FrmHome1, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me.FrmHome1, BunifuAnimatorNS.DecorationType.None)
        Me.FrmHome1.Location = New System.Drawing.Point(3, 3)
        Me.FrmHome1.Name = "FrmHome1"
        Me.FrmHome1.Size = New System.Drawing.Size(61, 37)
        Me.FrmHome1.TabIndex = 0
        Me.FrmHome1.Visible = False
        '
        'FormMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1338, 735)
        Me.Controls.Add(Me.pnlContainer)
        Me.Controls.Add(Me.pnlHeader)
        Me.Controls.Add(Me.pnlSideBar)
        Me.animate1.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.animate2.SetDecoration(Me, BunifuAnimatorNS.DecorationType.None)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.pnlSideBar.ResumeLayout(False)
        CType(Me.IconPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelLogo.ResumeLayout(False)
        Me.PanelLogo.PerformLayout()
        CType(Me.ImgHome, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        CType(Me.MinBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MaxBtn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CloseBtn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlContainer.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnlSideBar As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents pnlHeader As Bunifu.Framework.UI.BunifuGradientPanel
    Friend WithEvents BunifuDragControl1 As Bunifu.Framework.UI.BunifuDragControl
    Friend WithEvents pnlContainer As Panel
    Friend WithEvents animate1 As BunifuAnimatorNS.BunifuTransition
    Friend WithEvents animate2 As BunifuAnimatorNS.BunifuTransition
    Friend WithEvents FrmHome1 As FormHome
    Friend WithEvents FrmEmployee1 As FormProfiles
    Friend WithEvents FrmFindEmployee1 As FormListProfiles
    Friend WithEvents FrmAddLeave1 As FormHistory
    Friend WithEvents FrmSetting1 As FormSettings
    Friend WithEvents FrmUser1 As FormUsers
    Friend WithEvents Logout As FontAwesome.Sharp.IconButton
    Friend WithEvents btnManageUser As FontAwesome.Sharp.IconButton
    Friend WithEvents btnSettings As FontAwesome.Sharp.IconButton
    Friend WithEvents btnleave As FontAwesome.Sharp.IconButton
    Friend WithEvents btnList As FontAwesome.Sharp.IconButton
    Friend WithEvents btnProfiles As FontAwesome.Sharp.IconButton
    Friend WithEvents btnHome As FontAwesome.Sharp.IconButton
    Friend WithEvents PanelLogo As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents ImgHome As PictureBox
    Friend WithEvents lblFormTitle As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Label4 As Label
    Friend WithEvents IconPictureBox2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MinBtn As PictureBox
    Friend WithEvents MaxBtn As PictureBox
    Friend WithEvents CloseBtn As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel4 As Panel
End Class
