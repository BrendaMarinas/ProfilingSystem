﻿Public Class FormMenu

    Public Sub addContent(frm As UserControl)

        Try
            pnlContainer.Controls.Clear()
            Dim f As UserControl = New UserControl()
            f = frm
            pnlContainer.Controls.Add(f)
            f.Dock = DockStyle.Fill
            f.Visible = False
            f.BringToFront()
            animate1.ShowSync(f)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        addContent(FrmHome1)
        btnHome.Select()

    End Sub

    Private Sub BunifuImageButton1_Click(sender As Object, e As EventArgs)
        Process.Start("")
    End Sub

    Private Sub BunifuImageButton2_Click(sender As Object, e As EventArgs)
        Process.Start("https://web.facebook.com/onnaj.soicalap")
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        addContent(FrmHome1)
    End Sub

    Private Sub btnProfiles_Click(sender As Object, e As EventArgs) Handles btnProfiles.Click
        addContent(FrmEmployee1)
    End Sub

    Private Sub btnList_Click(sender As Object, e As EventArgs) Handles btnList.Click
        addContent(FrmFindEmployee1)
    End Sub

    Private Sub btnleave_Click(sender As Object, e As EventArgs) Handles btnleave.Click
        addContent(FrmAddLeave1)
    End Sub

    Private Sub btnSettings_Click(sender As Object, e As EventArgs) Handles btnSettings.Click
        addContent(FrmSetting1)
    End Sub

    Private Sub btnManageUser_Click(sender As Object, e As EventArgs) Handles btnManageUser.Click
        addContent(FrmUser1)
    End Sub

    Private Sub Reports_Click(sender As Object, e As EventArgs) Handles Logout.Click
        Me.Close()
        LoginForm1.UsernameTextBox.Clear()
        LoginForm1.PasswordTextBox.Clear()
        LoginForm1.UsernameTextBox.Focus()
        LoginForm1.Show()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblDate.Text = DateTime.Now.ToString("dddd, MMM dd yyyy hh:mm:ss tt")
    End Sub

    Private Sub MinBtn_Click(sender As Object, e As EventArgs) Handles MinBtn.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub MaxBtn_Click(sender As Object, e As EventArgs) Handles MaxBtn.Click
        Me.WindowState = FormWindowState.Maximized
    End Sub

    Private Sub CloseBtn_Click(sender As Object, e As EventArgs) Handles CloseBtn.Click
        Application.Exit()
    End Sub

    Private Sub IconPictureBox2_Click(sender As Object, e As EventArgs) Handles IconPictureBox2.Click

    End Sub
End Class
