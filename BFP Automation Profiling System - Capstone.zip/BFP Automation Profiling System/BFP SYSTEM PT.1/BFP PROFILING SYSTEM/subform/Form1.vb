﻿Public Class Form1
    Private Sub txtmname_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub GroupBox10_Enter(sender As Object, e As EventArgs) Handles GroupBox10.Enter

    End Sub

    Private Sub Label60_Click(sender As Object, e As EventArgs) Handles Label60.Click

    End Sub

    Private Sub txtlngpaynum_Click(sender As Object, e As EventArgs) Handles txtlngpaynum.Click

    End Sub

    Private Sub txtlndbnknum_Click(sender As Object, e As EventArgs) Handles txtlndbnknum.Click

    End Sub

    Private Sub txtbadgenum_Click(sender As Object, e As EventArgs) Handles txtbadgenum.Click

    End Sub

    Private Sub txtphlthnum_Click(sender As Object, e As EventArgs) Handles txtphlthnum.Click

    End Sub

    Private Sub txtgsisnum_Click(sender As Object, e As EventArgs) Handles txtgsisnum.Click

    End Sub

    Private Sub txtpibgnum_Click(sender As Object, e As EventArgs) Handles txtpibgnum.Click

    End Sub

    Private Sub txttinnum_Click(sender As Object, e As EventArgs) Handles txttinnum.Click

    End Sub

    Private Sub Label53_Click(sender As Object, e As EventArgs) Handles Label53.Click

    End Sub

    Private Sub Label54_Click(sender As Object, e As EventArgs) Handles Label54.Click

    End Sub

    Private Sub Label55_Click(sender As Object, e As EventArgs) Handles Label55.Click

    End Sub

    Private Sub Label56_Click(sender As Object, e As EventArgs) Handles Label56.Click

    End Sub

    Private Sub Label57_Click(sender As Object, e As EventArgs) Handles Label57.Click

    End Sub

    Private Sub Label58_Click(sender As Object, e As EventArgs) Handles Label58.Click

    End Sub

    Private Sub Label59_Click(sender As Object, e As EventArgs) Handles Label59.Click

    End Sub

    Private Sub txtremarks_Click(sender As Object, e As EventArgs) Handles txtremarks.Click

    End Sub

    Private Sub Label18_Click(sender As Object, e As EventArgs) Handles Label18.Click

    End Sub

    Private Sub txtpridesig_Click(sender As Object, e As EventArgs) Handles txtpridesig.Click

    End Sub

    Private Sub Label19_Click(sender As Object, e As EventArgs) Handles Label19.Click

    End Sub

    Private Sub txtapd_Click(sender As Object, e As EventArgs) Handles txtapd.Click

    End Sub

    Private Sub Label36_Click(sender As Object, e As EventArgs) Handles Label36.Click

    End Sub

    Private Sub txtyrspridesig_Click(sender As Object, e As EventArgs) Handles txtyrspridesig.Click

    End Sub

    Private Sub Label42_Click(sender As Object, e As EventArgs) Handles Label42.Click

    End Sub

    Private Sub dtdegs_Click(sender As Object, e As EventArgs) Handles dtdegs.Click

    End Sub

    Private Sub Label47_Click(sender As Object, e As EventArgs) Handles Label47.Click

    End Sub

    Private Sub cbosoa_Click(sender As Object, e As EventArgs) Handles cbosoa.Click

    End Sub

    Private Sub dtdolp_Click(sender As Object, e As EventArgs) Handles dtdolp.Click

    End Sub

    Private Sub dtdao_Click(sender As Object, e As EventArgs) Handles dtdao.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label48_Click(sender As Object, e As EventArgs) Handles Label48.Click

    End Sub

    Private Sub Label45_Click(sender As Object, e As EventArgs) Handles Label45.Click

    End Sub

    Private Sub txtdateretire_Click(sender As Object, e As EventArgs) Handles txtdateretire.Click

    End Sub

    Private Sub Label44_Click(sender As Object, e As EventArgs) Handles Label44.Click

    End Sub

    Private Sub Label41_Click(sender As Object, e As EventArgs) Handles Label41.Click

    End Sub

    Private Sub Label49_Click(sender As Object, e As EventArgs) Handles Label49.Click

    End Sub

    Private Sub dteffectivecon_Click(sender As Object, e As EventArgs) Handles dteffectivecon.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub dtdefs_Click(sender As Object, e As EventArgs) Handles dtdefs.Click

    End Sub
End Class