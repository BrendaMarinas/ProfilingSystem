﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FromPreviewProfiles
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FromPreviewProfiles))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.IconPictureBox1 = New FontAwesome.Sharp.IconPictureBox()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtemerg = New System.Windows.Forms.Label()
        Me.txtgender = New System.Windows.Forms.Label()
        Me.txtcontact = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtreligion = New System.Windows.Forms.Label()
        Me.txtzipcode = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtprovince = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtbplace = New System.Windows.Forms.Label()
        Me.txtstatus = New System.Windows.Forms.Label()
        Me.txtage = New System.Windows.Forms.Label()
        Me.txtsfxname = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.dtpdbirth = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtmname = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.cbomunicipality = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtcode = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtfname = New System.Windows.Forms.Label()
        Me.txtlname = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Barangay = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.IconPictureBox2 = New FontAwesome.Sharp.IconPictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtothereli = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.cbolvleli = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.txtdspecialtrain = New System.Windows.Forms.Label()
        Me.txtspecialtrain = New System.Windows.Forms.Label()
        Me.txtdmantrain = New System.Windows.Forms.Label()
        Me.cbohighmantrain = New System.Windows.Forms.Label()
        Me.cbohigheli = New System.Windows.Forms.Label()
        Me.txtdoclvl = New System.Windows.Forms.Label()
        Me.txtdoccrs = New System.Windows.Forms.Label()
        Me.txtmascrs = New System.Windows.Forms.Label()
        Me.txtmaslvl = New System.Windows.Forms.Label()
        Me.txtcrs = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.txtremarks = New System.Windows.Forms.Label()
        Me.txtlngpaynum = New System.Windows.Forms.Label()
        Me.txtlndbnknum = New System.Windows.Forms.Label()
        Me.txtbadgenum = New System.Windows.Forms.Label()
        Me.txtphlthnum = New System.Windows.Forms.Label()
        Me.txtgsisnum = New System.Windows.Forms.Label()
        Me.txtpibgnum = New System.Windows.Forms.Label()
        Me.txttinnum = New System.Windows.Forms.Label()
        Me.dteffectivecon = New System.Windows.Forms.Label()
        Me.txtauthcondesig = New System.Windows.Forms.Label()
        Me.txtcondesig = New System.Windows.Forms.Label()
        Me.txtdateretire = New System.Windows.Forms.Label()
        Me.cbosoa = New System.Windows.Forms.Label()
        Me.dtdolp = New System.Windows.Forms.Label()
        Me.dtdao = New System.Windows.Forms.Label()
        Me.txtyrsfiresvc = New System.Windows.Forms.Label()
        Me.dtdefs = New System.Windows.Forms.Label()
        Me.dtdegs = New System.Windows.Forms.Label()
        Me.txtyrspridesig = New System.Windows.Forms.Label()
        Me.dteop = New System.Windows.Forms.Label()
        Me.txtapd = New System.Windows.Forms.Label()
        Me.txtpridesig = New System.Windows.Forms.Label()
        Me.txtitemnum = New System.Windows.Forms.Label()
        Me.txtrank = New System.Windows.Forms.Label()
        Me.txtunitcode = New System.Windows.Forms.Label()
        Me.cbounitassign = New System.Windows.Forms.Label()
        Me.txtadmin = New System.Windows.Forms.Label()
        Me.txtaccnum = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.IconPictureBox3 = New FontAwesome.Sharp.IconPictureBox()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel6.SuspendLayout()
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel7.SuspendLayout()
        CType(Me.IconPictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.IconPictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Location = New System.Drawing.Point(93, 16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(135, 135)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 66
        Me.PictureBox1.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1131, 10)
        Me.Panel1.TabIndex = 67
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Black
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 565)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1131, 10)
        Me.Panel2.TabIndex = 68
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Black
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel3.Location = New System.Drawing.Point(0, 10)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(10, 555)
        Me.Panel3.TabIndex = 69
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Black
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel4.Location = New System.Drawing.Point(1121, 10)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(10, 555)
        Me.Panel4.TabIndex = 70
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Black
        Me.Panel6.Controls.Add(Me.IconPictureBox1)
        Me.Panel6.Controls.Add(Me.Panel7)
        Me.Panel6.Controls.Add(Me.txtemerg)
        Me.Panel6.Controls.Add(Me.txtgender)
        Me.Panel6.Controls.Add(Me.txtcontact)
        Me.Panel6.Controls.Add(Me.Label3)
        Me.Panel6.Controls.Add(Me.txtreligion)
        Me.Panel6.Controls.Add(Me.txtzipcode)
        Me.Panel6.Controls.Add(Me.Label5)
        Me.Panel6.Controls.Add(Me.Label25)
        Me.Panel6.Controls.Add(Me.txtprovince)
        Me.Panel6.Controls.Add(Me.Label30)
        Me.Panel6.Controls.Add(Me.txtbplace)
        Me.Panel6.Controls.Add(Me.txtstatus)
        Me.Panel6.Controls.Add(Me.txtage)
        Me.Panel6.Controls.Add(Me.txtsfxname)
        Me.Panel6.Controls.Add(Me.Label26)
        Me.Panel6.Controls.Add(Me.dtpdbirth)
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Controls.Add(Me.txtmname)
        Me.Panel6.Controls.Add(Me.Label27)
        Me.Panel6.Controls.Add(Me.cbomunicipality)
        Me.Panel6.Controls.Add(Me.PictureBox1)
        Me.Panel6.Controls.Add(Me.Panel5)
        Me.Panel6.Controls.Add(Me.Label7)
        Me.Panel6.Controls.Add(Me.txtcode)
        Me.Panel6.Controls.Add(Me.Label2)
        Me.Panel6.Controls.Add(Me.Label6)
        Me.Panel6.Controls.Add(Me.Label22)
        Me.Panel6.Controls.Add(Me.Label20)
        Me.Panel6.Controls.Add(Me.Label8)
        Me.Panel6.Controls.Add(Me.txtfname)
        Me.Panel6.Controls.Add(Me.txtlname)
        Me.Panel6.Controls.Add(Me.Label28)
        Me.Panel6.Controls.Add(Me.Label31)
        Me.Panel6.Controls.Add(Me.Barangay)
        Me.Panel6.Controls.Add(Me.Label29)
        Me.Panel6.Controls.Add(Me.Label21)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel6.Location = New System.Drawing.Point(10, 10)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(353, 555)
        Me.Panel6.TabIndex = 72
        '
        'IconPictureBox1
        '
        Me.IconPictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox1.ForeColor = System.Drawing.Color.OrangeRed
        Me.IconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.UserAlt
        Me.IconPictureBox1.IconColor = System.Drawing.Color.OrangeRed
        Me.IconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox1.IconSize = 37
        Me.IconPictureBox1.Location = New System.Drawing.Point(7, 179)
        Me.IconPictureBox1.Name = "IconPictureBox1"
        Me.IconPictureBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.IconPictureBox1.Size = New System.Drawing.Size(39, 37)
        Me.IconPictureBox1.TabIndex = 117
        Me.IconPictureBox1.TabStop = False
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Panel7.Controls.Add(Me.Label34)
        Me.Panel7.Location = New System.Drawing.Point(46, 179)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(248, 36)
        Me.Panel7.TabIndex = 115
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label34.Location = New System.Drawing.Point(14, 7)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(221, 20)
        Me.Label34.TabIndex = 113
        Me.Label34.Text = "PERSONAL INFORMATION"
        '
        'txtemerg
        '
        Me.txtemerg.AutoSize = True
        Me.txtemerg.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtemerg.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtemerg.Location = New System.Drawing.Point(213, 485)
        Me.txtemerg.Name = "txtemerg"
        Me.txtemerg.Size = New System.Drawing.Size(75, 18)
        Me.txtemerg.TabIndex = 105
        Me.txtemerg.Text = "EmerNum"
        '
        'txtgender
        '
        Me.txtgender.AutoSize = True
        Me.txtgender.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgender.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtgender.Location = New System.Drawing.Point(17, 340)
        Me.txtgender.Name = "txtgender"
        Me.txtgender.Size = New System.Drawing.Size(56, 18)
        Me.txtgender.TabIndex = 113
        Me.txtgender.Text = "Gender"
        '
        'txtcontact
        '
        Me.txtcontact.AutoSize = True
        Me.txtcontact.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcontact.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtcontact.Location = New System.Drawing.Point(100, 485)
        Me.txtcontact.Name = "txtcontact"
        Me.txtcontact.Size = New System.Drawing.Size(91, 18)
        Me.txtcontact.TabIndex = 104
        Me.txtcontact.Text = "ContactNum"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label3.ForeColor = System.Drawing.Color.IndianRed
        Me.Label3.Location = New System.Drawing.Point(13, 324)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 112
        Me.Label3.Text = "Gender:"
        '
        'txtreligion
        '
        Me.txtreligion.AutoSize = True
        Me.txtreligion.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtreligion.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtreligion.Location = New System.Drawing.Point(17, 390)
        Me.txtreligion.Name = "txtreligion"
        Me.txtreligion.Size = New System.Drawing.Size(62, 18)
        Me.txtreligion.TabIndex = 103
        Me.txtreligion.Text = "Religion"
        '
        'txtzipcode
        '
        Me.txtzipcode.AutoSize = True
        Me.txtzipcode.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtzipcode.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtzipcode.Location = New System.Drawing.Point(20, 485)
        Me.txtzipcode.Name = "txtzipcode"
        Me.txtzipcode.Size = New System.Drawing.Size(60, 18)
        Me.txtzipcode.TabIndex = 108
        Me.txtzipcode.Text = "ZipCode"
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label5.ForeColor = System.Drawing.Color.IndianRed
        Me.Label5.Location = New System.Drawing.Point(14, 368)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 16)
        Me.Label5.TabIndex = 92
        Me.Label5.Text = "Religion :"
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label25.ForeColor = System.Drawing.Color.IndianRed
        Me.Label25.Location = New System.Drawing.Point(97, 463)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(115, 16)
        Me.Label25.TabIndex = 85
        Me.Label25.Text = "Contact Number :"
        '
        'txtprovince
        '
        Me.txtprovince.AutoSize = True
        Me.txtprovince.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtprovince.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtprovince.Location = New System.Drawing.Point(219, 435)
        Me.txtprovince.Name = "txtprovince"
        Me.txtprovince.Size = New System.Drawing.Size(65, 18)
        Me.txtprovince.TabIndex = 109
        Me.txtprovince.Text = "Province"
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label30.ForeColor = System.Drawing.Color.IndianRed
        Me.Label30.Location = New System.Drawing.Point(209, 463)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(132, 16)
        Me.Label30.TabIndex = 86
        Me.Label30.Text = "Emergency Number :"
        '
        'txtbplace
        '
        Me.txtbplace.AutoSize = True
        Me.txtbplace.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbplace.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtbplace.Location = New System.Drawing.Point(97, 340)
        Me.txtbplace.Name = "txtbplace"
        Me.txtbplace.Size = New System.Drawing.Size(88, 18)
        Me.txtbplace.TabIndex = 106
        Me.txtbplace.Text = "PlaceofBirth"
        '
        'txtstatus
        '
        Me.txtstatus.AutoSize = True
        Me.txtstatus.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtstatus.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtstatus.Location = New System.Drawing.Point(144, 391)
        Me.txtstatus.Name = "txtstatus"
        Me.txtstatus.Size = New System.Drawing.Size(82, 18)
        Me.txtstatus.TabIndex = 99
        Me.txtstatus.Text = "CivilStatus"
        '
        'txtage
        '
        Me.txtage.AutoSize = True
        Me.txtage.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtage.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtage.Location = New System.Drawing.Point(111, 289)
        Me.txtage.Name = "txtage"
        Me.txtage.Size = New System.Drawing.Size(32, 18)
        Me.txtage.TabIndex = 102
        Me.txtage.Text = "Age"
        '
        'txtsfxname
        '
        Me.txtsfxname.AutoSize = True
        Me.txtsfxname.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtsfxname.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtsfxname.Location = New System.Drawing.Point(214, 291)
        Me.txtsfxname.Name = "txtsfxname"
        Me.txtsfxname.Size = New System.Drawing.Size(85, 18)
        Me.txtsfxname.TabIndex = 98
        Me.txtsfxname.Text = "SuffixName"
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label26.ForeColor = System.Drawing.Color.IndianRed
        Me.Label26.Location = New System.Drawing.Point(107, 227)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(83, 16)
        Me.Label26.TabIndex = 111
        Me.Label26.Text = "First Name :"
        '
        'dtpdbirth
        '
        Me.dtpdbirth.AutoSize = True
        Me.dtpdbirth.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpdbirth.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.dtpdbirth.Location = New System.Drawing.Point(16, 290)
        Me.dtpdbirth.Name = "dtpdbirth"
        Me.dtpdbirth.Size = New System.Drawing.Size(73, 18)
        Me.dtpdbirth.TabIndex = 101
        Me.dtpdbirth.Text = "DateBirth"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label4.ForeColor = System.Drawing.Color.IndianRed
        Me.Label4.Location = New System.Drawing.Point(212, 275)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 16)
        Me.Label4.TabIndex = 91
        Me.Label4.Text = "Suffix Name :"
        '
        'txtmname
        '
        Me.txtmname.AutoSize = True
        Me.txtmname.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmname.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtmname.Location = New System.Drawing.Point(219, 243)
        Me.txtmname.Name = "txtmname"
        Me.txtmname.Size = New System.Drawing.Size(90, 18)
        Me.txtmname.TabIndex = 110
        Me.txtmname.Text = "MiddleName"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label27.ForeColor = System.Drawing.Color.IndianRed
        Me.Label27.Location = New System.Drawing.Point(141, 368)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(87, 16)
        Me.Label27.TabIndex = 83
        Me.Label27.Text = "Civil Status :"
        '
        'cbomunicipality
        '
        Me.cbomunicipality.AutoSize = True
        Me.cbomunicipality.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbomunicipality.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.cbomunicipality.Location = New System.Drawing.Point(109, 435)
        Me.cbomunicipality.Name = "cbomunicipality"
        Me.cbomunicipality.Size = New System.Drawing.Size(69, 18)
        Me.cbomunicipality.TabIndex = 107
        Me.cbomunicipality.Text = "Municpal"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Firebrick
        Me.Panel5.Location = New System.Drawing.Point(100, 19)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(131, 136)
        Me.Panel5.TabIndex = 116
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label7.ForeColor = System.Drawing.Color.IndianRed
        Me.Label7.Location = New System.Drawing.Point(215, 419)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 16)
        Me.Label7.TabIndex = 94
        Me.Label7.Text = "Province :"
        '
        'txtcode
        '
        Me.txtcode.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtcode.Enabled = False
        Me.txtcode.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcode.Location = New System.Drawing.Point(93, 127)
        Me.txtcode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtcode.Multiline = True
        Me.txtcode.Name = "txtcode"
        Me.txtcode.Size = New System.Drawing.Size(71, 24)
        Me.txtcode.TabIndex = 110
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label2.ForeColor = System.Drawing.Color.IndianRed
        Me.Label2.Location = New System.Drawing.Point(111, 274)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 16)
        Me.Label2.TabIndex = 90
        Me.Label2.Text = "Age:"
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label6.ForeColor = System.Drawing.Color.IndianRed
        Me.Label6.Location = New System.Drawing.Point(104, 419)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(90, 16)
        Me.Label6.TabIndex = 93
        Me.Label6.Text = "Municipality :"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label22.ForeColor = System.Drawing.Color.IndianRed
        Me.Label22.Location = New System.Drawing.Point(14, 274)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(86, 16)
        Me.Label22.TabIndex = 87
        Me.Label22.Text = "Date of Birth"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(104, 108)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(62, 16)
        Me.Label20.TabIndex = 89
        Me.Label20.Text = "EMP ID :"
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label8.ForeColor = System.Drawing.Color.IndianRed
        Me.Label8.Location = New System.Drawing.Point(14, 464)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 16)
        Me.Label8.TabIndex = 95
        Me.Label8.Text = "ZipCode :"
        '
        'txtfname
        '
        Me.txtfname.AutoSize = True
        Me.txtfname.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtfname.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtfname.Location = New System.Drawing.Point(106, 243)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(86, 18)
        Me.txtfname.TabIndex = 96
        Me.txtfname.Text = "First Name "
        '
        'txtlname
        '
        Me.txtlname.AutoSize = True
        Me.txtlname.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlname.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.txtlname.Location = New System.Drawing.Point(16, 243)
        Me.txtlname.Name = "txtlname"
        Me.txtlname.Size = New System.Drawing.Size(75, 18)
        Me.txtlname.TabIndex = 97
        Me.txtlname.Text = "LastName"
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label28.ForeColor = System.Drawing.Color.IndianRed
        Me.Label28.Location = New System.Drawing.Point(13, 227)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(81, 16)
        Me.Label28.TabIndex = 82
        Me.Label28.Text = "Last Name :"
        '
        'Label31
        '
        Me.Label31.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label31.ForeColor = System.Drawing.Color.IndianRed
        Me.Label31.Location = New System.Drawing.Point(212, 227)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(95, 16)
        Me.Label31.TabIndex = 80
        Me.Label31.Text = "Middle Name :"
        '
        'Barangay
        '
        Me.Barangay.AutoSize = True
        Me.Barangay.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Barangay.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Barangay.Location = New System.Drawing.Point(20, 435)
        Me.Barangay.Name = "Barangay"
        Me.Barangay.Size = New System.Drawing.Size(70, 18)
        Me.Barangay.TabIndex = 100
        Me.Barangay.Text = "Barangay"
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label29.ForeColor = System.Drawing.Color.IndianRed
        Me.Label29.Location = New System.Drawing.Point(13, 419)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(64, 16)
        Me.Label29.TabIndex = 81
        Me.Label29.Text = "Address :"
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Bookman Old Style", 9.0!)
        Me.Label21.ForeColor = System.Drawing.Color.IndianRed
        Me.Label21.Location = New System.Drawing.Point(98, 324)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(97, 16)
        Me.Label21.TabIndex = 88
        Me.Label21.Text = "Place of Birth :"
        '
        'IconPictureBox2
        '
        Me.IconPictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox2.ForeColor = System.Drawing.Color.Black
        Me.IconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.GraduationCap
        Me.IconPictureBox2.IconColor = System.Drawing.Color.Black
        Me.IconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox2.IconSize = 45
        Me.IconPictureBox2.Location = New System.Drawing.Point(369, 10)
        Me.IconPictureBox2.Name = "IconPictureBox2"
        Me.IconPictureBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.IconPictureBox2.Size = New System.Drawing.Size(45, 45)
        Me.IconPictureBox2.TabIndex = 118
        Me.IconPictureBox2.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.txtothereli)
        Me.GroupBox2.Controls.Add(Me.Label32)
        Me.GroupBox2.Controls.Add(Me.cbolvleli)
        Me.GroupBox2.Controls.Add(Me.Label61)
        Me.GroupBox2.Controls.Add(Me.txtdspecialtrain)
        Me.GroupBox2.Controls.Add(Me.txtspecialtrain)
        Me.GroupBox2.Controls.Add(Me.txtdmantrain)
        Me.GroupBox2.Controls.Add(Me.cbohighmantrain)
        Me.GroupBox2.Controls.Add(Me.cbohigheli)
        Me.GroupBox2.Controls.Add(Me.txtdoclvl)
        Me.GroupBox2.Controls.Add(Me.txtdoccrs)
        Me.GroupBox2.Controls.Add(Me.txtmascrs)
        Me.GroupBox2.Controls.Add(Me.txtmaslvl)
        Me.GroupBox2.Controls.Add(Me.txtcrs)
        Me.GroupBox2.Controls.Add(Me.Label73)
        Me.GroupBox2.Controls.Add(Me.Label74)
        Me.GroupBox2.Controls.Add(Me.Label75)
        Me.GroupBox2.Controls.Add(Me.Label76)
        Me.GroupBox2.Controls.Add(Me.Label78)
        Me.GroupBox2.Controls.Add(Me.Label79)
        Me.GroupBox2.Controls.Add(Me.Label80)
        Me.GroupBox2.Controls.Add(Me.Label81)
        Me.GroupBox2.Controls.Add(Me.Label82)
        Me.GroupBox2.Controls.Add(Me.Label83)
        Me.GroupBox2.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox2.Location = New System.Drawing.Point(417, 36)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(701, 179)
        Me.GroupBox2.TabIndex = 119
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "EDUCATION ATTAINMENT"
        '
        'txtothereli
        '
        Me.txtothereli.AutoSize = True
        Me.txtothereli.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtothereli.Location = New System.Drawing.Point(420, 141)
        Me.txtothereli.Name = "txtothereli"
        Me.txtothereli.Size = New System.Drawing.Size(108, 18)
        Me.txtothereli.TabIndex = 116
        Me.txtothereli.Text = "OtherEligibility"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(421, 126)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(111, 16)
        Me.Label32.TabIndex = 115
        Me.Label32.Text = "Other Eligibility :"
        '
        'cbolvleli
        '
        Me.cbolvleli.AutoSize = True
        Me.cbolvleli.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbolvleli.Location = New System.Drawing.Point(176, 91)
        Me.cbolvleli.Name = "cbolvleli"
        Me.cbolvleli.Size = New System.Drawing.Size(100, 18)
        Me.cbolvleli.TabIndex = 114
        Me.cbolvleli.Text = "LevelEligibilty"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.Color.Black
        Me.Label61.Location = New System.Drawing.Point(177, 74)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(122, 16)
        Me.Label61.TabIndex = 113
        Me.Label61.Text = "Level of Eligibility :"
        '
        'txtdspecialtrain
        '
        Me.txtdspecialtrain.AutoSize = True
        Me.txtdspecialtrain.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdspecialtrain.Location = New System.Drawing.Point(187, 142)
        Me.txtdspecialtrain.Name = "txtdspecialtrain"
        Me.txtdspecialtrain.Size = New System.Drawing.Size(152, 18)
        Me.txtdspecialtrain.TabIndex = 111
        Me.txtdspecialtrain.Text = "DurationSpecialTrain"
        '
        'txtspecialtrain
        '
        Me.txtspecialtrain.AutoSize = True
        Me.txtspecialtrain.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtspecialtrain.Location = New System.Drawing.Point(21, 142)
        Me.txtspecialtrain.Name = "txtspecialtrain"
        Me.txtspecialtrain.Size = New System.Drawing.Size(140, 18)
        Me.txtspecialtrain.TabIndex = 110
        Me.txtspecialtrain.Text = "SpecializedTraining"
        '
        'txtdmantrain
        '
        Me.txtdmantrain.AutoSize = True
        Me.txtdmantrain.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdmantrain.Location = New System.Drawing.Point(493, 91)
        Me.txtdmantrain.Name = "txtdmantrain"
        Me.txtdmantrain.Size = New System.Drawing.Size(129, 18)
        Me.txtdmantrain.TabIndex = 109
        Me.txtdmantrain.Text = "DurationMantrain"
        '
        'cbohighmantrain
        '
        Me.cbohighmantrain.AutoSize = True
        Me.cbohighmantrain.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbohighmantrain.Location = New System.Drawing.Point(301, 91)
        Me.cbohighmantrain.Name = "cbohighmantrain"
        Me.cbohighmantrain.Size = New System.Drawing.Size(125, 18)
        Me.cbohighmantrain.TabIndex = 108
        Me.cbohighmantrain.Text = "HighestManTrain" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'cbohigheli
        '
        Me.cbohigheli.AutoSize = True
        Me.cbohigheli.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbohigheli.Location = New System.Drawing.Point(20, 93)
        Me.cbohigheli.Name = "cbohigheli"
        Me.cbohigheli.Size = New System.Drawing.Size(121, 18)
        Me.cbohigheli.TabIndex = 106
        Me.cbohigheli.Text = "HighestEligibility"
        '
        'txtdoclvl
        '
        Me.txtdoclvl.AutoSize = True
        Me.txtdoclvl.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdoclvl.Location = New System.Drawing.Point(569, 42)
        Me.txtdoclvl.Name = "txtdoclvl"
        Me.txtdoclvl.Size = New System.Drawing.Size(118, 18)
        Me.txtdoclvl.TabIndex = 105
        Me.txtdoclvl.Text = "DoctorateCourse"
        '
        'txtdoccrs
        '
        Me.txtdoccrs.AutoSize = True
        Me.txtdoccrs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdoccrs.Location = New System.Drawing.Point(430, 42)
        Me.txtdoccrs.Name = "txtdoccrs"
        Me.txtdoccrs.Size = New System.Drawing.Size(106, 18)
        Me.txtdoccrs.TabIndex = 104
        Me.txtdoccrs.Text = "DoctorateLevel"
        '
        'txtmascrs
        '
        Me.txtmascrs.AutoSize = True
        Me.txtmascrs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmascrs.Location = New System.Drawing.Point(177, 41)
        Me.txtmascrs.Name = "txtmascrs"
        Me.txtmascrs.Size = New System.Drawing.Size(80, 18)
        Me.txtmascrs.TabIndex = 103
        Me.txtmascrs.Text = "MasteryLvl"
        '
        'txtmaslvl
        '
        Me.txtmaslvl.AutoSize = True
        Me.txtmaslvl.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtmaslvl.Location = New System.Drawing.Point(293, 42)
        Me.txtmaslvl.Name = "txtmaslvl"
        Me.txtmaslvl.Size = New System.Drawing.Size(113, 18)
        Me.txtmaslvl.TabIndex = 102
        Me.txtmaslvl.Text = "MasteralCourse"
        '
        'txtcrs
        '
        Me.txtcrs.AutoSize = True
        Me.txtcrs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcrs.Location = New System.Drawing.Point(23, 41)
        Me.txtcrs.Name = "txtcrs"
        Me.txtcrs.Size = New System.Drawing.Size(109, 18)
        Me.txtcrs.TabIndex = 79
        Me.txtcrs.Text = "TertiaryCourse"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.ForeColor = System.Drawing.Color.Black
        Me.Label73.Location = New System.Drawing.Point(187, 126)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(209, 16)
        Me.Label73.TabIndex = 93
        Me.Label73.Text = "Duration of Specialized Training :"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.ForeColor = System.Drawing.Color.Black
        Me.Label74.Location = New System.Drawing.Point(21, 126)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(129, 16)
        Me.Label74.TabIndex = 92
        Me.Label74.Text = "Specilized Training :"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.Black
        Me.Label75.Location = New System.Drawing.Point(490, 75)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(205, 16)
        Me.Label75.TabIndex = 91
        Me.Label75.Text = "Duration of Mandatory Training :"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.ForeColor = System.Drawing.Color.Black
        Me.Label76.Location = New System.Drawing.Point(302, 75)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(183, 16)
        Me.Label76.TabIndex = 90
        Me.Label76.Text = "Highest Mandatory Training :"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.ForeColor = System.Drawing.Color.Black
        Me.Label78.Location = New System.Drawing.Point(21, 74)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(123, 16)
        Me.Label78.TabIndex = 89
        Me.Label78.Text = "Highest Eligibility :"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.ForeColor = System.Drawing.Color.Black
        Me.Label79.Location = New System.Drawing.Point(570, 25)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(122, 16)
        Me.Label79.TabIndex = 87
        Me.Label79.Text = "Doctorate Course :"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.ForeColor = System.Drawing.Color.Black
        Me.Label80.Location = New System.Drawing.Point(430, 25)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(110, 16)
        Me.Label80.TabIndex = 86
        Me.Label80.Text = "Doctorate Level :"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.ForeColor = System.Drawing.Color.Black
        Me.Label81.Location = New System.Drawing.Point(294, 25)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(116, 16)
        Me.Label81.TabIndex = 85
        Me.Label81.Text = "Masteral Course :"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.ForeColor = System.Drawing.Color.Black
        Me.Label82.Location = New System.Drawing.Point(177, 25)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(99, 16)
        Me.Label82.TabIndex = 84
        Me.Label82.Text = "Mastery Level :"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.ForeColor = System.Drawing.Color.Black
        Me.Label83.Location = New System.Drawing.Point(17, 25)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(109, 16)
        Me.Label83.TabIndex = 83
        Me.Label83.Text = "Tertiary Course :"
        '
        'GroupBox10
        '
        Me.GroupBox10.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox10.Controls.Add(Me.txtremarks)
        Me.GroupBox10.Controls.Add(Me.txtlngpaynum)
        Me.GroupBox10.Controls.Add(Me.txtlndbnknum)
        Me.GroupBox10.Controls.Add(Me.txtbadgenum)
        Me.GroupBox10.Controls.Add(Me.txtphlthnum)
        Me.GroupBox10.Controls.Add(Me.txtgsisnum)
        Me.GroupBox10.Controls.Add(Me.txtpibgnum)
        Me.GroupBox10.Controls.Add(Me.txttinnum)
        Me.GroupBox10.Controls.Add(Me.dteffectivecon)
        Me.GroupBox10.Controls.Add(Me.txtauthcondesig)
        Me.GroupBox10.Controls.Add(Me.txtcondesig)
        Me.GroupBox10.Controls.Add(Me.txtdateretire)
        Me.GroupBox10.Controls.Add(Me.cbosoa)
        Me.GroupBox10.Controls.Add(Me.dtdolp)
        Me.GroupBox10.Controls.Add(Me.dtdao)
        Me.GroupBox10.Controls.Add(Me.txtyrsfiresvc)
        Me.GroupBox10.Controls.Add(Me.dtdefs)
        Me.GroupBox10.Controls.Add(Me.dtdegs)
        Me.GroupBox10.Controls.Add(Me.txtyrspridesig)
        Me.GroupBox10.Controls.Add(Me.dteop)
        Me.GroupBox10.Controls.Add(Me.txtapd)
        Me.GroupBox10.Controls.Add(Me.txtpridesig)
        Me.GroupBox10.Controls.Add(Me.txtitemnum)
        Me.GroupBox10.Controls.Add(Me.txtrank)
        Me.GroupBox10.Controls.Add(Me.txtunitcode)
        Me.GroupBox10.Controls.Add(Me.cbounitassign)
        Me.GroupBox10.Controls.Add(Me.txtadmin)
        Me.GroupBox10.Controls.Add(Me.txtaccnum)
        Me.GroupBox10.Controls.Add(Me.Label53)
        Me.GroupBox10.Controls.Add(Me.Label54)
        Me.GroupBox10.Controls.Add(Me.Label55)
        Me.GroupBox10.Controls.Add(Me.Label56)
        Me.GroupBox10.Controls.Add(Me.Label57)
        Me.GroupBox10.Controls.Add(Me.Label58)
        Me.GroupBox10.Controls.Add(Me.Label59)
        Me.GroupBox10.Controls.Add(Me.Label60)
        Me.GroupBox10.Controls.Add(Me.Label51)
        Me.GroupBox10.Controls.Add(Me.Label50)
        Me.GroupBox10.Controls.Add(Me.Label49)
        Me.GroupBox10.Controls.Add(Me.Label1)
        Me.GroupBox10.Controls.Add(Me.Label48)
        Me.GroupBox10.Controls.Add(Me.Label45)
        Me.GroupBox10.Controls.Add(Me.Label47)
        Me.GroupBox10.Controls.Add(Me.Label44)
        Me.GroupBox10.Controls.Add(Me.Label41)
        Me.GroupBox10.Controls.Add(Me.Label42)
        Me.GroupBox10.Controls.Add(Me.Label9)
        Me.GroupBox10.Controls.Add(Me.Label36)
        Me.GroupBox10.Controls.Add(Me.Label40)
        Me.GroupBox10.Controls.Add(Me.Label52)
        Me.GroupBox10.Controls.Add(Me.Label19)
        Me.GroupBox10.Controls.Add(Me.Label18)
        Me.GroupBox10.Controls.Add(Me.Label23)
        Me.GroupBox10.Controls.Add(Me.Label37)
        Me.GroupBox10.Controls.Add(Me.Label38)
        Me.GroupBox10.Controls.Add(Me.Label39)
        Me.GroupBox10.Font = New System.Drawing.Font("Bookman Old Style", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox10.Location = New System.Drawing.Point(417, 235)
        Me.GroupBox10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox10.Size = New System.Drawing.Size(702, 316)
        Me.GroupBox10.TabIndex = 120
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "WORK INFORMATION"
        '
        'txtremarks
        '
        Me.txtremarks.AutoSize = True
        Me.txtremarks.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtremarks.Location = New System.Drawing.Point(419, 287)
        Me.txtremarks.Name = "txtremarks"
        Me.txtremarks.Size = New System.Drawing.Size(65, 18)
        Me.txtremarks.TabIndex = 205
        Me.txtremarks.Text = "remarks"
        '
        'txtlngpaynum
        '
        Me.txtlngpaynum.AutoSize = True
        Me.txtlngpaynum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlngpaynum.Location = New System.Drawing.Point(302, 287)
        Me.txtlngpaynum.Name = "txtlngpaynum"
        Me.txtlngpaynum.Size = New System.Drawing.Size(57, 18)
        Me.txtlngpaynum.TabIndex = 204
        Me.txtlngpaynum.Text = "longpay"
        '
        'txtlndbnknum
        '
        Me.txtlndbnknum.AutoSize = True
        Me.txtlndbnknum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlndbnknum.Location = New System.Drawing.Point(145, 287)
        Me.txtlndbnknum.Name = "txtlndbnknum"
        Me.txtlndbnknum.Size = New System.Drawing.Size(78, 18)
        Me.txtlndbnknum.TabIndex = 203
        Me.txtlndbnknum.Text = "landbank#"
        '
        'txtbadgenum
        '
        Me.txtbadgenum.AutoSize = True
        Me.txtbadgenum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtbadgenum.Location = New System.Drawing.Point(28, 287)
        Me.txtbadgenum.Name = "txtbadgenum"
        Me.txtbadgenum.Size = New System.Drawing.Size(54, 18)
        Me.txtbadgenum.TabIndex = 202
        Me.txtbadgenum.Text = "badge#"
        '
        'txtphlthnum
        '
        Me.txtphlthnum.AutoSize = True
        Me.txtphlthnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtphlthnum.Location = New System.Drawing.Point(567, 238)
        Me.txtphlthnum.Name = "txtphlthnum"
        Me.txtphlthnum.Size = New System.Drawing.Size(85, 18)
        Me.txtphlthnum.TabIndex = 201
        Me.txtphlthnum.Text = "philhealth#"
        '
        'txtgsisnum
        '
        Me.txtgsisnum.AutoSize = True
        Me.txtgsisnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtgsisnum.Location = New System.Drawing.Point(453, 238)
        Me.txtgsisnum.Name = "txtgsisnum"
        Me.txtgsisnum.Size = New System.Drawing.Size(43, 18)
        Me.txtgsisnum.TabIndex = 200
        Me.txtgsisnum.Text = "gsis#"
        '
        'txtpibgnum
        '
        Me.txtpibgnum.AutoSize = True
        Me.txtpibgnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpibgnum.Location = New System.Drawing.Point(304, 238)
        Me.txtpibgnum.Name = "txtpibgnum"
        Me.txtpibgnum.Size = New System.Drawing.Size(63, 18)
        Me.txtpibgnum.TabIndex = 199
        Me.txtpibgnum.Text = "pagibig#"
        '
        'txttinnum
        '
        Me.txttinnum.AutoSize = True
        Me.txttinnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txttinnum.Location = New System.Drawing.Point(190, 238)
        Me.txttinnum.Name = "txttinnum"
        Me.txttinnum.Size = New System.Drawing.Size(36, 18)
        Me.txttinnum.TabIndex = 198
        Me.txttinnum.Text = "tin#"
        '
        'dteffectivecon
        '
        Me.dteffectivecon.AutoSize = True
        Me.dteffectivecon.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dteffectivecon.Location = New System.Drawing.Point(17, 238)
        Me.dteffectivecon.Name = "dteffectivecon"
        Me.dteffectivecon.Size = New System.Drawing.Size(98, 18)
        Me.dteffectivecon.TabIndex = 197
        Me.dteffectivecon.Text = "effectiveofcon"
        '
        'txtauthcondesig
        '
        Me.txtauthcondesig.AutoSize = True
        Me.txtauthcondesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtauthcondesig.Location = New System.Drawing.Point(382, 190)
        Me.txtauthcondesig.Name = "txtauthcondesig"
        Me.txtauthcondesig.Size = New System.Drawing.Size(73, 18)
        Me.txtauthcondesig.TabIndex = 196
        Me.txtauthcondesig.Text = "authofcon"
        '
        'txtcondesig
        '
        Me.txtcondesig.AutoSize = True
        Me.txtcondesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcondesig.Location = New System.Drawing.Point(193, 190)
        Me.txtcondesig.Name = "txtcondesig"
        Me.txtcondesig.Size = New System.Drawing.Size(65, 18)
        Me.txtcondesig.TabIndex = 195
        Me.txtcondesig.Text = "condesig"
        '
        'txtdateretire
        '
        Me.txtdateretire.AutoSize = True
        Me.txtdateretire.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtdateretire.Location = New System.Drawing.Point(347, 141)
        Me.txtdateretire.Name = "txtdateretire"
        Me.txtdateretire.Size = New System.Drawing.Size(85, 18)
        Me.txtdateretire.TabIndex = 194
        Me.txtdateretire.Text = "dateofretire"
        '
        'cbosoa
        '
        Me.cbosoa.AutoSize = True
        Me.cbosoa.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbosoa.Location = New System.Drawing.Point(210, 139)
        Me.cbosoa.Name = "cbosoa"
        Me.cbosoa.Size = New System.Drawing.Size(81, 18)
        Me.cbosoa.TabIndex = 193
        Me.cbosoa.Text = "workstatus"
        '
        'dtdolp
        '
        Me.dtdolp.AutoSize = True
        Me.dtdolp.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdolp.Location = New System.Drawing.Point(116, 141)
        Me.dtdolp.Name = "dtdolp"
        Me.dtdolp.Size = New System.Drawing.Size(33, 18)
        Me.dtdolp.TabIndex = 192
        Me.dtdolp.Text = "dolp"
        '
        'dtdao
        '
        Me.dtdao.AutoSize = True
        Me.dtdao.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdao.Location = New System.Drawing.Point(20, 141)
        Me.dtdao.Name = "dtdao"
        Me.dtdao.Size = New System.Drawing.Size(30, 18)
        Me.dtdao.TabIndex = 191
        Me.dtdao.Text = "dao"
        '
        'txtyrsfiresvc
        '
        Me.txtyrsfiresvc.AutoSize = True
        Me.txtyrsfiresvc.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyrsfiresvc.Location = New System.Drawing.Point(17, 190)
        Me.txtyrsfiresvc.Name = "txtyrsfiresvc"
        Me.txtyrsfiresvc.Size = New System.Drawing.Size(104, 18)
        Me.txtyrsfiresvc.TabIndex = 190
        Me.txtyrsfiresvc.Text = "YrsFireservice"
        '
        'dtdefs
        '
        Me.dtdefs.AutoSize = True
        Me.dtdefs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdefs.Location = New System.Drawing.Point(496, 141)
        Me.dtdefs.Name = "dtdefs"
        Me.dtdefs.Size = New System.Drawing.Size(113, 18)
        Me.dtdefs.TabIndex = 188
        Me.dtdefs.Text = "DateEnterofFire"
        '
        'dtdegs
        '
        Me.dtdegs.AutoSize = True
        Me.dtdegs.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtdegs.Location = New System.Drawing.Point(587, 95)
        Me.dtdegs.Name = "dtdegs"
        Me.dtdegs.Size = New System.Drawing.Size(40, 18)
        Me.dtdegs.TabIndex = 187
        Me.dtdegs.Text = "Degs"
        '
        'txtyrspridesig
        '
        Me.txtyrspridesig.AutoSize = True
        Me.txtyrspridesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtyrspridesig.Location = New System.Drawing.Point(428, 94)
        Me.txtyrspridesig.Name = "txtyrspridesig"
        Me.txtyrspridesig.Size = New System.Drawing.Size(109, 18)
        Me.txtyrspridesig.TabIndex = 186
        Me.txtyrspridesig.Text = "YearsofPridesig"
        '
        'dteop
        '
        Me.dteop.AutoSize = True
        Me.dteop.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dteop.Location = New System.Drawing.Point(341, 93)
        Me.dteop.Name = "dteop"
        Me.dteop.Size = New System.Drawing.Size(34, 18)
        Me.dteop.TabIndex = 185
        Me.dteop.Text = "EOP"
        '
        'txtapd
        '
        Me.txtapd.AutoSize = True
        Me.txtapd.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtapd.Location = New System.Drawing.Point(165, 95)
        Me.txtapd.Name = "txtapd"
        Me.txtapd.Size = New System.Drawing.Size(130, 18)
        Me.txtapd.TabIndex = 183
        Me.txtapd.Text = "AuthPrimaryDesig"
        '
        'txtpridesig
        '
        Me.txtpridesig.AutoSize = True
        Me.txtpridesig.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpridesig.Location = New System.Drawing.Point(17, 95)
        Me.txtpridesig.Name = "txtpridesig"
        Me.txtpridesig.Size = New System.Drawing.Size(98, 18)
        Me.txtpridesig.TabIndex = 182
        Me.txtpridesig.Text = "PrimaryDesig"
        '
        'txtitemnum
        '
        Me.txtitemnum.AutoSize = True
        Me.txtitemnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtitemnum.Location = New System.Drawing.Point(595, 46)
        Me.txtitemnum.Name = "txtitemnum"
        Me.txtitemnum.Size = New System.Drawing.Size(71, 18)
        Me.txtitemnum.TabIndex = 181
        Me.txtitemnum.Text = "ItemNum"
        '
        'txtrank
        '
        Me.txtrank.AutoSize = True
        Me.txtrank.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtrank.Location = New System.Drawing.Point(498, 47)
        Me.txtrank.Name = "txtrank"
        Me.txtrank.Size = New System.Drawing.Size(43, 18)
        Me.txtrank.TabIndex = 180
        Me.txtrank.Text = "Rank"
        '
        'txtunitcode
        '
        Me.txtunitcode.AutoSize = True
        Me.txtunitcode.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtunitcode.Location = New System.Drawing.Point(373, 47)
        Me.txtunitcode.Name = "txtunitcode"
        Me.txtunitcode.Size = New System.Drawing.Size(69, 18)
        Me.txtunitcode.TabIndex = 179
        Me.txtunitcode.Text = "UnitCode"
        '
        'cbounitassign
        '
        Me.cbounitassign.AutoSize = True
        Me.cbounitassign.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbounitassign.Location = New System.Drawing.Point(246, 47)
        Me.cbounitassign.Name = "cbounitassign"
        Me.cbounitassign.Size = New System.Drawing.Size(81, 18)
        Me.cbounitassign.TabIndex = 178
        Me.cbounitassign.Text = "UnitAssign"
        '
        'txtadmin
        '
        Me.txtadmin.AutoSize = True
        Me.txtadmin.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadmin.Location = New System.Drawing.Point(137, 47)
        Me.txtadmin.Name = "txtadmin"
        Me.txtadmin.Size = New System.Drawing.Size(51, 18)
        Me.txtadmin.TabIndex = 177
        Me.txtadmin.Text = "Admin"
        '
        'txtaccnum
        '
        Me.txtaccnum.AutoSize = True
        Me.txtaccnum.Font = New System.Drawing.Font("Bookman Old Style", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtaccnum.Location = New System.Drawing.Point(20, 47)
        Me.txtaccnum.Name = "txtaccnum"
        Me.txtaccnum.Size = New System.Drawing.Size(93, 18)
        Me.txtaccnum.TabIndex = 176
        Me.txtaccnum.Text = "AccountNum"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Black
        Me.Label53.Location = New System.Drawing.Point(414, 272)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(78, 16)
        Me.Label53.TabIndex = 167
        Me.Label53.Text = "REMARKS :"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.Black
        Me.Label54.Location = New System.Drawing.Point(291, 273)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(69, 16)
        Me.Label54.TabIndex = 166
        Me.Label54.Text = "LONGPAY"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.Black
        Me.Label55.Location = New System.Drawing.Point(125, 273)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(117, 16)
        Me.Label55.TabIndex = 165
        Me.Label55.Text = "LANDBANK ATM#"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.Black
        Me.Label56.Location = New System.Drawing.Point(16, 272)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(65, 16)
        Me.Label56.TabIndex = 163
        Me.Label56.Text = "BADGE #"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.Black
        Me.Label57.Location = New System.Drawing.Point(541, 222)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(101, 16)
        Me.Label57.TabIndex = 164
        Me.Label57.Text = "PHILHEALTH #"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.Black
        Me.Label58.Location = New System.Drawing.Point(440, 222)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(52, 16)
        Me.Label58.TabIndex = 162
        Me.Label58.Text = "GSIS #"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.Black
        Me.Label59.Location = New System.Drawing.Point(284, 223)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(75, 16)
        Me.Label59.TabIndex = 161
        Me.Label59.Text = "PAGIBIG #"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.Black
        Me.Label60.Location = New System.Drawing.Point(183, 222)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(43, 16)
        Me.Label60.TabIndex = 160
        Me.Label60.Text = "TIN #"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Black
        Me.Label51.Location = New System.Drawing.Point(17, 222)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(154, 16)
        Me.Label51.TabIndex = 158
        Me.Label51.Text = "Effective of Concurrent :"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Black
        Me.Label50.Location = New System.Drawing.Point(378, 172)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(170, 16)
        Me.Label50.TabIndex = 156
        Me.Label50.Text = "Auth of Concurrent Desig :"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Black
        Me.Label49.Location = New System.Drawing.Point(190, 172)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(161, 16)
        Me.Label49.TabIndex = 154
        Me.Label49.Text = "Concurrent Designation :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(340, 125)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 16)
        Me.Label1.TabIndex = 152
        Me.Label1.Text = "Date of Retirement :"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.Black
        Me.Label48.Location = New System.Drawing.Point(211, 123)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(91, 16)
        Me.Label48.TabIndex = 151
        Me.Label48.Text = "Work Status :"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Black
        Me.Label45.Location = New System.Drawing.Point(107, 123)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(51, 16)
        Me.Label45.TabIndex = 148
        Me.Label45.Text = "DOLP :"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Black
        Me.Label47.Location = New System.Drawing.Point(19, 124)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(44, 16)
        Me.Label47.TabIndex = 147
        Me.Label47.Text = "DAO :"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Black
        Me.Label44.Location = New System.Drawing.Point(17, 172)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(130, 16)
        Me.Label44.TabIndex = 145
        Me.Label44.Text = "Yrs in Fire Service  :"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Black
        Me.Label41.Location = New System.Drawing.Point(495, 123)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(185, 16)
        Me.Label41.TabIndex = 140
        Me.Label41.Text = "Date Entered of Fire Service :"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(584, 77)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(52, 16)
        Me.Label42.TabIndex = 139
        Me.Label42.Text = "DEGS :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(339, 77)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 16)
        Me.Label9.TabIndex = 135
        Me.Label9.Text = "EOP :"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(415, 78)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(139, 16)
        Me.Label36.TabIndex = 134
        Me.Label36.Text = "Yrs of Primary Desig :"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Black
        Me.Label40.Location = New System.Drawing.Point(138, 31)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(54, 16)
        Me.Label40.TabIndex = 126
        Me.Label40.Text = "Admin :"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Black
        Me.Label52.Location = New System.Drawing.Point(244, 30)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(86, 16)
        Me.Label52.TabIndex = 121
        Me.Label52.Text = "Unit Assign :"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(163, 77)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(148, 16)
        Me.Label19.TabIndex = 120
        Me.Label19.Text = "Auth of Primary Desig :"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(19, 78)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(139, 16)
        Me.Label18.TabIndex = 119
        Me.Label18.Text = "Primary Designation :"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(582, 29)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(96, 16)
        Me.Label23.TabIndex = 118
        Me.Label23.Text = "Item Number :"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(487, 30)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(47, 16)
        Me.Label37.TabIndex = 117
        Me.Label37.Text = "Rank :"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Black
        Me.Label38.Location = New System.Drawing.Point(356, 29)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(76, 16)
        Me.Label38.TabIndex = 116
        Me.Label38.Text = "Unit Code :"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Black
        Me.Label39.Location = New System.Drawing.Point(17, 31)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(120, 16)
        Me.Label39.TabIndex = 115
        Me.Label39.Text = "Account Number  :"
        '
        'IconPictureBox3
        '
        Me.IconPictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.IconPictureBox3.ForeColor = System.Drawing.Color.Black
        Me.IconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.Briefcase
        Me.IconPictureBox3.IconColor = System.Drawing.Color.Black
        Me.IconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.[Auto]
        Me.IconPictureBox3.IconSize = 45
        Me.IconPictureBox3.Location = New System.Drawing.Point(371, 207)
        Me.IconPictureBox3.Name = "IconPictureBox3"
        Me.IconPictureBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.IconPictureBox3.Size = New System.Drawing.Size(45, 45)
        Me.IconPictureBox3.TabIndex = 121
        Me.IconPictureBox3.TabStop = False
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.Black
        Me.Panel8.Location = New System.Drawing.Point(417, 17)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(711, 12)
        Me.Panel8.TabIndex = 122
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.Black
        Me.Panel9.Location = New System.Drawing.Point(417, 222)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(711, 12)
        Me.Panel9.TabIndex = 123
        '
        'FromPreviewProfiles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1131, 575)
        Me.Controls.Add(Me.Panel9)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.IconPictureBox3)
        Me.Controls.Add(Me.GroupBox10)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.IconPictureBox2)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FromPreviewProfiles"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Preview Profile"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.IconPictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        CType(Me.IconPictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        CType(Me.IconPictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents txtcode As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtprovince As Label
    Friend WithEvents txtzipcode As Label
    Friend WithEvents cbomunicipality As Label
    Friend WithEvents txtbplace As Label
    Friend WithEvents txtemerg As Label
    Friend WithEvents txtcontact As Label
    Friend WithEvents txtreligion As Label
    Friend WithEvents txtage As Label
    Friend WithEvents dtpdbirth As Label
    Friend WithEvents Barangay As Label
    Friend WithEvents txtstatus As Label
    Friend WithEvents txtsfxname As Label
    Friend WithEvents txtlname As Label
    Friend WithEvents txtfname As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents txtmname As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents txtgender As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Label34 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents IconPictureBox1 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents IconPictureBox2 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents cbolvleli As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents txtdspecialtrain As Label
    Friend WithEvents txtspecialtrain As Label
    Friend WithEvents txtdmantrain As Label
    Friend WithEvents cbohighmantrain As Label
    Friend WithEvents cbohigheli As Label
    Friend WithEvents txtdoclvl As Label
    Friend WithEvents txtdoccrs As Label
    Friend WithEvents txtmascrs As Label
    Friend WithEvents txtmaslvl As Label
    Friend WithEvents txtcrs As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents txtothereli As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents txtremarks As Label
    Friend WithEvents txtlngpaynum As Label
    Friend WithEvents txtlndbnknum As Label
    Friend WithEvents txtbadgenum As Label
    Friend WithEvents txtphlthnum As Label
    Friend WithEvents txtgsisnum As Label
    Friend WithEvents txtpibgnum As Label
    Friend WithEvents txttinnum As Label
    Friend WithEvents dteffectivecon As Label
    Friend WithEvents txtauthcondesig As Label
    Friend WithEvents txtcondesig As Label
    Friend WithEvents txtdateretire As Label
    Friend WithEvents cbosoa As Label
    Friend WithEvents dtdolp As Label
    Friend WithEvents dtdao As Label
    Friend WithEvents txtyrsfiresvc As Label
    Friend WithEvents dtdefs As Label
    Friend WithEvents dtdegs As Label
    Friend WithEvents txtyrspridesig As Label
    Friend WithEvents dteop As Label
    Friend WithEvents txtapd As Label
    Friend WithEvents txtpridesig As Label
    Friend WithEvents txtitemnum As Label
    Friend WithEvents txtrank As Label
    Friend WithEvents txtunitcode As Label
    Friend WithEvents cbounitassign As Label
    Friend WithEvents txtadmin As Label
    Friend WithEvents txtaccnum As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents IconPictureBox3 As FontAwesome.Sharp.IconPictureBox
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel9 As Panel
End Class
