﻿Public Class FormViewProfiles

    Private Sub FormViewProfiles_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Try
            sql = "SELECT `EMPID` AS 'EMPLOYEEID',CONCAT( `EMP_FNAME`,' ', `EMP_LNAME`,' ', `EMP_MNAME`) AS 'NAME'" _
                & ", `EMP_AGE` AS 'AGE', `EMP_SEX` AS 'GENDER', `STATUS` AS 'STATUS', `ADDRESS` AS 'ADDRESS', `CONTACT` AS 'CONTACT'  FROM `employee` WHERE RECORDENTRY not in (0)"
            reloadDtg(sql, Dtgemplist)
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub

    'TXTSEARCH
    Private Sub TxtProfileSearch_TextChanged(sender As Object, e As EventArgs) Handles TxtProfileSearch.TextChanged
        Try
            sql = "SELECT `EMPID` AS 'EMPLOYEEID',CONCAT( `EMP_FNAME`,' ', `EMP_LNAME`,' ', `EMP_MNAME`) AS 'NAME'" _
           & ", `EMP_AGE` AS 'AGE', `EMP_SEX` AS 'GENDER', `STATUS` AS 'STATUS', `ADDRESS` AS 'ADDRESS'" _
           & ", `CONTACT` AS 'CONTACT'  FROM `employee` WHERE RECORDENTRY not in (0) and (`EMPID` LIKE '%" & TxtProfileSearch.Text & "%'" _
           & " OR EMP_FNAME LIKE '%" & TxtProfileSearch.Text & "%' OR EMP_LNAME LIKE '%" & TxtProfileSearch.Text & "%')"
            reloadDtg(sql, Dtgemplist)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub


    'BUTTON CLOSE HERE
    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles BtnClose.Click
        Me.Close()
    End Sub

    Private Sub Dtgemplist_DoubleClick(sender As Object, e As EventArgs) Handles Dtgemplist.DoubleClick
        Try
            FormMenu.FrmAddLeave1.txtEmployeeId.Text = Dtgemplist.CurrentRow.Cells(0).Value
            Me.Close()
        Catch ex As Exception
            'MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub BtnSelect_Click(sender As Object, e As EventArgs) Handles BtnSelect.Click

        Try
            FormMenu.FrmAddLeave1.txtEmployeeId.Text = Dtgemplist.CurrentRow.Cells(0).Value
            Me.Close()
        Catch ex As Exception
            '  MsgBox(ex.Message)
        End Try

    End Sub


End Class