﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormViewProfiles
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormViewProfiles))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.TxtProfileSearch = New System.Windows.Forms.TextBox()
        Me.BtnSelect = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.BtnClose = New Bunifu.Framework.UI.BunifuFlatButton()
        Me.Dtgemplist = New System.Windows.Forms.DataGridView()
        CType(Me.Dtgemplist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bookman Old Style", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Maroon
        Me.Label1.Location = New System.Drawing.Point(8, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(269, 24)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "LIST OF BFP PROFILES"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(10, 410)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(57, 16)
        Me.Label46.TabIndex = 36
        Me.Label46.Text = "Search :"
        '
        'TxtProfileSearch
        '
        Me.TxtProfileSearch.Font = New System.Drawing.Font("Bookman Old Style", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtProfileSearch.Location = New System.Drawing.Point(68, 407)
        Me.TxtProfileSearch.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TxtProfileSearch.Name = "TxtProfileSearch"
        Me.TxtProfileSearch.Size = New System.Drawing.Size(282, 22)
        Me.TxtProfileSearch.TabIndex = 35
        '
        'BtnSelect
        '
        Me.BtnSelect.Activecolor = System.Drawing.Color.Maroon
        Me.BtnSelect.BackColor = System.Drawing.Color.Maroon
        Me.BtnSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnSelect.BorderRadius = 0
        Me.BtnSelect.ButtonText = " Select"
        Me.BtnSelect.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSelect.DisabledColor = System.Drawing.Color.Gray
        Me.BtnSelect.Iconcolor = System.Drawing.Color.Transparent
        Me.BtnSelect.Iconimage = CType(resources.GetObject("BtnSelect.Iconimage"), System.Drawing.Image)
        Me.BtnSelect.Iconimage_right = Nothing
        Me.BtnSelect.Iconimage_right_Selected = Nothing
        Me.BtnSelect.Iconimage_Selected = Nothing
        Me.BtnSelect.IconMarginLeft = 0
        Me.BtnSelect.IconMarginRight = 0
        Me.BtnSelect.IconRightVisible = True
        Me.BtnSelect.IconRightZoom = 0R
        Me.BtnSelect.IconVisible = True
        Me.BtnSelect.IconZoom = 40.0R
        Me.BtnSelect.IsTab = False
        Me.BtnSelect.Location = New System.Drawing.Point(526, 21)
        Me.BtnSelect.Name = "BtnSelect"
        Me.BtnSelect.Normalcolor = System.Drawing.Color.Maroon
        Me.BtnSelect.OnHovercolor = System.Drawing.Color.Red
        Me.BtnSelect.OnHoverTextColor = System.Drawing.Color.White
        Me.BtnSelect.selected = False
        Me.BtnSelect.Size = New System.Drawing.Size(102, 31)
        Me.BtnSelect.TabIndex = 40
        Me.BtnSelect.Text = " Select"
        Me.BtnSelect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BtnSelect.Textcolor = System.Drawing.Color.White
        Me.BtnSelect.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'BtnClose
        '
        Me.BtnClose.Activecolor = System.Drawing.Color.DarkOrange
        Me.BtnClose.BackColor = System.Drawing.Color.DarkOrange
        Me.BtnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnClose.BorderRadius = 0
        Me.BtnClose.ButtonText = "Close"
        Me.BtnClose.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnClose.DisabledColor = System.Drawing.Color.Gray
        Me.BtnClose.ForeColor = System.Drawing.Color.White
        Me.BtnClose.Iconcolor = System.Drawing.Color.Transparent
        Me.BtnClose.Iconimage = CType(resources.GetObject("BtnClose.Iconimage"), System.Drawing.Image)
        Me.BtnClose.Iconimage_right = Nothing
        Me.BtnClose.Iconimage_right_Selected = Nothing
        Me.BtnClose.Iconimage_Selected = Nothing
        Me.BtnClose.IconMarginLeft = 0
        Me.BtnClose.IconMarginRight = 0
        Me.BtnClose.IconRightVisible = True
        Me.BtnClose.IconRightZoom = 0R
        Me.BtnClose.IconVisible = True
        Me.BtnClose.IconZoom = 40.0R
        Me.BtnClose.IsTab = False
        Me.BtnClose.Location = New System.Drawing.Point(651, 21)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Normalcolor = System.Drawing.Color.DarkOrange
        Me.BtnClose.OnHovercolor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnClose.OnHoverTextColor = System.Drawing.Color.White
        Me.BtnClose.selected = False
        Me.BtnClose.Size = New System.Drawing.Size(102, 31)
        Me.BtnClose.TabIndex = 41
        Me.BtnClose.Text = "Close"
        Me.BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BtnClose.Textcolor = System.Drawing.Color.White
        Me.BtnClose.TextFont = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Dtgemplist
        '
        Me.Dtgemplist.AllowUserToAddRows = False
        Me.Dtgemplist.AllowUserToDeleteRows = False
        Me.Dtgemplist.AllowUserToResizeColumns = False
        Me.Dtgemplist.AllowUserToResizeRows = False
        Me.Dtgemplist.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Dtgemplist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.Dtgemplist.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(59, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Dtgemplist.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Dtgemplist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(21, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Century Gothic", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Red
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dtgemplist.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dtgemplist.ColumnHeadersHeight = 45
        Me.Dtgemplist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(59, Byte), Integer), CType(CType(17, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Dtgemplist.DefaultCellStyle = DataGridViewCellStyle2
        Me.Dtgemplist.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.Dtgemplist.EnableHeadersVisualStyles = False
        Me.Dtgemplist.Location = New System.Drawing.Point(13, 60)
        Me.Dtgemplist.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.Dtgemplist.Name = "Dtgemplist"
        Me.Dtgemplist.RowHeadersVisible = False
        Me.Dtgemplist.RowTemplate.Height = 24
        Me.Dtgemplist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dtgemplist.Size = New System.Drawing.Size(740, 341)
        Me.Dtgemplist.StandardTab = True
        Me.Dtgemplist.TabIndex = 52
        '
        'FormViewProfiles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(765, 438)
        Me.Controls.Add(Me.Dtgemplist)
        Me.Controls.Add(Me.BtnClose)
        Me.Controls.Add(Me.BtnSelect)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.TxtProfileSearch)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FormViewProfiles"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " "
        CType(Me.Dtgemplist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents TxtProfileSearch As TextBox
    Friend WithEvents BtnSelect As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents BtnClose As Bunifu.Framework.UI.BunifuFlatButton
    Friend WithEvents Dtgemplist As DataGridView
End Class
