﻿Public Class FromPreviewProfiles
    Private Sub FromPreviewProfiles_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            sql = "SELECT * FROM `employee` e, `employee_workinfo` ew " _
                 & " WHERE e.`EMPID`=ew.`EMPID` AND e.EMPID ='" & txtcode.Text & "'"
            reloadtxt(sql)

            If dt.Rows.Count > 0 Then

                txtaccnum.Text = dt.Rows(0).Item("ACCOUNT_NUM")
                txtrank.Text = dt.Rows(0).Item("RANK")
                PictureBox1.ImageLocation = Application.StartupPath & "\Photo\" & dt.Rows(0).Item("BFPEMPIMAGE")
                txtfname.Text = dt.Rows(0).Item("EMP_FNAME")
                txtlname.Text = dt.Rows(0).Item("EMP_LNAME")
                txtmname.Text = dt.Rows(0).Item("EMP_MNAME")
                Barangay.Text = dt.Rows(0).Item("ADDRESS")
                txtcontact.Text = dt.Rows(0).Item("CONTACT")
                txtstatus.Text = dt.Rows(0).Item("STATUS")
                dtpdbirth.Text = dt.Rows(0).Item("BIRTH_DATE")
                txtbplace.Text = dt.Rows(0).Item("BIRTH_PLACE")
                txtgender.Text = dt.Rows(0).Item("EMP_SEX")
                txtage.Text = dt.Rows(0).Item("EMP_AGE")
                txtemerg.Text = dt.Rows(0).Item("EMERG_CONTACT")
                txtsfxname.Text = dt.Rows(0).Item("EMP_SFXNAME")
                txtreligion.Text = dt.Rows(0).Item("RELIGION")
                cbomunicipality.Text = dt.Rows(0).Item("MUNICIPALITY")
                txtzipcode.Text = dt.Rows(0).Item("ZIPCODE")
                txtprovince.Text = dt.Rows(0).Item("PROVINCE")
                txtcrs.Text = dt.Rows(0).Item("TERTIARY_CRS")
                txtmascrs.Text = dt.Rows(0).Item("MASTERAL_CRS")
                txtmaslvl.Text = dt.Rows(0).Item("MASTERAL_LVL")
                txtdoccrs.Text = dt.Rows(0).Item("DOCTORATE_CRS")
                txtdoclvl.Text = dt.Rows(0).Item("DOCTORATE_LVL")
                cbohigheli.Text = dt.Rows(0).Item("HIGH_ELI")
                cbolvleli.Text = dt.Rows(0).Item("LVL_ELI")
                txtothereli.Text = dt.Rows(0).Item("OTHER_ELI")
                cbohighmantrain.Text = dt.Rows(0).Item("HIGH_MANTRAIN")
                txtdmantrain.Text = dt.Rows(0).Item("DTN_MANTRAIN")
                txtspecialtrain.Text = dt.Rows(0).Item("SPL_TRAIN")
                txtdspecialtrain.Text = dt.Rows(0).Item("DTN_SPLTRAIN")
                cbounitassign.Text = dt.Rows(0).Item("UNIT_ASSIGN")
                cbosoa.Text = dt.Rows(0).Item("STATUS_APPOINTMENT")
                txtadmin.Text = dt.Rows(0).Item("ADMIN")
                txtunitcode.Text = dt.Rows(0).Item("UNITCODE")
                txtitemnum.Text = dt.Rows(0).Item("ITEM_NUMBER")
                txtpridesig.Text = dt.Rows(0).Item("PRIMARY_DESIG")
                txtapd.Text = dt.Rows(0).Item("AUTH_PRIDESIG")
                dteop.Text = dt.Rows(0).Item("EFFECTIVE_PRIMARY")
                txtyrspridesig.Text = dt.Rows(0).Item("YRS_PRIMARY")
                dtdegs.Text = dt.Rows(0).Item("DEGS")
                dtdefs.Text = dt.Rows(0).Item("DEFS")
                txtyrsfiresvc.Text = dt.Rows(0).Item("YRS_FIRESERVICE")
                dtdao.Text = dt.Rows(0).Item("DAO")
                dtdolp.Text = dt.Rows(0).Item("DOLP")
                txtdateretire.Text = dt.Rows(0).Item("DATE_RETIREMENT")
                txtcondesig.Text = dt.Rows(0).Item("CON_DESIG")
                txtauthcondesig.Text = dt.Rows(0).Item("AUTH_CONDESIG")
                dteffectivecon.Text = dt.Rows(0).Item("EFFECTIVE_CON")
                txttinnum.Text = dt.Rows(0).Item("TIN_num")
                txtpibgnum.Text = dt.Rows(0).Item("PAGIBIG_num")
                txtgsisnum.Text = dt.Rows(0).Item("GSIS_num")
                txtphlthnum.Text = dt.Rows(0).Item("PHILHEALTH_num")
                txtbadgenum.Text = dt.Rows(0).Item("BADGE_num")
                txtlndbnknum.Text = dt.Rows(0).Item("LANDBANK_num")
                txtlngpaynum.Text = dt.Rows(0).Item("LONGPAY")
                txtremarks.Text = dt.Rows(0).Item("REMARKS")
                'Else
                '    cleartext(GroupBox10)
                '    cleartext(GroupBox9)
            Else

                loadautonumber("employee", txtcode)
            End If
            'aloadautonumber("employee", txtcode)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub GroupBox10_Enter(sender As Object, e As EventArgs) Handles GroupBox10.Enter

    End Sub
End Class