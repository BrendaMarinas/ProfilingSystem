-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2021 at 03:24 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bfparpis`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EMPID` varchar(60) NOT NULL,
  `EMP_FNAME` varchar(60) DEFAULT NULL,
  `EMP_LNAME` varchar(60) DEFAULT NULL,
  `EMP_MNAME` varchar(60) DEFAULT NULL,
  `ADDRESS` varchar(100) DEFAULT NULL,
  `CONTACT` varchar(20) DEFAULT NULL,
  `STATUS` varchar(30) DEFAULT NULL,
  `BIRTH_DATE` date DEFAULT NULL,
  `BIRTH_PLACE` varchar(100) DEFAULT NULL,
  `EMP_SEX` varchar(10) DEFAULT NULL,
  `EMP_AGE` int(11) DEFAULT NULL,
  `EMERG_CONTACT` varchar(25) DEFAULT NULL,
  `EMP_SFXNAME` varchar(70) DEFAULT NULL,
  `RELIGION` varchar(70) DEFAULT NULL,
  `MUNICIPALITY` varchar(100) DEFAULT NULL,
  `ZIPCODE` varchar(70) DEFAULT NULL,
  `PROVINCE` varchar(100) DEFAULT NULL,
  `TERTIARY_CRS` varchar(100) DEFAULT NULL,
  `MASTERAL_CRS` varchar(100) DEFAULT NULL,
  `MASTERAL_LVL` varchar(70) DEFAULT NULL,
  `DOCTORATE_CRS` varchar(100) DEFAULT NULL,
  `DOCTORATE_LVL` varchar(70) DEFAULT NULL,
  `HIGH_ELI` varchar(100) DEFAULT NULL,
  `LVL_ELI` varchar(70) DEFAULT NULL,
  `OTHER_ELI` varchar(150) DEFAULT NULL,
  `HIGH_MANTRAIN` varchar(150) DEFAULT NULL,
  `DTN_MANTRAIN` varchar(150) DEFAULT NULL,
  `SPL_TRAIN` varchar(150) DEFAULT NULL,
  `DTN_SPLTRAIN` varchar(150) DEFAULT NULL,
  `BFPEMPIMAGE` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `RECORDENTRY` double NOT NULL,
  `ONLEAVE` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EMPID`, `EMP_FNAME`, `EMP_LNAME`, `EMP_MNAME`, `ADDRESS`, `CONTACT`, `STATUS`, `BIRTH_DATE`, `BIRTH_PLACE`, `EMP_SEX`, `EMP_AGE`, `EMERG_CONTACT`, `EMP_SFXNAME`, `RELIGION`, `MUNICIPALITY`, `ZIPCODE`, `PROVINCE`, `TERTIARY_CRS`, `MASTERAL_CRS`, `MASTERAL_LVL`, `DOCTORATE_CRS`, `DOCTORATE_LVL`, `HIGH_ELI`, `LVL_ELI`, `OTHER_ELI`, `HIGH_MANTRAIN`, `DTN_MANTRAIN`, `SPL_TRAIN`, `DTN_SPLTRAIN`, `BFPEMPIMAGE`, `RECORDENTRY`, `ONLEAVE`) VALUES
('000011', 'Anthony', 'Dela Cruz', 'Navarro', 'Alvear St, San Carlos, Pangasinan', '09451909653', 'Single', '1999-12-11', 'Alvear St, San Carlos, Pangasinan', 'MALE', 22, '09451909653', 'JR.', 'Roman Catholic', 'SAN CARLOS', '2420', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '2ND', 'PD 907', 'FBRC', 'Jan – Mar 2019', 'HAZMAT', 'August 1-31, 2021', '1.jpg', 10, 0),
('0000110', 'Miguel', 'Soriano', 'Mendoza', 'Calvo St, Binmaley, Pangasinan', '09451909653', 'Single', '1999-12-11', 'Calvo St, Binmaley, Pangasinan', 'MALE', 22, '09451909653', 'JR.', 'Roman Catholic ', 'BINMALEY', '2417', 'PANGASINAN', 'BS Information Technology', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'PD 907', 'FBRC', 'May- July 2019', 'HAZMAT', 'August 1-31, 2021', '10.jpg', 10, 0),
('0000111', 'Mize', 'Enriquez', 'Santos', 'Bayombong St, Urdaneta, Pangasinan', '09483367017', 'Single', '1997-04-22', 'Bayombong St, Urdaneta, Pangasinan', 'MALE', 24, '09483367017', 'JR.', 'Roman Catholic', 'URDANETA', '2428', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'RA 1080', 'FBRC', 'Jan – Mar 2019', 'HAZMAT', 'August 1-31, 2021', '11.jpg', 10, 0),
('0000112', 'Peterson', 'Aquino', 'Caguioa', 'Tampac, Calasiao, Pangasinan', '09481836103', 'Single', '1999-07-02', 'Tampac, Calasiao, Pangasinan', 'MALE', 22, '09481836103', 'JR.', 'Roman Catholic', 'CALASIAO', '2418', 'PANGASINAN', 'BS Information Technology', 'None', 'None', 'None', 'None', 'CS Professional', '2ND', 'RA 1080', 'FBRC', 'May- July 2019', 'HAZMAT', 'August 1-31, 2021', '12.jpg', 10, 0),
('0000113', 'Romel', 'Agustin', 'Manzano', ': Poblacion, Bugallon, Pangasinan\n', ': 094571182', 'Single', '1999-10-11', ': Poblacion, Bugallon, Pangasinan\n', 'MALE', 22, ': 094571182', 'JR.', 'Roman Catholic', 'BUGALLON', '2416', 'PANGASINAN', 'BS Computer Science', 'None', 'None', 'None', 'None', 'CS Professional', '2ND', 'PD 907', 'FBRC', 'May- July 2019', 'HAZMAT', 'August 1-31, 2021', '13.jpg', 10, 0),
('0000114', 'Cezaro', 'Ventil', 'Delos Angeles', 'Pangapisan North, Lingayen, Pangasinan', '09456345103', 'Single', '1999-10-02', 'Pangapisan North, Lingayen, Pangasinan', 'MALE', 22, '09456345103', 'SR.', 'Roman Catholic ', 'LINGAYEN', '2401', 'PANGASINAN', 'BS Information Technology', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'CS Professional', 'FBRC', 'June- August 2019', 'HAZMAT', 'July1-31, 2021', '1.jpg', 10, 0),
('0000115', 'Adrian', 'Sinto', 'Lebanon', 'Balococ, Lingayen, Pangasinan', '09684225112', 'Single', '1999-07-09', 'Balococ, Lingayen, Pangasinan', 'MALE', 22, '09684225112', 'JR.', 'Roman Catholic ', 'LINGAYEN', '2401', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'CS Professional', 'FBRC', 'June- August 2019', 'HAZMAT', 'July1-31, 2021', '2.jpg', 10, 0),
('0000116', 'Izaz', 'Fila', 'Dezente', 'Sitio Casagatan Brgy. Bayaoas Aguilar', '09246614207', 'Single', '1999-02-19', 'Sitio Casagatan Brgy. Bayaoas Aguilar', 'MALE', 22, '09246614207', 'JR.', 'Roman Catholic ', 'DAGUPAN CITY', '2400', 'PANGASINAN', 'BS Information Technology', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'CS Professional', 'FAIIC', 'February- April 2019', 'HAZMAT', 'July1-31, 2021', '3.jpg', 10, 0),
('0000117', 'John Rabz', 'Jonen', 'Angeles', 'Lasip, Lingayen, Pangasinan', ' 0968422509', 'Single', '1999-08-14', 'Lasip, Lingayen, Pangasinan', 'MALE', 22, '09684225092', 'JR.', 'Roman Catholic', 'LINGAYEN', '2401', 'PANGASINAN', 'BS Information Technology', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'CS Professional', 'FBRC', 'February- April 2019', 'HAZMAT', 'July1-31, 2021', '5.jpg', 10, 0),
('0000118', 'John Mark', 'Miles', 'Vicentte', 'Sitio Casagatan Brgy. Bayaoas Aguilar', '09123456789', 'Single', '1998-10-25', 'Sitio Casagatan Brgy. Bayaoas Aguilar', 'MALE', 23, '09123456789', 'JR.', 'Roman Catholic ', 'AGUILAR', '2415', 'PANGASINAN', 'BS Information Technology', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'CS Professional', 'FBRC', 'February- April 2019', 'HAZMAT', 'July1-31, 2021', '6.jpg', 10, 0),
('0000119', 'Razel', 'Aquino', 'Espanol', 'Pogomboa, Aguilar, Pangasinan', '09661431039', 'Single', '1999-12-09', 'Pogomboa, Aguilar, Pangasinan', 'MALE', 22, '09661431039', 'JR.', 'Roman Catholic ', 'AGUILAR', '2415', 'PANGASINAN', 'BS Information Technology', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'PD 907', 'FBRC', 'Ocotber- December 2019', 'HAZMAT', 'July1-31, 2021', '7.jpg', 10, 0),
('000012', 'Cyrus', 'Valdez', 'Villanueva', 'Libas St, San Carlos, Pangasinan', '09051028174', 'Single', '1999-02-01', 'Libas St, San Carlos, Pangasinan', 'MALE', 22, '09051028174', 'SR.', 'Roman Catholic', 'SAN CARLOS', '2420', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'CS Professional', '2ND', 'RA 1080', 'FBRC', 'May –Jul 2019', 'HAZMAT', 'April 1-31, 2021', '2.jpg', 10, 0),
('0000120', 'Lindon', 'Simpit', 'Julian', 'Bonuan, Dagupan, Pangasinan', '09456225113', 'Single', '1999-01-15', 'Bonuan, Dagupan, Pangasinan', 'MALE', 22, '09456225113', 'JR.', 'Roman Catholic', 'DAGUPAN CITY', '2400', 'PANGASINAN', 'BS Electrical Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'CS Professional', 'FBRC', 'June- August 2019', 'HAZMAT', 'July1-31, 2021', '9.jpg', 10, 0),
('0000121', 'Hillarys', 'Castro', 'Jiensa', 'San Iisrod Sur', '098332432', 'Single', '2000-06-15', 'Binmaley Engot', 'FEMALE', 21, '098332432', 'NONE', 'INC', 'Binmaley', '2417', 'Pangasinan', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'RA 1080', '1ST', 'NONE', 'FBRC', 'NONE', 'NONE', 'NONE', 'ceazar.jpg', 10, 0),
('0000122', 'Giana', 'Perez', 'Castro', 'Enogt\n', '093287232', 'Married', '2000-11-15', 'Enogt', 'FEMALE', 21, '093287232', '----Select-----', 'INC', 'Bugallon', '2416', 'Pangasinan', 'none', 'none', 'none', 'none', 'none', 'RA 1080', '1ST', 'none', 'FAIIC', 'none', 'none', 'none', 'ceazar.jpg', 10, 0),
('0000126', 'Billary', 'Delos Reyes', 'Sanadara', 'San Isidro Sur', '0923121321', 'Single', '2000-06-15', 'Binmaley Pangasinan', 'FEMALE', 21, '0923121321', 'SR.', 'INC', 'Bugallon', '2416', 'Pangasinan', 'N/a', 'N/a', 'N/a', 'N/a', 'N/a', 'RA 1080', '1ST', 'N/a', 'FPSC', 'N/a', 'N/a', 'N/a', '2.jpg', 10, 0),
('000013', 'Darwin', 'Sarmiento', 'Alcantara', 'Sakbit St, San Carlos, Pangasinan', '09051028174', 'Single', '1998-12-09', 'Sakbit St, San Carlos, Pangasinan', 'MALE', 23, '09051028174', 'JR.', 'Roman Catholic', 'SAN CARLOS', '2420', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '2ND', 'RA 1080', 'FBRC', 'May –Jul 2019', 'HAZMAT', 'April 1-31, 2021', '3.jpg', 10, 0),
('000014', 'Denmark', 'Rosales', 'Galvez', 'Calugay St, Manoag, Pangasinan', '09451909653', 'Single', '1999-02-12', 'Calugay St, Manoag, Pangasinan', 'MALE', 22, '09451909653', 'JR.', 'Roman Catholic', 'DAGUPAN CITY', '2400', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'PD 907', 'FBRC', 'Jan – Mar 2019', 'HAZMAT', 'August 1-31, 2021', '4.jpg', 10, 0),
('000015', 'Edwin', 'Pastrana', 'Tuazon', 'Quibaol, Lingayen, Pangasinan', '09054855298', 'Single', '1996-11-22', 'Quibaol, Lingayen, Pangasinan', 'MALE', 25, '09054855298', 'JR.', 'Roman Catholic ', 'LINGAYEN', '2401', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'CS Professional', '2ND', 'RA 1080', 'FBRC', 'May –Jul 2019', 'HAZMAT', 'April 1-31, 2021', '5.jpg', 10, 0),
('000016', 'Franklin', 'Manaois', 'Paragas', 'Coloso St., Kabankalan City\n', '09623561039', 'Single', '1998-11-13', 'Coloso St., Kabankalan City\n', 'MALE', 23, '09623561039', 'JR.', 'Roman Catholic ', 'DAGUPAN CITY', '2400', 'PANGASINAN', 'BS Mechanical Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'PD 907', 'FBRC', 'October- December 2019', 'HAZMAT', 'July1-31, 2021', '6.jpg', 10, 0),
('000017', 'Jayson', 'Tolentino', 'Tejada', 'Laoag, Dagupan City, Pangasinan\n', '09482719274', 'Single', '1999-05-09', 'Laoag, Dagupan City, Pangasinan\n\n', 'FEMALE', 22, '09482719274', 'JR.', 'Roman Catholic', 'Lingayen', '2401', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'CS Professional', '2ND', 'PD 907', 'FBRC', 'May- July 2019', 'HAZMAT', 'August 1-31, 2021', '7.jpg', 10, 0),
('000018', 'Jericho', 'Vidal', 'Francisco', 'Limos St, Manaoag, Pangasinan\n', '09054855298', 'Single', '1997-03-26', 'Limos St, Manaoag, Pangasinan\n', 'MALE', 24, '09054855298', 'JR.', 'Roman Catholic ', 'CALASIAO', '2418', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'CS Professional', '2ND', 'RA 1080', 'FBRC', 'Sept –Nov 2019', 'HAZMAT', 'April 1-31, 2021', '8.jpg', 10, 0),
('000019', 'Junmar', 'Fajardo', 'Manlangit', 'Navato St., Bugallon Pangasinan\n', '09663533032', 'Single', '1997-09-14', 'Navato St., Bugallon Pangasinan\n', 'MALE', 24, '09663533032', 'JR.', 'Roman Catholic', 'BUGALLON', '2416', 'PANGASINAN', 'BS Civil Engineering', 'None', 'None', 'None', 'None', 'RA 1080', '1ST', 'PD 907', 'FBRC', 'October- December 2019', 'HAZMAT', 'July1-31, 2021', '9.jpg', 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee_workinfo`
--

CREATE TABLE `employee_workinfo` (
  `id` int(10) NOT NULL,
  `EMPID` int(30) NOT NULL,
  `ACCOUNT_NUM` varchar(100) DEFAULT NULL,
  `RANK` varchar(60) DEFAULT NULL,
  `UNIT_ASSIGN` varchar(50) NOT NULL,
  `STATUS_APPOINTMENT` varchar(30) NOT NULL,
  `ADMIN` varchar(100) DEFAULT NULL,
  `UNITCODE` varchar(50) DEFAULT NULL,
  `ITEM_NUMBER` varchar(100) DEFAULT NULL,
  `PRIMARY_DESIG` varchar(100) DEFAULT NULL,
  `AUTH_PRIDESIG` varchar(100) DEFAULT NULL,
  `EFFECTIVE_PRIMARY` date DEFAULT NULL,
  `YRS_PRIMARY` varchar(100) DEFAULT NULL,
  `DEGS` date DEFAULT NULL,
  `DEFS` date DEFAULT NULL,
  `YRS_FIRESERVICE` varchar(100) DEFAULT NULL,
  `DAO` date DEFAULT NULL,
  `DOLP` date DEFAULT NULL,
  `DATE_RETIREMENT` varchar(70) DEFAULT NULL,
  `CON_DESIG` varchar(50) DEFAULT NULL,
  `AUTH_CONDESIG` varchar(50) DEFAULT NULL,
  `EFFECTIVE_CON` date DEFAULT NULL,
  `TIN_num` varchar(70) DEFAULT NULL,
  `PAGIBIG_num` varchar(70) DEFAULT NULL,
  `GSIS_num` varchar(70) DEFAULT NULL,
  `PHILHEALTH_num` varchar(70) DEFAULT NULL,
  `BADGE_num` varchar(70) DEFAULT NULL,
  `LANDBANK_num` varchar(70) DEFAULT NULL,
  `LONGPAY` varchar(100) DEFAULT NULL,
  `REMARKS` varchar(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_workinfo`
--

INSERT INTO `employee_workinfo` (`id`, `EMPID`, `ACCOUNT_NUM`, `RANK`, `UNIT_ASSIGN`, `STATUS_APPOINTMENT`, `ADMIN`, `UNITCODE`, `ITEM_NUMBER`, `PRIMARY_DESIG`, `AUTH_PRIDESIG`, `EFFECTIVE_PRIMARY`, `YRS_PRIMARY`, `DEGS`, `DEFS`, `YRS_FIRESERVICE`, `DAO`, `DOLP`, `DATE_RETIREMENT`, `CON_DESIG`, `AUTH_CONDESIG`, `EFFECTIVE_CON`, `TIN_num`, `PAGIBIG_num`, `GSIS_num`, `PHILHEALTH_num`, `BADGE_num`, `LANDBANK_num`, `LONGPAY`, `REMARKS`) VALUES
(89, 11, 'U80261', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'Chief admin', 'SO 2021-02', '2021-12-31', '122 Days 0 Years 4 Months ', '2021-10-12', '2021-12-31', '-67 Days 0 Years -2 Months ', '2021-10-25', '2021-10-25', '12/11/2055 12:25:21 AM', 'chief operation', 'SO, 2021-05', '2021-10-16', 'a4654056-3', '22-fa3530', '1-691616-51', '975633-1', 'S25256', '1414-1309-720', '4', '3'),
(90, 12, 'U40151', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'Admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '122 Days 0 Years 4 Months ', '1999-10-25', '1999-06-25', '8158 Days 22 Years 272 Months ', '2005-10-25', '2021-10-25', '2/1/2055 12:39:48 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4159256-0', '21-fa1942', '1-699696-58', '#: 971619-1', 'S25256', '2014-1149-790', '4', '2'),
(91, 13, 'U20254', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'Admin', '10401', 'U-08-0672', 'Chief Admin', 'SO 2021-02', '2021-10-25', '7975 Days 22 Years 266 Months ', '2021-10-25', '1999-12-25', '7975 Days 22 Years 266 Months ', '2005-10-25', '2021-10-25', '12/9/2054 12:46:53 AM', 'chief operation', 'SO, 2021-05', '2021-10-16', 'a4159256-3', '21-fa1940', '1-699696-51', '971609-1', 'S25256', '1014-1149-790', '3', '3'),
(92, 14, 'U61260', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '5844 Days 16 Years 195 Months ', '2021-10-25', '1999-10-25', '8036 Days 22 Years 268 Months ', '2005-10-25', '2021-10-20', '2/12/2055 12:52:26 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4654056-3', '22-fa3520', '1-691616-51', '975603-1', 'S25256', '2414-1109-720', '4', '2'),
(93, 15, 'U60261', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '122 Days 0 Years 4 Months ', '2021-03-25', '1999-05-25', '8189 Days 22 Years 273 Months ', '2005-10-25', '2021-02-25', '11/22/2052 1:00:19 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4159056-3', '20-fa3940', '1-699616-51', '971609-1', 'S25256', '1014-1149-790', '3', '2'),
(94, 16, 'U90002', 'SUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '5844 Days 16 Years 195 Months ', '2021-06-25', '1999-10-25', '8036 Days 22 Years 268 Months ', '2021-10-25', '2021-10-25', '11/13/2054 1:07:36 AM', 'chief operation', 'SO, 2021-05', '2021-10-16', 'a4554356-3', '12-fa9541', '1-621546-57', '971399-1', 'S25256', '1324-1329-125', '3', '1'),
(95, 17, 'U90205', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '5844 Days 16 Years 195 Months ', '2021-07-25', '1999-12-25', '7975 Days 22 Years 266 Months ', '2021-10-06', '2021-10-12', '5/9/2055 1:13:06 AM', 'chief operation', 'SO, 2021-05', '2021-12-25', 'a4554356-3', '12-fa6531', '1-621646-57', '971333-1', 'S25256', '1424-1389-721', '3', '2'),
(96, 18, 'U63269', 'SSUPT', 'URDANETA', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '6209 Days 17 Years 207 Months ', '2021-06-25', '2006-10-25', '5479 Days 15 Years 183 Months ', '2021-10-13', '2021-10-20', '3/26/2053 1:18:57 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4154056-3', '22-fa3940', '1-699616-51', '974609-1', 'S25256', '2014-1149-790', '3', '1'),
(97, 19, 'U90002', 'SUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '579 Days 2 Years 19 Months ', '1999-10-25', '2020-07-25', '457 Days 1 Years 15 Months ', '2021-10-25', '2021-10-25', '9/14/2053 1:25:37 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554356-3', '12-fa6531', '1-621546-57', '971339-6', 'S25256', '1324-1389-121', '3', '2'),
(98, 110, 'U90263', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '365 Days 1 Years 12 Months ', '1999-10-25', '2004-10-25', '6209 Days 17 Years 207 Months ', '2021-10-25', '2021-10-25', '12/11/2055 1:30:53 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4654056-3', '22-fa3530', '1-621616-51', '971633-1', ' S25256', '1404-1309-720', '4', '2'),
(99, 111, 'U63269', 'SSUPT', 'URDANETA', 'Regular', 'Admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '365 Days 1 Years 12 Months ', '1999-03-25', '2021-10-25', '0 Days 0 Years 0 Months ', '2021-10-25', '2021-10-25', '4/22/2053 1:35:55 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4654056-3', '22-fa3920', '1-699616-51', '975609-1', 'S25256', '2414-1109-790', '3', '4'),
(100, 112, 'U91206', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'Admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2006-10-25', '5479 Days 15 Years 183 Months ', '2021-10-25', '2021-10-25', '7/2/2055 1:41:21 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554356-3', '22-fa3530', '1-621646-51', '971933-1', 'S25256', '1404-1389-720', '3', '3'),
(101, 113, 'U91263', 'SSUPT', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '5479 Days 15 Years 183 Months ', '2021-10-25', '2020-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2021-10-25', '10/11/2055 1:45:38 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4654056-3', '22-fa3530', '1-621616-51', '971633-1', 'S25256', '1404-1309-720', '3', '4'),
(102, 114, 'U90002', 'SUPT', 'MANAOG', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '8036 Days 22 Years 268 Months ', '2021-10-25', '2001-10-25', '7305 Days 20 Years 244 Months ', '2021-10-25', '2021-10-25', '10/2/2055 1:49:27 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554356-3', '12-fa3543', '1-632546-56', '9723979-6', 'S25256', '1324-1359-126', '3', '2'),
(103, 115, 'U90002', 'SFO3', 'DAGUPAN CITY', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '5844 Days 16 Years 195 Months ', '2021-10-25', '1999-10-25', '8036 Days 22 Years 268 Months ', '2021-10-25', '2021-10-25', '7/9/2055 1:56:03 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554456-4', '10-fa4544', '1-646546-54', '9798979-4', 'S25054', '1074-1459-124', '4', '2'),
(104, 116, 'U90003', 'SFO2', 'URDANETA', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '5844 Days 16 Years 195 Months ', '2021-03-25', '2020-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2021-10-25', '2/19/2055 2:01:49 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554456-4', '10-fa4545', '1-646546-55', '9798979-1', 'S25059', '1074-1459-122', '3', '2'),
(105, 117, 'U90002', 'SUPT', 'MANAOG', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '4383 Days 12 Years 146 Months ', '2021-10-25', '2020-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2021-10-25', '8/14/2055 2:06:13 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554456-3', '10-fa4542', '1-646546-52', '9798979-2', 'S25052', '1074-1459-123', '4', '2'),
(106, 118, 'U90003', 'SUPT', 'AGUILAR ', 'Regular', 'Admin', '123187', 'U-SAD87234', 'Admin Chief', 'S0.A231', '2021-10-25', '242 Days 1 Years 8 Months ', '2021-10-25', '2010-10-25', '4018 Days 11 Years 134 Months ', '2021-10-25', '2021-10-25', '10/25/2054 2:10:38 AM', 'Chief', 'S0.A231', '2021-10-25', 'a4554456-4', '10-fa4545', '1-646546-55', '9798979-1', 'S25059', '1074-1459-122', '3', '2'),
(107, 119, 'U90002', 'SUPT', 'URDANETA', 'Regular', ' admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2020-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2021-10-25', '12/9/2055 2:15:48 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554356-3', '12-fa3541', '1-631546-51', '9723929-1', 'S25256', '1324-1319-121', '3', '1'),
(108, 120, 'U90002', 'SSUPT', 'SAN CARLOS', 'Regular', 'admin', '10401', 'U-08-0672', 'chief admin', 'SO 2021-02', '2021-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2020-10-25', '365 Days 1 Years 12 Months ', '2021-10-25', '2021-10-25', '1/15/2055 2:19:41 AM', 'chief operation', 'SO, 2021-05', '2021-10-25', 'a4554356-3', '10-fa3543', '1-636546-53', '9793979-3', 'S25054', '1374-1359-123', '3', '2'),
(109, 121, 'NONE', 'NUP', 'Aguilar', 'Regular', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', '2021-11-02', '352 Days 1 Years 12 Months ', '2021-11-15', '2020-11-15', '0 Days 0 Years 0 Months ', '2021-11-15', '2021-11-15', '6/15/2056 11:53:46 AM', 'NONE', 'NONE', '2021-11-15', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE', 'NONE'),
(110, 122, 'none', 'NUP', 'Binmaley', 'Regular', 'none', 'none', 'none', 'none', 'none', '2021-11-15', '279 Days 1 Years 9 Months ', '2021-11-15', '2021-02-15', '273 Days 1 Years 9 Months ', '2021-11-10', '2021-11-15', '11/15/2056 11:56:44 AM', 'none', 'none', '2021-11-15', 'none', 'none', 'none', 'none', 'none', 'none', 'none', 'none'),
(111, 123, 'ADMIN', 'FO2', 'Binmaley', 'Regular', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN', '2021-11-15', '0 Days 0 Years 0 Months ', '2021-11-15', '2021-11-15', '0 Days 0 Years 0 Months ', '2021-11-15', '2021-11-15', '11/15/2057 12:11:43 PM', 'ADMIN', 'ADMIN', '2021-11-15', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN', 'ADMIN'),
(112, 124, 'Pangasinan', 'NUP', 'Bugallon', 'Regular', 'Pangasinan', 'Pangasinan', 'Pangasinan', 'Pangasinan', 'Pangasinan', '2021-11-15', '0 Days 0 Years 0 Months ', '2021-11-15', '2021-11-15', '0 Days 0 Years 0 Months ', '2021-11-15', '2021-11-15', '11/15/2056 12:19:06 PM', 'Pangasinan', 'Pangasinan', '2021-11-15', 'Pangasinan', 'Pangasinan', 'Pangasinan', 'Pangasinan', 'Pangasinan', 'Pangasinan', 'Pangasinan', 'Pangasinan'),
(116, 126, 'N/a', 'NUP', 'Bugallon', 'Regular', 'N/a', 'N/a', 'N/a', 'N/a', 'N/a', '2021-11-15', '365 Days 1 Years 12 Months ', '2021-11-15', '2021-11-15', '0 Days 0 Years 0 Months ', '2021-11-15', '2021-11-15', '6/15/2056 12:40:04 PM', 'N/a', 'N/a', '2021-11-15', 'N/a', 'N/a', 'N/a', 'N/a', 'N/a', 'N/a', 'N/a', 'N/a');

-- --------------------------------------------------------

--
-- Table structure for table `history_resignation`
--

CREATE TABLE `history_resignation` (
  `RESIGID` int(11) NOT NULL,
  `EMPID` int(11) NOT NULL,
  `ACCOUNT_NUM` varchar(30) NOT NULL,
  `DATEFROM` datetime NOT NULL,
  `DATETO` datetime NOT NULL,
  `NODAYS` varchar(100) NOT NULL,
  `DESIGNATION` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history_resignation`
--

INSERT INTO `history_resignation` (`RESIGID`, `EMPID`, `ACCOUNT_NUM`, `DATEFROM`, `DATETO`, `NODAYS`, `DESIGNATION`) VALUES
(66, 11, 'U80261', '2021-10-25 12:25:18', '2022-10-25 12:25:18', '365', 'chief operation'),
(67, 110, 'U90263', '2021-06-25 02:23:59', '2021-11-03 02:23:59', '131', 'chief operation'),
(68, 111, 'U63269', '2021-10-07 02:24:21', '2021-11-25 02:24:21', '49', 'chief operation'),
(69, 112, 'U91206', '2021-06-25 02:24:41', '2021-10-25 02:24:41', '122', 'chief operation'),
(70, 113, 'U91263', '2021-02-25 02:25:04', '2022-02-11 02:25:04', '351', 'chief operation'),
(71, 120, 'U90002', '2021-11-19 01:06:08', '2021-11-26 01:06:08', '7', 'chief operation');

-- --------------------------------------------------------

--
-- Table structure for table `tblautonumber`
--

CREATE TABLE `tblautonumber` (
  `id` int(11) NOT NULL,
  `STRT` varchar(30) NOT NULL,
  `END` int(11) NOT NULL,
  `INCREMENT` int(11) NOT NULL,
  `DESCRIPTION` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblautonumber`
--

INSERT INTO `tblautonumber` (`id`, `STRT`, `END`, `INCREMENT`, `DESCRIPTION`) VALUES
(1, '00001', 27, 1, 'employee'),
(2, '1032', 2, 1, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `tbldateentry`
--

CREATE TABLE `tbldateentry` (
  `RESIGID` int(11) NOT NULL,
  `EMPID` varchar(11) NOT NULL,
  `DATE_ENTRY` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldateentry`
--

INSERT INTO `tbldateentry` (`RESIGID`, `EMPID`, `DATE_ENTRY`) VALUES
(191, '000011', 'Monday, Oct 25 2021 12:35:33 AM'),
(192, '000012', 'Monday, Oct 25 2021 12:46:52 AM'),
(193, '000013', 'Monday, Oct 25 2021 12:52:26 AM'),
(194, '000014', 'Monday, Oct 25 2021 12:58:19 AM'),
(195, '000015', 'Monday, Oct 25 2021 01:05:48 AM'),
(196, '000016', 'Monday, Oct 25 2021 01:12:41 AM'),
(197, '000017', 'Monday, Oct 25 2021 01:18:56 AM'),
(198, '000018', 'Monday, Oct 25 2021 01:25:04 AM'),
(199, '000019', 'Monday, Oct 25 2021 01:30:53 AM'),
(200, '0000110', 'Monday, Oct 25 2021 01:35:19 AM'),
(201, '0000111', 'Monday, Oct 25 2021 01:40:36 AM'),
(202, '0000112', 'Monday, Oct 25 2021 01:44:58 AM'),
(203, '0000113', 'Monday, Oct 25 2021 01:49:26 AM'),
(204, '0000114', 'Monday, Oct 25 2021 01:56:02 AM'),
(205, '0000115', 'Monday, Oct 25 2021 02:01:49 AM'),
(206, '0000116', 'Monday, Oct 25 2021 02:06:13 AM'),
(207, '0000117', 'Monday, Oct 25 2021 02:10:38 AM'),
(208, '0000118', 'Monday, Oct 25 2021 02:15:48 AM'),
(209, '0000119', 'Monday, Oct 25 2021 02:19:41 AM'),
(210, '0000120', 'Monday, Oct 25 2021 02:23:16 AM'),
(211, '0000121', 'Monday, Nov 15 2021 11:56:43 AM'),
(212, '0000122', 'Monday, Nov 15 2021 12:00:07 PM'),
(213, '0000123', 'Monday, Nov 15 2021 12:14:18 PM'),
(214, '0000124', 'Monday, Nov 15 2021 12:20:23 PM'),
(215, '0000125', 'Monday, Nov 15 2021 12:36:54 PM'),
(216, '0000126', 'Monday, Nov 15 2021 12:41:39 PM');

-- --------------------------------------------------------

--
-- Table structure for table `tblsettings`
--

CREATE TABLE `tblsettings` (
  `ID` int(11) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `FORTHE` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsettings`
--

INSERT INTO `tblsettings` (`ID`, `DESCRIPTION`, `FORTHE`) VALUES
(1, 'NUP', 'RANK'),
(2, 'SFO1', 'RANK'),
(3, 'FO2', 'RANK'),
(4, 'FO3', 'RANK'),
(5, 'SFO1', 'RANK'),
(6, 'SFO2', 'RANK'),
(7, 'SFO3', 'RANK'),
(8, 'SFO4', 'RANK'),
(9, 'INSP', 'RANK'),
(10, 'SINSP', 'RANK'),
(12, 'CINSP', 'RANK'),
(13, 'SUPT', 'RANK'),
(14, 'SSUPT', 'RANK');

-- --------------------------------------------------------

--
-- Table structure for table `tblunitassign`
--

CREATE TABLE `tblunitassign` (
  `ID` int(11) NOT NULL,
  `UNIT_ASSIGN` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblunitassign`
--

INSERT INTO `tblunitassign` (`ID`, `UNIT_ASSIGN`) VALUES
(2, 'Aguilar'),
(3, 'Bugallon'),
(4, 'Binmaley'),
(5, 'San Jacinto'),
(6, 'Dagupan'),
(7, 'Lingayen'),
(8, 'Manaog'),
(9, 'San Carlos'),
(10, 'Urdaneta');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `USER_ID` int(30) NOT NULL,
  `NAME` text DEFAULT NULL,
  `USERNAME` varchar(60) DEFAULT NULL,
  `PASSWORD` varchar(90) DEFAULT NULL,
  `TYPE` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`USER_ID`, `NAME`, `USERNAME`, `PASSWORD`, `TYPE`) VALUES
(12, 'adminstrator', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'Administrator'),
(10328, 'HR Personnel', 'HR', '51bd95353aeda6615433bea21896c893ef5e62dc', 'HR Personnel'),
(10329, 'admin2', 'admin', 'da39a3ee5e6b4b0d3255bfef95601890afd80709', 'Administrator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EMPID`);

--
-- Indexes for table `employee_workinfo`
--
ALTER TABLE `employee_workinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history_resignation`
--
ALTER TABLE `history_resignation`
  ADD PRIMARY KEY (`RESIGID`);

--
-- Indexes for table `tblautonumber`
--
ALTER TABLE `tblautonumber`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldateentry`
--
ALTER TABLE `tbldateentry`
  ADD PRIMARY KEY (`RESIGID`);

--
-- Indexes for table `tblsettings`
--
ALTER TABLE `tblsettings`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblunitassign`
--
ALTER TABLE `tblunitassign`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `employee_workinfo`
--
ALTER TABLE `employee_workinfo`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `history_resignation`
--
ALTER TABLE `history_resignation`
  MODIFY `RESIGID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `tblautonumber`
--
ALTER TABLE `tblautonumber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbldateentry`
--
ALTER TABLE `tbldateentry`
  MODIFY `RESIGID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=217;

--
-- AUTO_INCREMENT for table `tblsettings`
--
ALTER TABLE `tblsettings`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblunitassign`
--
ALTER TABLE `tblunitassign`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `USER_ID` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103212;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
